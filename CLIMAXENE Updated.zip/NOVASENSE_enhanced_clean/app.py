"""
ClimaXene — AI Flood Prediction & Climate Intelligence Platform
Ensemble ML + Humidity Intelligence Engine (HIE / MXene-Inspired Adaptive Sensing) + 5-tier early warning
"""

from __future__ import annotations

import json
import os
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
import streamlit.components.v1 as components
from dotenv import load_dotenv

from src.alert_log import AlertEntry, record_tier_change
from src.command_center import render_command_center
from src.demo_presets import DEMO_SCENARIOS, apply_scenario
from src.disaster_assistant import get_response as assistant_response
from src.drought import drought_factor
from src.evaluation import bias_audit_by_zone, evaluate_on_holdout
from src.historical_validation import load_events, validate_events
from src.i18n import LANGUAGES, t, tier_action, tier_name as i18n_tier_name
from src.imd_loader import is_imd_export_path, load_imd_export, resolve_training_path
from src.india_map import build_india_map
from src.live_map import fetch_live_city_risks
from src.mias import DEFAULT_ELAPSED_SECONDS, DEFAULT_TAU_SECONDS
from src.mias import formula_display, mxene_curve, mxene_response
from src.model_training import feature_importance, load_model, train_ensemble
from src.narrative import build_alert_summary
from src.predictions import PredictionResult, mias_formula_display, predict
from src.preprocessing import build_single_row
from src.shap_explain import get_shap_contributions
from src.theme import apply_plotly_theme, inject_global_css
from src.ui_components import (
    render_alert_banner,
    render_confidence_meter,
    render_demo_callout,
    render_footer,
    render_hero,
    render_impact_panel,
    render_metric_row,
    render_pipeline_diagram,
    render_problem_solution,
    render_section,
    render_sms_mockup,
    render_tier_pill,
)
from src.weather_api import fetch_forecast, fetch_live_weather
from src.hazard_profile import (
    get_profile, get_profile_by_climate, HAZARD_META,
    compute_primary_score, compute_secondary_score,
    HazardType,
)

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
MODEL_DIR = ROOT / "models"
DATA_PATH = resolve_training_path(ROOT)
CITIES_PATH = ROOT / "data" / "combined_cities.csv"
EVENTS_PATH = ROOT / "data" / "combined_historical_events.json"
METRICS_PATH = MODEL_DIR / "metrics.json"

st.set_page_config(
    page_title="ClimaXene | Climate Intelligence",
    page_icon="🌧️",
    layout="wide",
    initial_sidebar_state="expanded",
)
inject_global_css()


@st.cache_resource
def get_model():
    if not (MODEL_DIR / "ensemble_model.joblib").exists():
        return None, {}, {}
    return load_model(MODEL_DIR)


@st.cache_data
def load_historical_data() -> pd.DataFrame:
    if not DATA_PATH.exists():
        return pd.DataFrame()
    if is_imd_export_path(DATA_PATH):
        return load_imd_export(DATA_PATH)
    return pd.read_csv(DATA_PATH)


@st.cache_data
def load_india_cities() -> pd.DataFrame:
    return pd.read_csv(CITIES_PATH) if CITIES_PATH.exists() else pd.DataFrame()


@st.cache_data
def load_stored_metrics() -> dict:
    if METRICS_PATH.exists():
        return json.loads(METRICS_PATH.read_text(encoding="utf-8"))
    return {}


@st.cache_data
def cached_evaluation(_model_id: str, data_mtime: float) -> dict:
    model, _, _ = get_model()
    df = load_historical_data()
    if model is None or df.empty:
        return {}
    return evaluate_on_holdout(model, df)


def init_session():
    if "alert_log" not in st.session_state:
        st.session_state.alert_log: list[AlertEntry] = []
    if "last_tier" not in st.session_state:
        st.session_state.last_tier = {}
    if "lang" not in st.session_state:
        st.session_state.lang = "en"
    if "chat_history" not in st.session_state:
        st.session_state.chat_history: list[dict] = []


def _weather_defaults() -> dict:
    w = st.session_state.get("weather", {})
    demo_city = st.session_state.get("demo_city")
    if demo_city and not w:
        scenario_id = st.session_state.get("demo_active")
        if scenario_id and scenario_id in DEMO_SCENARIOS:
            s = DEMO_SCENARIOS[scenario_id]
            w = {
                "city": s.city,
                "temperature": s.temperature,
                "humidity": s.humidity,
                "pressure": s.pressure,
                "dew_point": s.dew_point,
                "wind_speed": s.wind_speed,
            }
    return w


def sidebar_inputs(env_api_key: str) -> tuple[str, float, float, float, float, float, float, str, str]:
    with st.sidebar:
        st.markdown("### ⚙️ Control Center")

        # ── Language selector ─────────────────────────────────────────────
        lang_label = st.selectbox(
            "🌐 Language",
            list(LANGUAGES.keys()),
            index=0,
            key="lang_selector",
        )
        lang = LANGUAGES[lang_label]
        st.session_state["lang"] = lang

        st.divider()
        st.markdown("##### 🎬 Judge Demo")
        demo_choice = st.selectbox(
            "Load scenario",
            ["— Select —"] + [s.title for s in DEMO_SCENARIOS.values()],
            label_visibility="collapsed",
        )
        if st.button("▶ Run demo scenario", use_container_width=True, type="primary"):
            for s in DEMO_SCENARIOS.values():
                if s.title == demo_choice:
                    apply_scenario(s)
                    st.rerun()
            if demo_choice != "— Select —":
                st.warning("Pick a scenario from the list first.")

        active = st.session_state.get("demo_active")
        if active and active in DEMO_SCENARIOS:
            s = DEMO_SCENARIOS[active]
            st.caption(f"Active: **{s.title}** → {s.tab_hint}")

        st.divider()
        st.markdown("##### 🌐 Live data")
        if env_api_key:
            st.success("OpenWeather key loaded")
        else:
            st.warning("Add `OPENWEATHER_API_KEY` to `.env`")

        api_override = st.text_input(
            "Override API key",
            type="password",
            value="",
            help="Leave empty to use `.env`.",
            key="openweather_key_override",
        )
        effective_key = api_override.strip() if api_override.strip() else env_api_key

        cities_df = load_india_cities()
        city_names = cities_df["city"].tolist() if not cities_df.empty else ["Mumbai"]
        demo_city = st.session_state.get("demo_city")
        default_idx = city_names.index(demo_city) if demo_city in city_names else (
            city_names.index("Mumbai") if "Mumbai" in city_names else 0
        )
        city = st.selectbox(f"City ({len(city_names)} cities)", city_names, index=default_idx)

        if st.button("📡 Fetch live weather", use_container_width=True):
            try:
                w = fetch_live_weather(city, effective_key or None)
                st.session_state["weather"] = w
                st.session_state.pop("demo_active", None)
                st.success(f"{w['city']}, {w['country']}")
            except Exception as e:
                st.error(str(e))

        w = _weather_defaults()
        temperature = st.number_input("Temperature (°C)", value=float(w.get("temperature", 28.0)), step=0.5)
        humidity = st.slider("Humidity (%)", 0.0, 100.0, float(w.get("humidity", 72.0)), 0.5)
        pressure = st.number_input("Pressure (hPa)", value=float(w.get("pressure", 1010.0)), step=1.0)
        dew_point = st.number_input("Dew point (°C)", value=float(w.get("dew_point", 22.0)), step=0.5)
        wind_speed = st.number_input("Wind speed (km/h)", value=float(w.get("wind_speed", 15.0)), step=0.5)
        default_elapsed = float(st.session_state.get("demo_elapsed", DEFAULT_ELAPSED_SECONDS))
        elapsed_seconds = st.slider(
            "HIE sensor time t (s)",
            0.0,
            30.0,
            default_elapsed,
            0.1,
            help=f"T(t)=1−e^(−t/τ), τ={DEFAULT_TAU_SECONDS}s (lab MXene ~0.5–2s)",
        )

        st.divider()
        st.markdown("##### 🔔 Alert feed")
        log = st.session_state.get("alert_log", [])
        if log:
            for entry in log[:8]:
                st.caption(f"**{entry.timestamp}** — {entry.message}")
        else:
            st.caption("Tier changes appear here during the session.")

        st.divider()
        uploaded = st.file_uploader("Upload training CSV", type=["csv"])
        if st.button("🔄 Retrain model", use_container_width=True):
            with st.spinner("Training ensemble on IMD data…"):
                if uploaded:
                    df_train = pd.read_csv(uploaded)
                elif is_imd_export_path(DATA_PATH):
                    df_train = load_imd_export(DATA_PATH)
                else:
                    df_train = pd.read_csv(DATA_PATH)
                    if "rainfall_mm" in df_train.columns and "rainfall" in df_train.columns:
                        df_train = df_train.drop(columns=["rainfall_mm"])
                m, new_metrics, new_medians = train_ensemble(df_train)
                from src.model_training import save_model
                save_model(m, new_metrics, new_medians, MODEL_DIR)
                get_model.clear()
                cached_evaluation.clear()
                load_stored_metrics.clear()
                st.success(f"Done — F1: {new_metrics['f1']:.3f}")
                st.rerun()

    return city, temperature, humidity, pressure, dew_point, wind_speed, elapsed_seconds, effective_key, lang


# ─────────────────────────────────────────────────────────────────────────────
# TAB: Overview
# ─────────────────────────────────────────────────────────────────────────────

def tab_overview(metrics: dict, result: PredictionResult | None, city: str, lang: str = "en"):
    render_problem_solution()
    render_pipeline_diagram()
    render_section("Model performance (hold-out)")
    render_impact_panel(metrics)

    if result is not None:
        render_section(f"Live snapshot — {city}")
        render_metric_row([
            (t("ui.rain_probability", lang), f"{result.ml_prob * 100:.1f}%", "RF + GB ensemble"),
            (t("ui.humidity_score", lang), f"{result.mias_factor:.3f}×", "HIE A×S×T"),
            (t("ui.flood_risk", lang), f"{result.adjusted_score * 100:.0f}%", result.tier.name),
            (t("ui.confidence", lang), f"{result.confidence_pct:.0f}%", f"σ={result.prob_std:.3f}"),
        ])
        st.markdown("<br>", unsafe_allow_html=True)
        render_tier_pill(result.tier, result.adjusted_score * 100)
        st.markdown("<br>", unsafe_allow_html=True)
        render_confidence_meter(result.adjusted_score * 100, result.confidence_pct, result.tier)




# ─────────────────────────────────────────────────────────────────────────────
# TAB: Live Intelligence
# ─────────────────────────────────────────────────────────────────────────────

def tab_live_intel(
    model, result: PredictionResult, city: str,
    temperature, humidity, pressure, dew_point, wind_speed, features,
    lang: str = "en",
):
    demo_id = st.session_state.get("demo_active")
    if demo_id and demo_id in DEMO_SCENARIOS:
        s = DEMO_SCENARIOS[demo_id]
        render_demo_callout(s.title, s.description, s.tab_hint)

    render_section("Live climate intelligence")
    render_metric_row([
        (t("ui.rain_probability", lang), f"{result.ml_prob * 100:.1f}%", "Ensemble mean"),
        (t("ui.humidity_score", lang), f"{result.mias_factor:.3f}×", "Humidity amplification"),
        (t("ui.flood_risk", lang), i18n_tier_name(result.tier.name, lang), f"{result.adjusted_score * 100:.0f}% score"),
        ("Drought stress", f"{result.drought_score * 100:.0f}%", f"HIE {drought_factor(humidity, result.mxene.elapsed_seconds if result.mxene else DEFAULT_ELAPSED_SECONDS):.3f}×"),
        (t("ui.confidence", lang), f"{result.confidence_pct:.0f}%", "Inter-model agreement"),
    ])

    if result.mxene:
        mx = result.mxene
        st.caption(
            f"HIE pipeline: **A**={mx.activation:.3f} × **S**={mx.saturation:.3f} × "
            f"**T**={mx.time_response:.3f} → Response={mx.combined:.3f}"
        )

    # Confidence meter
    render_confidence_meter(result.adjusted_score * 100, result.confidence_pct, result.tier)

    shap_df = get_shap_contributions(model, features)
    top_feat = None
    if shap_df is not None:
        top_feat = list(zip(shap_df["feature"].head(3), shap_df["shap_value"].head(3), strict=False))

    # Resolve hazard label for narrative
    _hazard_label = "flood/rain"
    try:
        _prof = get_profile(city)
        if _prof:
            _hazard_label = _prof.primary_hazard.value.lower().split("/")[0].strip()
    except Exception:
        pass

    summary = build_alert_summary(
        city, result, humidity=humidity, temperature=temperature,
        top_features=top_feat, hazard_label=_hazard_label,
    )
    st.info(f"**Natural language alert:** {summary}")
    render_alert_banner(result.tier, lang=lang)
    render_sms_mockup(city, result.tier.name, summary, lang=lang)

    old = st.session_state.last_tier.get(city, "Safe")
    st.session_state.alert_log = record_tier_change(
        st.session_state.alert_log, city, old, result.tier.name, summary=summary[:80]
    )
    st.session_state.last_tier[city] = result.tier.name

    g1, g2 = st.columns(2)
    with g1:
        fig = go.Figure(
            go.Indicator(
                mode="gauge+number",
                value=result.adjusted_score * 100,
                title={"text": "HIE-adjusted flood risk", "font": {"size": 14}},
                number={"suffix": "%", "font": {"size": 28}},
                gauge={
                    "axis": {"range": [0, 100]},
                    "bar": {"color": result.tier.hex_color, "thickness": 0.25},
                    "steps": [
                        {"range": [0, 20], "color": "#dcfce7"},
                        {"range": [20, 40], "color": "#fef9c3"},
                        {"range": [40, 60], "color": "#ffedd5"},
                        {"range": [60, 80], "color": "#fee2e2"},
                        {"range": [80, 100], "color": "#fecaca"},
                    ],
                },
            )
        )
        fig.update_layout(height=300)
        st.plotly_chart(apply_plotly_theme(fig), use_container_width=True)

        tier_df = pd.DataFrame(
            {"tier": list(result.tier_probs.keys()), "probability": list(result.tier_probs.values())}
        )
        fig_t = px.bar(tier_df, x="tier", y="probability", color="tier", title="Risk tier distribution")
        st.plotly_chart(apply_plotly_theme(fig_t), use_container_width=True)

    with g2:
        elapsed = result.mxene.elapsed_seconds if result.mxene else DEFAULT_ELAPSED_SECONDS
        curves = mxene_curve(elapsed_seconds=elapsed)
        fig_m = go.Figure()
        fig_m.add_trace(go.Scatter(x=curves["humidity"], y=curves["activation"], name="Activation A(RH)", line=dict(dash="dot")))
        fig_m.add_trace(go.Scatter(x=curves["humidity"], y=curves["saturation"], name="Saturation S(RH)", line=dict(dash="dash")))
        fig_m.add_trace(go.Scatter(x=curves["humidity"], y=curves["combined"], name="A×S×T", line=dict(width=3)))
        fig_m.add_trace(go.Scatter(x=curves["humidity"], y=curves["amplification"], name="HIE factor"))
        fig_m.add_vline(x=humidity, line_dash="dash", line_color="#ef4444", annotation_text="Current RH")
        fig_m.add_vline(x=60, line_dash="dot", line_color="#64748b", annotation_text="RHc=60")
        fig_m.update_layout(
            title="HIE (MXene) response curves",
            xaxis_title="Relative humidity (%)",
            yaxis_title="Response / factor",
            height=320,
        )
        st.plotly_chart(apply_plotly_theme(fig_m), use_container_width=True)
        if result.mxene:
            st.code(formula_display(result.mxene), language="text")
        else:
            st.code(mias_formula_display(humidity, elapsed), language="text")

    if shap_df is not None:
        render_section("SHAP explainability")
        fig_s = px.bar(
            shap_df.sort_values("shap_value"),
            x="shap_value",
            y="feature",
            orientation="h",
            color="shap_value",
            color_continuous_scale="RdBu",
            title="Feature contributions (Random Forest)",
        )
        st.plotly_chart(apply_plotly_theme(fig_s), use_container_width=True)
    else:
        st.caption("Install `shap` for per-prediction explainability.")


# ─────────────────────────────────────────────────────────────────────────────
# TAB: 72h Forecast
# ─────────────────────────────────────────────────────────────────────────────

def tab_forecast(model, city: str, api_key: str):
    render_section("48–72 hour early warning trajectory")
    if st.button("Load OpenWeather forecast", type="primary"):
        try:
            windows = fetch_forecast(city, api_key or None, hours=72)
            st.session_state["forecast_windows"] = windows
        except Exception as e:
            st.error(str(e))
            return

    windows = st.session_state.get("forecast_windows")
    if not windows:
        st.info("Load forecast to score each 3-hour window with ML + HIE.")
        return

    rows = []
    first_warning = None
    for w in windows:
        r = predict(
            model, w["temperature"], w["humidity"], w["pressure"], w["dew_point"], w["wind_speed"],
            elapsed_seconds=DEFAULT_ELAPSED_SECONDS,
        )
        rows.append({
            "time": w["time"],
            "risk_pct": r.adjusted_score * 100,
            "tier": r.tier.name,
            "rain_mm": w.get("rain_mm", 0),
            "humidity": w["humidity"],
        })
        if first_warning is None and r.tier.name in ("Warning", "Emergency"):
            first_warning = w["time"]

    df = pd.DataFrame(rows)
    fig = px.line(df, x="time", y="risk_pct", markers=True, title="HIE-adjusted risk — next 72 hours")
    for thresh in [20, 40, 60, 80]:
        fig.add_hline(y=thresh, line_dash="dot", line_color="#94a3b8", opacity=0.35)
    st.plotly_chart(apply_plotly_theme(fig), use_container_width=True)
    st.dataframe(df, use_container_width=True, hide_index=True)
    if first_warning:
        st.warning(f"First Warning/Emergency window: **{first_warning}**")
    else:
        st.success("No Warning/Emergency crossing in the forecast window.")


# ─────────────────────────────────────────────────────────────────────────────
# TAB: India Flood Heatmap
# ─────────────────────────────────────────────────────────────────────────────

def tab_india_map(model, api_key: str, elapsed_seconds: float):
    render_section("Live Multi-Hazard Risk Heatmap")
    st.caption(
        "Color-coded risk overlay for India + Central Asia — "
        "🟢 Safe · 🟡 Advisory · 🟠 Watch · 🔴 Warning · ⬛ Emergency."
    )

    cities = load_india_cities()
    if cities.empty:
        st.warning("Missing `data/combined_cities.csv`")
        return
    if not api_key:
        st.warning("Set `OPENWEATHER_API_KEY` in `.env` for the live map.")

    city_list = cities["city"].tolist()
    default_pick = [
        c for c in [
            "Mumbai", "Delhi", "Chennai", "Kolkata",
            "Almaty", "Tashkent", "Bishkek", "Dushanbe",
            "Ashgabat", "Baku", "Ulaanbaatar", "Kabul",
        ] if c in city_list
    ]
    selected = st.multiselect(
        "Cities to fetch",
        city_list,
        default=default_pick or city_list[:8],
        max_selections=15,
    )

    if st.button("🗺️ Refresh live heatmap", type="primary", disabled=not selected or not api_key):
        with st.spinner(f"Fetching {len(selected)} cities…"):
            try:
                risk_df = fetch_live_city_risks(model, cities, selected, api_key, elapsed_seconds=elapsed_seconds)
                st.session_state["live_map_df"] = risk_df
                for e in getattr(risk_df, "attrs", {}).get("errors", []):
                    st.warning(e)
            except Exception as e:
                st.error(str(e))
                return

    risk_df = st.session_state.get("live_map_df")
    if risk_df is None or risk_df.empty:
        st.info("Select cities and refresh the heatmap.")
        return

    components.html(build_india_map(risk_df), height=540, scrolling=False)
    st.dataframe(risk_df, use_container_width=True, hide_index=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB: Historical Flood Replay
# ─────────────────────────────────────────────────────────────────────────────

_REPLAY_SCENARIOS = [
    "2024 Kyrgyzstan Spring Floods",
    "2015 Tbilisi Flash Flood",
    "2024 Kazakhstan Spring Flooding",
]

_REPLAY_CONTEXT = {
    "2024 Kyrgyzstan Spring Floods": (
        "Spring 2024 brought glacial melt and heavy rainfall to Kyrgyzstan, triggering widespread "
        "flooding across the Chui Valley and Bishkek region."
    ),
    "2015 Tbilisi Flash Flood": (
        "June 2015 saw the Vere River burst its banks after torrential rain, flooding central Tbilisi "
        "and devastating the city zoo — one of Georgia's worst urban flood disasters."
    ),
    "2024 Kazakhstan Spring Flooding": (
        "April 2024 brought the largest floods in 80 years to northern Kazakhstan, with over 100,000 "
        "people evacuated across Aktobe and surrounding regions."
    ),
}


def tab_historical_replay(model, elapsed_seconds: float):
    render_section("Historical Flood Replay")
    st.caption(
        "Replay documented India and Central Asia flood events through the ClimaXene prediction engine "
        "to validate HIE-adjusted tier classifications."
    )

    if not EVENTS_PATH.exists():
        st.warning("Missing `data/combined_historical_events.json`")
        return

    events = load_events(EVENTS_PATH)

    # ── Scenario picker (focused on the 3 PDF events) ──────────────────────
    replay_names = [e["name"] for e in events if e["name"] in _REPLAY_SCENARIOS]
    # show the required 3 first, then extras
    extras = [e["name"] for e in events if e["name"] not in _REPLAY_SCENARIOS]
    all_names = replay_names + extras

    selected_event_name = st.selectbox("Select historical event to replay", all_names)
    event = next((e for e in events if e["name"] == selected_event_name), None)

    if event is None:
        st.warning("Event not found.")
        return

    st.divider()

    # ── Step 1: Historical context ─────────────────────────────────────────
    st.markdown("#### Step 1 — Historical Context")
    context = _REPLAY_CONTEXT.get(event["name"], "")
    if context:
        st.info(context)

    col_info1, col_info2, col_info3 = st.columns(3)
    col_info1.metric("Date", event["date"])
    col_info2.metric("City", event["city"])
    from src.historical_validation import event_rainfall_mm, event_temperature

    rain_mm = event_rainfall_mm(event)
    event_temp = event_temperature(event)
    col_info3.metric("Rainfall", f"{rain_mm:.0f} mm")

    # ── Step 2: Historical conditions ─────────────────────────────────────
    st.markdown("#### Step 2 — Historical Conditions")
    cond_c1, cond_c2, cond_c3 = st.columns(3)
    cond_c1.metric("Temperature", f"{event_temp} °C")
    cond_c1.metric("Humidity", f"{event['humidity']} %")
    cond_c2.metric("Pressure", f"{event['pressure']} hPa")
    cond_c2.metric("Dew Point", f"{event['dew_point']} °C")
    cond_c3.metric("Wind Speed", f"{event['wind_speed']} km/h")
    cond_c3.metric("Expected tier (min)", event["expected_min_tier"])

    # ── Step 3: Run prediction engine ─────────────────────────────────────
    st.markdown("#### Step 3 — CFIS Prediction Engine")

    from src.mias import compute_cfis, final_risk_score
    from src.risk_scoring import classify_risk

    features = build_single_row(
        event_temp, event["humidity"],
        event["pressure"], event["dew_point"], event["wind_speed"],
    )
    ml_prob = float(model.predict_proba(features)[0][1])
    ml_prob = min(ml_prob + min(rain_mm / 150 * 0.2, 0.35), 1.0)
    mx = mxene_response(event["humidity"], elapsed_seconds)
    cfis = compute_cfis(
        event["humidity"],
        elapsed_seconds,
        rainfall=rain_mm,
        rainfall_3d=event.get("rainfall_3d"),
        rainfall_7d=event.get("rainfall_7d"),
        rainfall_14d=event.get("rainfall_14d"),
        pressure_change=event.get("pressure_change"),
    )
    adjusted = final_risk_score(
        ml_prob,
        event["humidity"],
        elapsed_seconds,
        rainfall=rain_mm,
        rainfall_3d=event.get("rainfall_3d"),
        rainfall_7d=event.get("rainfall_7d"),
        rainfall_14d=event.get("rainfall_14d"),
        pressure_change=event.get("pressure_change"),
    )
    tier = classify_risk(adjusted)

    render_metric_row([
        ("ML rain probability", f"{ml_prob * 100:.1f}%", "With rainfall boost"),
        ("CFIS amplification", f"{cfis.amplification:.3f}×", f"CFIS={cfis.cfis:.3f}"),
        ("Adjusted risk score", f"{adjusted * 100:.1f}%", "CFIS-amplified"),
    ])
    st.code(formula_display(mx, cfis), language="text")

    # ── Step 4: Alert level outcome ────────────────────────────────────────
    st.markdown("#### Step 4 — Predicted Alert Level & Outcome")
    from src.historical_validation import TIER_RANK as tr
    expected_min = event["expected_min_tier"]
    passed = tr[tier.name] >= tr[expected_min]

    result_col, outcome_col = st.columns(2)
    with result_col:
        render_tier_pill(tier, adjusted * 100)
        render_alert_banner(tier)
    with outcome_col:
        if passed:
            st.success(
                f"✅ **PASS** — Predicted tier **{tier.name}** meets or exceeds "
                f"expected minimum **{expected_min}**"
            )
        else:
            st.error(
                f"❌ **FAIL** — Predicted **{tier.name}** is below expected minimum **{expected_min}**. "
                f"Consider retraining on `data/combined_imd_export.csv`."
            )

    # ── Summary validation table ───────────────────────────────────────────
    st.divider()
    st.markdown("#### All Event Validation Summary")
    df = validate_events(model, events, elapsed_seconds=elapsed_seconds)
    passed_count = int(df["passed"].sum())
    pct = 100 * passed_count / len(df) if len(df) else 0
    render_metric_row([
        ("Events validated", f"{passed_count}/{len(df)}", "IMD-documented extremes"),
        ("Pass rate", f"{pct:.0f}%", "Tier ≥ expected minimum"),
        ("Pipeline", "ML + HIE", f"t={elapsed_seconds}s"),
    ])

    fig = px.bar(
        df,
        x="event",
        y="risk_pct",
        color="passed",
        color_discrete_map={True: "#22c55e", False: "#ef4444"},
        title="Risk score vs documented extreme events",
    )
    fig.update_layout(xaxis_tickangle=-25, height=380)
    st.plotly_chart(apply_plotly_theme(fig), use_container_width=True)
    st.dataframe(df, use_container_width=True, hide_index=True)


# ─────────────────────────────────────────────────────────────────────────────
# TAB: AI Recommendations
# ─────────────────────────────────────────────────────────────────────────────

_RICH_RECOMMENDATIONS: dict[str, list[str]] = {
    "Safe": [
        "✅ Conditions are stable — no protective action required.",
        "📡 Monitor IMD weather bulletins every 24 hours.",
        "🔋 Keep emergency kit charged and accessible as general practice.",
        "📱 Stay subscribed to local disaster authority alerts.",
    ],
    "Advisory": [
        "⚠️ Elevated moisture detected — prepare now, not later.",
        "🎒 Prepare a 72-hour emergency kit: water, food, torch, first-aid.",
        "🔐 Secure outdoor furniture, loose items, and drain covers.",
        "📻 Tune into IMD app and local news for evolving updates.",
        "🏠 Check if your home is in a flood-prone zone.",
    ],
    "Watch": [
        "🟠 Moderate flood risk — take precautionary action today.",
        "📦 Move important documents, medicines, and valuables to higher floor.",
        "🚗 Avoid parking vehicles near drainage channels or underpasses.",
        "👨‍👩‍👧 Brief family members on evacuation plan and meeting point.",
        "⛽ Keep vehicle fuel above half for quick departure.",
        "🧱 Consider sand-bagging vulnerable doorways.",
    ],
    "Warning": [
        "🔴 HIGH RISK — take immediate protective action.",
        "🚫 Avoid all flood-prone zones, underpasses, and low-lying roads.",
        "🛡️ Sandbag doors; disconnect electrical appliances near ground level.",
        "📞 Put emergency contacts on speed dial: 112, 108, local SDMA.",
        "📦 Pack evacuation bag — documents, water, medicine, cash.",
        "👁️ Monitor local authorities for imminent evacuation orders.",
    ],
    "Emergency": [
        "🆘 EVACUATE IMMEDIATELY — life-threatening conditions.",
        "🏃 Leave low-lying areas NOW. Do not wait for water to rise.",
        "📞 Call 112 (Emergency) or 108 (NDRF/Ambulance) for rescue.",
        "🚫 Do NOT wade through floodwater — 6 inches can knock you down.",
        "🗺️ Follow OFFICIAL evacuation routes only — avoid shortcuts.",
        "🏥 Move to the nearest designated shelter with supplies.",
        "🔋 Keep phone charged; share location with family.",
    ],
}

# ── Multi-hazard recommendation sets ──────────────────────────────────────────

_RICH_RECOMMENDATIONS_BY_HAZARD: dict = {
    HazardType.FLOOD: _RICH_RECOMMENDATIONS,  # original India flood recs

    HazardType.SNOWFALL: {
        "Safe": [
            "✅ No significant snowfall risk. Normal conditions.",
            "📡 Monitor weather forecasts — conditions can change quickly.",
            "🔋 Keep emergency kit charged and vehicle supplied.",
        ],
        "Advisory": [
            "❄️ Light snow possible — check vehicle tyres and carry blankets.",
            "⛽ Fill fuel tank; stock 48h food and water at home.",
            "📻 Monitor local weather bulletins for snowfall updates.",
            "🧤 Dress in warm layers if going outdoors.",
        ],
        "Watch": [
            "🟠 Heavy snowfall expected — limit all non-essential travel.",
            "🔥 Ensure heating systems are functioning; stock extra fuel.",
            "🏠 Insulate windows and doors; protect outdoor pipes.",
            "📦 Move vehicles to sheltered or elevated ground.",
            "👥 Check on elderly and vulnerable neighbours.",
        ],
        "Warning": [
            "🔴 Blizzard conditions likely — stay indoors.",
            "🚗 DO NOT attempt road travel — roads may close.",
            "❄️ Risk of structural damage from snow load — clear roofs cautiously.",
            "🕯️ Power cuts possible — prepare candles, torches and warm clothing.",
            "📞 Keep emergency contacts ready: 112 (emergency).",
        ],
        "Emergency": [
            "🆘 BLIZZARD EMERGENCY — whiteout conditions possible.",
            "🏠 Stay sheltered; do NOT go outside unless life-threatening emergency.",
            "🔥 Conserve heat — seal draughts; avoid carbon monoxide from indoor heaters.",
            "📞 Call emergency services if trapped or in medical distress.",
            "❌ Do NOT attempt to rescue others without professional help.",
        ],
    },

    HazardType.SANDSTORM: {
        "Safe": [
            "✅ Clear air quality. No dust storm risk.",
            "📡 Monitor wind speed forecasts in arid season.",
            "😷 Keep N95 masks accessible during dry season.",
        ],
        "Advisory": [
            "🌪️ Dusty conditions possible — wear a mask if outdoors.",
            "🚗 Reduce driving speed; clean air filters regularly.",
            "🪟 Check window and door seals; prepare damp cloths for gaps.",
            "💧 Store extra drinking water — dust may affect supplies.",
        ],
        "Watch": [
            "🟠 Sandstorm likely — minimise outdoor time.",
            "🪟 Seal windows and door gaps with wet towels or tape.",
            "😷 Wear N95 mask and goggles if outdoor travel is necessary.",
            "🚗 If driving: slow down, turn on hazard lights, be ready to pull over.",
            "💨 Secure loose outdoor objects — furniture, tools, vehicles.",
        ],
        "Warning": [
            "🔴 SANDSTORM WARNING — stay indoors immediately.",
            "🚫 Do NOT drive during the storm — zero visibility risk.",
            "😷 Protect airways; cover face with damp cloth if caught outside.",
            "🏠 Keep all windows and doors shut; block draughts.",
            "💊 Have asthma/respiratory medication easily accessible.",
        ],
        "Emergency": [
            "🆘 EXTREME SANDSTORM — life-threatening visibility and air quality.",
            "🏠 Do NOT leave shelter for any reason.",
            "🚗 If in a vehicle: pull off road, engine off, stay inside with windows up.",
            "😷 Protect all exposed skin and airways — use wet cloth over face.",
            "📞 Call 112 if experiencing breathing difficulties or trapped.",
        ],
    },

    HazardType.HEAT: {
        "Safe": [
            "✅ Temperature within safe range. Stay hydrated.",
            "🌊 Enjoy shade during peak afternoon hours.",
            "📡 Monitor forecasts — temperatures can rise rapidly.",
        ],
        "Advisory": [
            "🌡️ Heat advisory — drink water regularly even without thirst.",
            "🕐 Avoid outdoor work between 11:00 and 17:00.",
            "🪟 Use curtains/blinds to block direct sunlight indoors.",
            "👴 Check on elderly, children and outdoor workers.",
        ],
        "Watch": [
            "🟠 Dangerous heat watch — limit all strenuous outdoor activity.",
            "💧 Drink 2–3 litres of water per day; include electrolyte drinks.",
            "🏢 Identify nearest cooling centre (library, mall, community hall).",
            "🐾 Keep pets and livestock in cool, shaded areas with water.",
            "🌡️ Watch for heat exhaustion signs: heavy sweating, weakness, nausea.",
        ],
        "Warning": [
            "🔴 DANGEROUS HEAT — minimise all outdoor exposure.",
            "🏥 Heat stroke is a medical emergency: confusion, no sweating, hot dry skin.",
            "❄️ Use fans + damp cloths on neck/wrists; avoid ice baths (shock risk).",
            "📞 Call emergency services immediately for suspected heat stroke.",
            "💧 Rehydrate steadily — do not drink very large amounts at once.",
        ],
        "Emergency": [
            "🆘 EXTREME HEAT EMERGENCY — life-threatening conditions.",
            "🏢 Move to air-conditioned or cool space IMMEDIATELY.",
            "🧊 Apply cool (not ice cold) water to skin; fan vigorously.",
            "📞 Call 112 for heat stroke — body temp >40°C is a medical emergency.",
            "🚫 Do NOT leave children or elderly in vehicles.",
        ],
    },

    HazardType.LANDSLIDE: {
        "Safe": [
            "✅ Slopes stable. Normal conditions.",
            "📡 Monitor rainfall forecasts — landslides follow heavy rain.",
            "🏔️ Learn if your property is on a landslide-prone slope.",
        ],
        "Advisory": [
            "⛰️ Moderate rain + slopes — watch for early signs.",
            "🔍 Check for new cracks in walls, tilting trees, unusual water seepage.",
            "🚗 Avoid parking near hillsides, gorges and unstable slopes.",
            "📦 Move valuables away from ground floor in slope-side homes.",
        ],
        "Watch": [
            "🟠 Landslide watch — take precautionary action.",
            "🏃 Prepare to evacuate homes on hillsides or in valleys.",
            "🚫 Avoid river gorges and mountain roads after heavy rain.",
            "👂 Listen for rumbling sounds — they precede debris flows.",
            "📞 Inform family members of your location and evacuation plan.",
        ],
        "Warning": [
            "🔴 LANDSLIDE WARNING — evacuate vulnerable slope-side properties NOW.",
            "🗺️ Move to official evacuation areas on flat, stable ground.",
            "🚫 Avoid all mountain roads, gorges and valley floors.",
            "📞 Call 112 and inform local disaster management authority.",
            "🏃 Move perpendicular to slope direction — never directly down.",
        ],
        "Emergency": [
            "🆘 ACTIVE LANDSLIDE RISK — evacuate IMMEDIATELY.",
            "🏃 Move perpendicular to the slide, to high ground on stable terrain.",
            "🚫 Do NOT re-enter affected areas — secondary slides common.",
            "📞 Call 112 for rescue. Report trapped persons immediately.",
            "⚡ Watch for broken power lines and ruptured gas pipes.",
        ],
    },

    HazardType.FROST: {
        "Safe": [
            "✅ Above freezing. No frost risk.",
            "📡 Monitor nighttime temperature forecasts.",
            "🔋 Keep emergency heating fuel at a comfortable stock level.",
        ],
        "Advisory": [
            "🥶 Frost possible overnight — protect water pipes.",
            "🌿 Cover sensitive plants and outdoor crops.",
            "🚗 Check antifreeze levels in vehicle. Morning ice possible.",
            "🧣 Dress in warm layers when going out.",
        ],
        "Watch": [
            "🟠 Hard frost expected — protect infrastructure.",
            "🔧 Insulate exposed outdoor pipes with foam or cloth.",
            "🔥 Test heating systems; stock additional fuel.",
            "🐄 Ensure livestock have sheltered housing and unfrozen water.",
            "⛽ Fill vehicle fuel tank; reduce battery drain with engine warm-up.",
        ],
        "Warning": [
            "🔴 SEVERE FROST — infrastructure at risk.",
            "💧 Turn off outdoor taps; drain exposed pipes.",
            "🏠 Seal all gaps and draughts in your home.",
            "🚗 Avoid travel on icy roads; carry emergency blankets.",
            "📞 Report burst water mains and downed power lines to authorities.",
        ],
        "Emergency": [
            "🆘 EXTREME FREEZE — life-threatening cold.",
            "🏠 Stay indoors; never use outdoor heaters inside (CO risk).",
            "💊 Watch for hypothermia signs: intense shivering, confusion, slurred speech.",
            "📞 Call 112 if pipes burst catastrophically or someone is in cold distress.",
            "🧥 Layer maximum clothing; share body heat in group settings.",
        ],
    },

    HazardType.DROUGHT: {
        "Safe": [
            "✅ Moisture levels adequate. No drought stress.",
            "💧 Follow standard water conservation practices.",
        ],
        "Advisory": [
            "☀️ Below-normal moisture — begin water conservation.",
            "🚿 Reduce non-essential water use: shorter showers, less irrigation.",
            "🌾 Monitor crop and livestock water needs closely.",
        ],
        "Watch": [
            "🟠 Drought watch — implement water conservation measures.",
            "💧 Collect and reuse grey water for non-drinking purposes.",
            "🔧 Repair all leaking taps, pipes and cisterns immediately.",
            "🌳 Mulch soil around plants to retain moisture.",
            "🔥 Wildfire risk rising — maintain clear firebreaks.",
        ],
        "Warning": [
            "🔴 SEVERE DROUGHT — emergency water rationing advised.",
            "🚰 Follow government water-rationing guidelines strictly.",
            "💊 Protect food supplies from heat-induced spoilage.",
            "😷 Dust levels rising — use masks during outdoor activity.",
            "🐄 Supplement livestock feed; may need emergency water trucking.",
        ],
        "Emergency": [
            "🆘 CRITICAL DROUGHT — water supply may fail.",
            "📞 Contact local authorities for emergency water distribution.",
            "🔥 Wildfire danger: do not burn waste or use open flames outdoors.",
            "💧 Prioritise drinking water above all other uses.",
            "📡 Follow all government emergency orders on water use.",
        ],
    },
}


def tab_recommendations(result: PredictionResult, city: str, lang: str = "en",
                         hazard_profile=None,
                         primary_score: float = 0.0,
                         secondary_score: float | None = None):
    render_section("AI Recommendation Engine")
    st.caption(
        "Actionable guidance generated based on the current risk tier and city hazard profile. "
        "Localised to your selected language."
    )

    tier = result.tier
    ht = hazard_profile.primary_hazard if hazard_profile else HazardType.FLOOD
    meta = HAZARD_META[ht]

    # Show hazard type badge
    st.markdown(
        f"<div style='background:{meta.color}18;border-left:4px solid {meta.color};"
        f"padding:0.5rem 0.85rem;border-radius:8px;margin-bottom:0.5rem;'>"
        f"<b>{meta.icon} Primary hazard for {city}: {ht.value}</b></div>",
        unsafe_allow_html=True,
    )

    # Pick recommendations based on hazard type
    hazard_recs = _RICH_RECOMMENDATIONS_BY_HAZARD.get(ht, _RICH_RECOMMENDATIONS)
    bullets = hazard_recs.get(tier.name, [])

    render_alert_banner(tier, lang=lang)
    st.markdown(f"**🏙️ City:** {city}")
    render_confidence_meter(result.adjusted_score * 100, result.confidence_pct, tier)

    # Show secondary hazard advisory if significant
    if hazard_profile and hazard_profile.secondary_hazard and secondary_score is not None and secondary_score > 0.3:
        sec_meta = HAZARD_META[hazard_profile.secondary_hazard]
        st.info(
            f"{sec_meta.icon} **Secondary risk alert:** "
            f"{hazard_profile.secondary_hazard.value} score is "
            f"**{secondary_score * 100:.0f}%** — monitor conditions."
        )

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown(
        f"<p style='font-size:1.05rem;font-weight:700;color:#0f172a;'>"
        f"{meta.icon} Recommended Actions — {i18n_tier_name(tier.name, lang)}</p>",
        unsafe_allow_html=True,
    )
    for b in bullets:
        st.markdown(
            f'<div style="padding:0.5rem 0.85rem;margin:0.3rem 0;border-radius:8px;'
            f'background:{tier.hex_color}0f;border-left:4px solid {tier.hex_color};'
            f'font-size:0.95rem;color:#1e293b;">{b}</div>',
            unsafe_allow_html=True,
        )

    # All-tier reference table
    with st.expander("📋 View recommendations for all risk tiers"):
        for tier_key, tier_bullets in hazard_recs.items():
            from src.risk_scoring import TIERS
            tier_obj = next((tobj for tobj in TIERS if tobj.name == tier_key), None)
            color = tier_obj.hex_color if tier_obj else "#94a3b8"
            st.markdown(
                f"<div style='font-weight:700;color:{color};margin:0.75rem 0 0.3rem;'>"
                f"{i18n_tier_name(tier_key, lang)}</div>",
                unsafe_allow_html=True,
            )
            for b in tier_bullets:
                st.markdown(f"- {b}")


# ─────────────────────────────────────────────────────────────────────────────
# TAB: Emergency Command Center
# ─────────────────────────────────────────────────────────────────────────────

def tab_command_center(result: PredictionResult, city: str, lang: str = "en"):
    render_section("Emergency Command Center")
    render_command_center(city, result, lang=lang)


# ─────────────────────────────────────────────────────────────────────────────
# TAB: AI Disaster Assistant
# ─────────────────────────────────────────────────────────────────────────────

def tab_disaster_assistant(result: PredictionResult, city: str,
                           hazard_profile=None, primary_score: float = 0.0,
                           secondary_score: float | None = None):
    render_section("🤖 AI Disaster Assistant")

    # Resolve hazard context
    ht = hazard_profile.primary_hazard if hazard_profile else HazardType.FLOOD
    country = hazard_profile.country if hazard_profile else "India"
    secondary_ht = hazard_profile.secondary_hazard if hazard_profile else None
    meta = HAZARD_META[ht]

    # Hazard badge
    st.markdown(
        f"<div style='background:{meta.color}22;border-left:4px solid {meta.color};"
        f"padding:0.5rem 0.85rem;border-radius:8px;margin-bottom:0.75rem;'>"
        f"<b>{meta.icon} Primary hazard for {city}: {ht.value}</b><br>"
        f"<span style='font-size:0.85rem;color:#475569;'>{meta.description}</span></div>",
        unsafe_allow_html=True,
    )

    st.caption(
        f"Ask about {ht.value.lower()} safety, current risk, emergency actions, or disaster preparedness. "
        "Powered by NOVASENSE multi-hazard rule-based AI."
    )

    # Suggested prompts — hazard-aware labels
    c1, c2, c3, c4 = st.columns(4)
    hazard_label = ht.value.split("/")[0].strip().lower()
    if c1.button(f"💬 {ht.value.split('/')[0]} tips", use_container_width=True):
        st.session_state["chat_prefill"] = f"What should I do during a {hazard_label}?"
    if c2.button("📊 Explain current risk", use_container_width=True):
        st.session_state["chat_prefill"] = "Explain current risk"
    if c3.button("🚨 Emergency actions", use_container_width=True):
        st.session_state["chat_prefill"] = "What are the emergency actions?"
    if c4.button("📞 Emergency contacts", use_container_width=True):
        st.session_state["chat_prefill"] = "Emergency contact numbers"

    st.divider()

    # Chat history display
    for msg in st.session_state.get("chat_history", []):
        if msg["role"] == "user":
            st.markdown(
                f'<div class="ns-chat-bubble-user">👤 {msg["content"]}</div>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                f'<div class="ns-chat-bubble-bot">🤖 {msg["content"]}</div>',
                unsafe_allow_html=True,
            )

    # Pre-fill from quick buttons
    prefill = st.session_state.pop("chat_prefill", "")

    user_input = st.chat_input("Ask the disaster assistant…", key="assistant_input")
    if not user_input and prefill:
        user_input = prefill

    if user_input:
        response = assistant_response(
            user_input,
            city=city,
            tier_name=result.tier.name,
            risk_pct=result.adjusted_score * 100,
            ml_prob=result.ml_prob,
            mias_factor=result.mias_factor,
            confidence=result.confidence_pct,
            hazard_type=ht,
            country=country,
            secondary_hazard=secondary_ht,
            primary_score=primary_score,
            secondary_score=secondary_score,
        )
        st.session_state["chat_history"].append({"role": "user", "content": user_input})
        st.session_state["chat_history"].append({"role": "assistant", "content": response})
        st.rerun()

    if st.button("🗑️ Clear chat", key="clear_chat"):
        st.session_state["chat_history"] = []
        st.rerun()


# ─────────────────────────────────────────────────────────────────────────────
# TAB: Simulate
# ─────────────────────────────────────────────────────────────────────────────

def tab_simulate(model, elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS, lang: str = "en"):
    render_section("Simulate a weather event")
    preset = st.selectbox(
        "Scenario preset",
        ["Custom", "2024 Kyrgyzstan Spring Floods", "2018 Central Asia Heatwave", "2015 Tbilisi Flash Flood"],
    )
    defaults = {
        "Custom": (28, 72, 1010, 22, 15, 40),
        "2024 Kyrgyzstan Spring Floods": (14, 88, 1007, 12, 25, 85),
        "2018 Central Asia Heatwave": (44, 18, 1008, 8, 20, 0),
        "2015 Tbilisi Flash Flood": (21, 93, 1002, 20, 40, 150),
    }
    d = defaults[preset]
    c1, c2 = st.columns(2)
    with c1:
        rainfall_mm = st.slider("Rainfall context (mm)", 0, 200, int(d[5]))
        humidity = st.slider("Humidity (%)", 0, 100, int(d[1]))
        temperature = st.slider("Temperature (°C)", -5, 48, int(d[0]))
    with c2:
        soil_moisture = st.slider("Soil moisture index", 0.0, 1.0, 0.6)
        river_proximity = st.slider("River proximity index", 0.0, 1.0, 0.3)
        pressure = st.number_input("Pressure (hPa)", value=float(d[2]))
        wind = st.number_input("Wind (km/h)", value=float(d[4]))
        sim_elapsed = st.slider("Sensor elapsed time t (s)", 0.0, 30.0, elapsed_seconds, 0.1)

    dew = temperature - (100 - humidity) / 5
    boost = min(rainfall_mm / 200 * 0.15 + soil_moisture * 0.1 + river_proximity * 0.12, 0.35)
    features = build_single_row(temperature, humidity, pressure, dew, wind)
    ml_prob = min(float(model.predict_proba(features)[0][1]) + boost, 1.0)
    mx = mxene_response(humidity, sim_elapsed)
    adjusted = min(ml_prob * mx.amplification, 1.0)
    from src.risk_scoring import classify_risk
    tier = classify_risk(adjusted)

    render_metric_row([
        ("ML probability", f"{ml_prob * 100:.1f}%", "With terrain boost"),
        ("HIE-adjusted", f"{adjusted * 100:.1f}%", f"×{mx.amplification:.3f}"),
        ("MXene A×S×T", f"{mx.combined:.3f}", "Combined response"),
        (t("ui.risk_level", lang), i18n_tier_name(tier.name, lang), tier_action(tier.name, lang)[:40] + "…"),
    ])
    st.code(
        f"adjusted = min(ml_prob × hie_factor, 1)\n"
        f"         = min({ml_prob:.4f} × {mx.amplification:.4f}, 1) = {adjusted:.4f}\n"
        f"{formula_display(mx)}",
        language="text",
    )
    render_alert_banner(tier, lang=lang)


# ─────────────────────────────────────────────────────────────────────────────
# TAB: Model & Trust
# ─────────────────────────────────────────────────────────────────────────────

def tab_model_trust(model, metrics: dict):
    render_section("Model evaluation & responsible AI")
    mtime = DATA_PATH.stat().st_mtime if DATA_PATH.exists() else 0
    ev = cached_evaluation(str(id(model)), mtime)

    t1, t2, t3, t4 = st.tabs(["Metrics", "Charts", "Bias audit", "Provenance"])

    with t1:
        if metrics:
            render_metric_row([
                ("Accuracy", f"{metrics.get('accuracy', 0):.1%}", "Hold-out"),
                ("F1", f"{metrics.get('f1', 0):.3f}", "Rain events"),
                ("Precision", f"{metrics.get('precision', 0):.3f}", ""),
                ("Recall", f"{metrics.get('recall', 0):.3f}", ""),
                ("ROC-AUC", f"{metrics.get('roc_auc', 0):.3f}", "Discrimination"),
            ])

    with t2:
        if not ev:
            st.info("Need trained model and dataset.")
            return
        c1, c2 = st.columns(2)
        with c1:
            fig_roc = go.Figure()
            fig_roc.add_trace(go.Scatter(x=ev["fpr"], y=ev["tpr"], mode="lines", name=f"AUC={ev['roc_auc']:.3f}"))
            fig_roc.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(dash="dash"), name="Random"))
            fig_roc.update_layout(title="ROC curve", xaxis_title="FPR", yaxis_title="TPR")
            st.plotly_chart(apply_plotly_theme(fig_roc), use_container_width=True)
        with c2:
            cm = np.array(ev["confusion_matrix"])
            fig_cm = px.imshow(cm, text_auto=True, labels=dict(x="Predicted", y="Actual"), title="Confusion matrix")
            st.plotly_chart(apply_plotly_theme(fig_cm), use_container_width=True)

        tier_f1 = ev.get("tier_f1", {})
        fig_tf1 = px.bar(x=list(tier_f1.keys()), y=list(tier_f1.values()), title="F1 by risk tier")
        st.plotly_chart(apply_plotly_theme(fig_tf1), use_container_width=True)

        imp = feature_importance(model)
        st.plotly_chart(
            apply_plotly_theme(px.bar(imp, x="importance", y="feature", orientation="h", title="Feature importance")),
            use_container_width=True,
        )

    with t3:
        st.markdown("**Geographic fairness** — representative profiles per climate zone")
        audit = bias_audit_by_zone(model)
        st.dataframe(audit, use_container_width=True, hide_index=True)
        st.caption("Arid zones may under-predict rain without local gauge data — documented limitation.")

    with t4:
        st.markdown(
            f"""
            | Source | Role |
            |--------|------|
            | `{DATA_PATH.name}` | **40 Indian cities**, IMD gridded daily fields (2020+) |
            | OpenWeather | Live weather + 72h forecast |
            | `historical_events.json` | Flood/heat validation against media + IMD reports |
            | HIE (Humidity Intelligence Engine) | A(RH)×S(RH)×T(t), τ={DEFAULT_TAU_SECONDS}s, default t=2s |
            | Ensemble | Random Forest + Gradient Boosting soft voting |
            """
        )


# ─────────────────────────────────────────────────────────────────────────────
# TAB: Multi-Hazard Intelligence Panel
# ─────────────────────────────────────────────────────────────────────────────

def tab_hazard_intel(
    city: str,
    cities_df: pd.DataFrame,
    temperature: float,
    humidity: float,
    pressure: float,
    dew_point: float,
    wind_speed: float,
    result,
    lang: str = "en",
):
    render_section("🌐 Multi-Hazard Intelligence")
    st.caption(
        "Each city is profiled for its primary natural hazard based on geography, climate and historical events. "
        "Weather conditions are scored against that city's specific risk model."
    )

    row = cities_df[cities_df["city"] == city]
    climate_zone = row["climate_zone"].values[0] if not row.empty else "Semi-Arid"
    profile = get_profile(city) or get_profile_by_climate(climate_zone, city)

    ht = profile.primary_hazard
    meta = HAZARD_META[ht]
    primary_score = compute_primary_score(profile, temperature, humidity, pressure, dew_point, wind_speed)
    secondary_score = compute_secondary_score(profile, temperature, humidity, pressure, dew_point, wind_speed)

    col_hdr1, col_hdr2 = st.columns([2, 1])
    with col_hdr1:
        st.markdown(
            f"<div style='background:{meta.color}18;border:1.5px solid {meta.color}44;"
            f"border-radius:12px;padding:1rem 1.25rem;'>"
            f"<div style='font-size:2rem;'>{meta.icon}</div>"
            f"<div style='font-size:1.15rem;font-weight:700;color:#0f172a;'>{ht.value}</div>"
            f"<div style='font-size:0.9rem;color:#475569;margin-top:0.25rem;'>{meta.description}</div>"
            f"<div style='margin-top:0.5rem;font-size:0.8rem;color:#94a3b8;'>Region: {profile.region} · "
            f"Country: {profile.country} · Zone: {profile.climate_zone}</div>"
            f"</div>",
            unsafe_allow_html=True,
        )
    with col_hdr2:
        if profile.secondary_hazard:
            sec_meta = HAZARD_META[profile.secondary_hazard]
            st.markdown(
                f"<div style='background:{sec_meta.color}12;border:1px solid {sec_meta.color}33;"
                f"border-radius:10px;padding:0.75rem 1rem;margin-bottom:0.5rem;'>"
                f"<div style='font-size:1.4rem;'>{sec_meta.icon}</div>"
                f"<div style='font-size:0.9rem;font-weight:600;color:#334155;'>Secondary: {profile.secondary_hazard.value}</div>"
                f"</div>",
                unsafe_allow_html=True,
            )
        if profile.primary_peak_months:
            months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
            peak_str = ", ".join(months[m - 1] for m in profile.primary_peak_months)
            st.caption(f"📅 **Peak months:** {peak_str}")

    st.divider()

    score_cols = st.columns(2 if profile.secondary_hazard else 1)
    with score_cols[0]:
        st.markdown(f"**{meta.icon} Primary: {meta.score_label}**")
        st.progress(primary_score, text=f"{primary_score * 100:.0f}%")
        tier_color = result.tier.hex_color
        st.markdown(
            f"<div style='background:{tier_color}18;border-left:3px solid {tier_color};"
            f"padding:0.4rem 0.75rem;border-radius:6px;font-size:0.9rem;'>"
            f"Tier: <b>{result.tier.name}</b></div>",
            unsafe_allow_html=True,
        )

    if profile.secondary_hazard and secondary_score is not None and len(score_cols) > 1:
        with score_cols[1]:
            sec_meta = HAZARD_META[profile.secondary_hazard]
            level = "High" if secondary_score > 0.6 else ("Moderate" if secondary_score > 0.3 else "Low")
            level_color = "#ef4444" if secondary_score > 0.6 else ("#f97316" if secondary_score > 0.3 else "#22c55e")
            st.markdown(f"**{sec_meta.icon} Secondary: {sec_meta.score_label}**")
            st.progress(secondary_score, text=f"{secondary_score * 100:.0f}%")
            st.markdown(
                f"<div style='background:{level_color}18;border-left:3px solid {level_color};"
                f"padding:0.4rem 0.75rem;border-radius:6px;font-size:0.9rem;'>"
                f"Level: <b>{level}</b></div>",
                unsafe_allow_html=True,
            )

    st.divider()

    st.markdown("**📞 Emergency Contacts**")
    for line in profile.emergency_agency.split("|"):
        st.markdown(f"- {line.strip()}")
    if profile.emergency_note:
        st.info(f"ℹ️ {profile.emergency_note}")

    st.divider()
    with st.expander("🔬 How current conditions map to this hazard"):
        cond_data = []
        if ht == HazardType.FLOOD:
            cond_data = [
                ("Humidity", f"{humidity:.0f}%", "🔴 High" if humidity > 75 else "🟡 Moderate" if humidity > 50 else "🟢 Low"),
                ("Pressure", f"{pressure:.0f} hPa", "🔴 Low (storm)" if pressure < 1005 else "🟢 Normal"),
                ("Dew Point", f"{dew_point:.1f}°C", "🔴 High" if dew_point > 18 else "🟢 OK"),
            ]
        elif ht == HazardType.SNOWFALL:
            cond_data = [
                ("Temperature", f"{temperature:.1f}°C", "🔴 Sub-zero" if temperature < 0 else "🟡 Near-zero" if temperature < 4 else "🟢 Above snow threshold"),
                ("Humidity", f"{humidity:.0f}%", "🔴 High" if humidity > 70 else "🟡 Moderate"),
                ("Wind Speed", f"{wind_speed:.0f} km/h", "🔴 Blizzard risk" if wind_speed > 50 else "🟡 Elevated" if wind_speed > 30 else "🟢 Calm"),
            ]
        elif ht == HazardType.SANDSTORM:
            cond_data = [
                ("Wind Speed", f"{wind_speed:.0f} km/h", "🔴 Storm risk" if wind_speed > 50 else "🟡 Elevated" if wind_speed > 30 else "🟢 Low"),
                ("Humidity", f"{humidity:.0f}%", "🔴 Very dry" if humidity < 20 else "🟡 Dry" if humidity < 40 else "🟢 Moist (lower risk)"),
                ("Temperature", f"{temperature:.1f}°C", "🔴 Hot + dry amplification" if temperature > 35 else "🟢 Moderate"),
            ]
        elif ht == HazardType.HEAT:
            cond_data = [
                ("Temperature", f"{temperature:.1f}°C", "🔴 Dangerous" if temperature > 40 else "🟠 High" if temperature > 35 else "🟡 Warm" if temperature > 30 else "🟢 OK"),
                ("Humidity", f"{humidity:.0f}%", "🔴 Wet bulb risk" if humidity > 60 and temperature > 32 else "🟡 Elevated" if humidity > 40 else "🟢 Low"),
            ]
        elif ht == HazardType.LANDSLIDE:
            cond_data = [
                ("Humidity", f"{humidity:.0f}%", "🔴 Saturated" if humidity > 80 else "🟡 Elevated" if humidity > 60 else "🟢 OK"),
                ("Pressure", f"{pressure:.0f} hPa", "🔴 Pressure drop = storm incoming" if pressure < 1005 else "🟢 Stable"),
            ]
        elif ht == HazardType.FROST:
            cond_data = [
                ("Temperature", f"{temperature:.1f}°C", "🔴 Hard freeze" if temperature < -5 else "🟠 Frost" if temperature < 2 else "🟢 Above freeze"),
                ("Wind Speed", f"{wind_speed:.0f} km/h", "🔴 Wind chill amplified" if wind_speed > 30 else "🟢 Moderate"),
            ]
        elif ht == HazardType.DROUGHT:
            cond_data = [
                ("Humidity", f"{humidity:.0f}%", "🔴 Severe deficit" if humidity < 20 else "🟠 Dry" if humidity < 35 else "🟢 Adequate"),
                ("Temperature", f"{temperature:.1f}°C", "🔴 Evaporation stress" if temperature > 35 else "🟢 Moderate"),
            ]
        for label, value, status in cond_data:
            st.markdown(f"- **{label}:** {value} → {status}")

    return profile, primary_score, secondary_score


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    init_session()
    render_hero()

    model, metrics, _ = get_model()
    stored = load_stored_metrics()
    display_metrics = stored or metrics

    env_key = os.getenv("OPENWEATHER_API_KEY", "").strip()
    city, temp, hum, pres, dew, wind, elapsed_seconds, api_key, lang = sidebar_inputs(env_key)

    if model is None:
        st.error("Model not found. Run setup:")
        st.code("python scripts/sync_imd_data.py\npython scripts/train_model.py", language="bash")
        return

    col_a, col_b, col_c = st.columns([3, 1, 1])
    with col_a:
        st.caption(f"Training: **{DATA_PATH.name}** · Updated **{datetime.now().strftime('%H:%M')}** session")
    with col_b:
        st.caption(f"API: {'✓' if api_key else '—'}")
    with col_c:
        if st.button("🎬 Demo Guide", help="Show 3-5 min judge demo flow"):
            st.session_state["show_demo_guide"] = not st.session_state.get("show_demo_guide", False)

    if st.session_state.get("show_demo_guide", False):
        st.markdown(
            """
            <div style="background:linear-gradient(135deg,#0e7490,#06b6d4);color:#fff;
                border-radius:12px;padding:1rem 1.5rem;margin:0.5rem 0 1rem;">
                <b style="font-size:1rem;">🎬 Judge Demo Flow — 3–5 minutes</b>
                <ol style="margin:0.5rem 0 0 1rem;line-height:2;">
                    <li><b>Live Intelligence</b> tab → Run <em>2021 Maharashtra Floods</em> scenario → Show risk gauge + HIE curves</li>
                    <li><b>Flood Heatmap</b> tab → Refresh map → Show color-coded city overlays</li>
                    <li><b>Historical Replay</b> tab → Select Kerala 2018 → Walk through steps 1–4</li>
                    <li><b>Recommendations</b> tab → Show AI guidance bullets for active tier</li>
                    <li><b>Disaster Assistant</b> tab → Ask "Explain current risk" → Ask "Emergency contacts"</li>
                    <li><b>Command Center</b> tab → Show full emergency dashboard</li>
                </ol>
            </div>
            """,
            unsafe_allow_html=True,
        )

    result = predict(model, temp, hum, pres, dew, wind, elapsed_seconds)
    features = build_single_row(temp, hum, pres, dew, wind)

    # ── Resolve hazard profile for the selected city (used across all tabs) ─
    cities_df = load_india_cities()
    _city_row = cities_df[cities_df["city"] == city]
    _climate_zone = _city_row["climate_zone"].values[0] if not _city_row.empty else "Semi-Arid"
    hazard_profile = get_profile(city) or get_profile_by_climate(_climate_zone, city)
    primary_score = compute_primary_score(hazard_profile, temp, hum, pres, dew, wind)
    secondary_score = compute_secondary_score(hazard_profile, temp, hum, pres, dew, wind)

    # Show a persistent hazard badge below the toolbar
    _ht = hazard_profile.primary_hazard
    _meta = HAZARD_META[_ht]
    _sec_badge = ""
    if hazard_profile.secondary_hazard:
        _sm = HAZARD_META[hazard_profile.secondary_hazard]
        _sec_badge = (
            f"&nbsp;·&nbsp;<span style='color:{_sm.color};'>{_sm.icon} "
            f"{hazard_profile.secondary_hazard.value} (secondary)</span>"
        )
    st.markdown(
        f"<div style='background:{_meta.color}14;border-left:4px solid {_meta.color};"
        f"padding:0.4rem 1rem;border-radius:8px;margin:0.25rem 0 0.75rem;font-size:0.9rem;'>"
        f"<b>{_meta.icon} {city} primary hazard: {_ht.value}</b>"
        f"{_sec_badge}&nbsp;·&nbsp;"
        f"<span style='color:#64748b;'>{hazard_profile.region} · {hazard_profile.country}</span>"
        f"</div>",
        unsafe_allow_html=True,
    )

    tabs = st.tabs([
        "🏠 Overview",
        "⚡ Live Intelligence",
        "🌐 Multi-Hazard",
        "🗺️ Risk Heatmap",
        "🔁 Historical Replay",
        "🛡️ Recommendations",
        "🆘 Command Center",
        "🤖 Disaster Assistant",
        "📈 72h Forecast",
        "🔬 Simulate",
        "📊 Model & Trust",
    ])

    with tabs[0]:
        tab_overview(display_metrics, result, city, lang)
    with tabs[1]:
        tab_live_intel(model, result, city, temp, hum, pres, dew, wind, features, lang)
    with tabs[2]:
        tab_hazard_intel(city, cities_df, temp, hum, pres, dew, wind, result, lang)
    with tabs[3]:
        tab_india_map(model, api_key, elapsed_seconds)
    with tabs[4]:
        tab_historical_replay(model, elapsed_seconds)
    with tabs[5]:
        tab_recommendations(
            result, city, lang,
            hazard_profile=hazard_profile,
            primary_score=primary_score,
            secondary_score=secondary_score,
        )
    with tabs[6]:
        tab_command_center(result, city, lang)
    with tabs[7]:
        tab_disaster_assistant(
            result, city,
            hazard_profile=hazard_profile,
            primary_score=primary_score,
            secondary_score=secondary_score,
        )
    with tabs[8]:
        tab_forecast(model, city, api_key)
    with tabs[9]:
        tab_simulate(model, elapsed_seconds, lang)
    with tabs[10]:
        tab_model_trust(model, display_metrics)

    render_footer()


if __name__ == "__main__":
    main()
