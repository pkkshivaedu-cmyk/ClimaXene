"""
Generate ClimaXene hackathon PowerPoint deck.
Run: python scripts/build_hackathon_ppt.py
Output: presentations/ClimaXene_Hackathon.pptx
"""

from __future__ import annotations

from pathlib import Path

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "presentations" / "ClimaXene_Hackathon.pptx"

# Brand
CYAN = RGBColor(8, 145, 178)
DARK = RGBColor(15, 23, 42)
SLATE = RGBColor(71, 85, 105)
WHITE = RGBColor(255, 255, 255)
LIGHT = RGBColor(240, 253, 250)
ACCENT = RGBColor(6, 182, 212)


def _box(slide, left, top, width, height, fill_rgb):
    shape = slide.shapes.add_shape(1, left, top, width, height)  # rectangle
    shape.fill.solid()
    shape.fill.fore_color.rgb = fill_rgb
    shape.line.fill.background()
    return shape


def _text(slide, left, top, width, height, text, size=18, bold=False, color=DARK, align=PP_ALIGN.LEFT):
    tb = slide.shapes.add_textbox(left, top, width, height)
    tf = tb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = text
    p.font.size = Pt(size)
    p.font.bold = bold
    p.font.color.rgb = color
    p.alignment = align
    tf.vertical_anchor = MSO_ANCHOR.TOP
    return tb


def slide_title(prs: Presentation):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _box(slide, Inches(0), Inches(0), Inches(10), Inches(5.625), CYAN)
    _text(slide, Inches(0.6), Inches(1.2), Inches(8.8), Inches(1.2), "ClimaXene", 44, True, WHITE, PP_ALIGN.LEFT)
    _text(
        slide, Inches(0.6), Inches(2.0), Inches(8.5), Inches(1.0),
        "Hyperlocal Climate Intelligence for India",
        22, False, LIGHT, PP_ALIGN.LEFT,
    )
    _text(
        slide, Inches(0.6), Inches(3.0), Inches(8.5), Inches(1.5),
        "Ensemble ML  ·  MIAS (MXene-Inspired Adaptive Sensing)  ·  5-Tier Early Warning\n"
        "Hackathon 2025  |  AI-Driven Flood & Rain Risk Platform",
        14, False, LIGHT, PP_ALIGN.LEFT,
    )


def slide_bullets(prs: Presentation, title: str, bullets: list[str], subtitle: str = ""):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _box(slide, Inches(0), Inches(0), Inches(10), Inches(0.9), CYAN)
    _text(slide, Inches(0.5), Inches(0.15), Inches(9), Inches(0.7), title, 28, True, WHITE)
    if subtitle:
        _text(slide, Inches(0.5), Inches(1.0), Inches(9), Inches(0.4), subtitle, 13, False, SLATE)
    y = 1.45 if subtitle else 1.15
    body = "\n".join(f"•  {b}" for b in bullets)
    _text(slide, Inches(0.55), Inches(y), Inches(8.9), Inches(4.0), body, 17, False, DARK)


def slide_metrics(prs: Presentation):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _box(slide, Inches(0), Inches(0), Inches(10), Inches(0.9), CYAN)
    _text(slide, Inches(0.5), Inches(0.15), Inches(9), Inches(0.7), "Model Performance (Hold-Out)", 28, True, WHITE)
    metrics = [
        ("ROC-AUC", "0.814", "Strong discrimination"),
        ("F1 Score", "0.627", "Rain event detection"),
        ("Accuracy", "78.0%", "46,661 train rows"),
        ("Coverage", "40 cities", "IMD hyperlocal India"),
    ]
    for i, (label, val, sub) in enumerate(metrics):
        col = i % 2
        row = i // 2
        left = Inches(0.55 + col * 4.6)
        top = Inches(1.35 + row * 2.0)
        _box(slide, left, top, Inches(4.2), Inches(1.7), LIGHT)
        _text(slide, left + Inches(0.2), top + Inches(0.15), Inches(3.8), Inches(0.4), label, 14, False, SLATE)
        _text(slide, left + Inches(0.2), top + Inches(0.5), Inches(3.8), Inches(0.7), val, 32, True, CYAN)
        _text(slide, left + Inches(0.2), top + Inches(1.2), Inches(3.8), Inches(0.4), sub, 12, False, SLATE)
    _text(
        slide, Inches(0.55), Inches(5.0), Inches(8.9), Inches(0.5),
        "Source: Random Forest + Gradient Boosting soft-voting ensemble on imd_export.csv",
        11, False, SLATE,
    )


def slide_formula(prs: Presentation):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _box(slide, Inches(0), Inches(0), Inches(10), Inches(0.9), CYAN)
    _text(slide, Inches(0.5), Inches(0.15), Inches(9), Inches(0.7), "MIAS — Our Innovation", 28, True, WHITE)
    formula = (
        "Activation:   A(RH) = 1 / (1 + e^(-k × (RH - 60)))\n"
        "Saturation:   S(RH) = 1 - e^(-0.03 × RH)\n"
        "Time:         T(t)  = 1 - e^(-t / τ)     τ = 1 second (lab MXene)\n\n"
        "Response      = A × S × T\n"
        "MIAS factor   = 1 + 0.4 × Response\n"
        "Adjusted risk = min(ML_probability × MIAS_factor, 1.0)\n\n"
        "Inspired by Ti₃C₂Tₓ MXene humidity sensors — software layer when\n"
        "physical sensors are not yet deployed at scale."
    )
    _box(slide, Inches(0.55), Inches(1.2), Inches(8.9), Inches(3.8), RGBColor(241, 245, 249))
    _text(slide, Inches(0.75), Inches(1.35), Inches(8.5), Inches(3.5), formula, 15, False, DARK)


def slide_tiers(prs: Presentation):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _box(slide, Inches(0), Inches(0), Inches(10), Inches(0.9), CYAN)
    _text(slide, Inches(0.5), Inches(0.15), Inches(9), Inches(0.7), "5-Tier Early Warning System", 28, True, WHITE)
    tiers = [
        ("Safe", "0–20%", "#22c55e", "Normal activities"),
        ("Advisory", "20–40%", "#eab308", "Stay informed"),
        ("Watch", "40–60%", "#f97316", "Avoid drainage zones"),
        ("Warning", "60–80%", "#ef4444", "Move valuables higher"),
        ("Emergency", "80–100%", "#7f1d1d", "Evacuate low-lying areas"),
    ]
    for i, (name, pct, _, action) in enumerate(tiers):
        top = Inches(1.15 + i * 0.82)
        _text(slide, Inches(0.55), top, Inches(2.2), Inches(0.6), name, 16, True, CYAN)
        _text(slide, Inches(2.5), top, Inches(1.5), Inches(0.6), pct, 14, False, SLATE)
        _text(slide, Inches(4.0), top, Inches(5.4), Inches(0.6), action, 14, False, DARK)


def slide_demo(prs: Presentation):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _box(slide, Inches(0), Inches(0), Inches(10), Inches(0.9), CYAN)
    _text(slide, Inches(0.5), Inches(0.15), Inches(9), Inches(0.7), "Live Demo Flow (90 sec)", 28, True, WHITE)
    steps = [
        "1. Overview tab — metrics + pipeline",
        "2. Sidebar → Run demo → 2021 Maharashtra Floods",
        "3. Live Intelligence — gauge, MIAS curves, SHAP",
        "4. SMS alert mockup + natural-language advisory",
        "5. Event Validation — Chennai 2015, Kerala 2018",
        "6. India Map + Model & Trust (ROC, bias audit)",
    ]
    _text(slide, Inches(0.55), Inches(1.15), Inches(4.2), Inches(4.0), "\n".join(steps), 16, False, DARK)
    _box(slide, Inches(5.0), Inches(1.15), Inches(4.4), Inches(3.8), LIGHT)
    _text(
        slide, Inches(5.2), Inches(1.35), Inches(4.0), Inches(3.4),
        "Run dashboard:\n\npython -m streamlit run app.py\n\n"
        "→ http://localhost:8501\n\n"
        "Insert your screenshot here\n"
        "(Win+Shift+S during demo)",
        14, False, SLATE, PP_ALIGN.CENTER,
    )


def slide_close(prs: Presentation):
    slide = prs.slides.add_slide(prs.slide_layouts[6])
    _box(slide, Inches(0), Inches(0), Inches(10), Inches(5.625), CYAN)
    _text(slide, Inches(0.6), Inches(1.5), Inches(8.8), Inches(1.0), "Thank You", 40, True, WHITE, PP_ALIGN.CENTER)
    _text(
        slide, Inches(0.6), Inches(2.5), Inches(8.8), Inches(1.5),
        "ClimaXene doesn't just predict rain —\n"
        "it senses humidity like next-gen MXene hardware\n"
        "and translates it into life-saving tiers for India.",
        18, False, LIGHT, PP_ALIGN.CENTER,
    )
    _text(
        slide, Inches(0.6), Inches(4.2), Inches(8.8), Inches(0.6),
        "Questions?  |  github / demo / team name",
        14, False, LIGHT, PP_ALIGN.CENTER,
    )


def build():
    prs = Presentation()
    prs.slide_width = Inches(10)
    prs.slide_height = Inches(5.625)

    slide_title(prs)
    slide_bullets(
        prs, "The Problem",
        [
            "India loses $3B+ annually to floods; monsoon variability is rising",
            "Flash floods strike faster than gauge networks can update",
            "Humidity spikes before rainfall peaks — under-used in standard forecasts",
            "Communities need actionable tiers, not raw millimetres",
        ],
    )
    slide_bullets(
        prs, "Our Solution — ClimaXene",
        [
            "IMD 40-city training data + OpenWeather live & 72h forecast",
            "RF + Gradient Boosting ensemble for rain probability",
            "MIAS amplifies risk using MXene-inspired humidity physics",
            "5-tier IMD-style alerts + SHAP explainability + SMS mockup",
        ],
    )
    slide_bullets(
        prs, "System Architecture",
        [
            "Data → Feature engineering → Ensemble ML → MIAS (A×S×T) → 5-tier risk",
            "Outputs: dashboard, India map, forecast trajectory, alert log",
            "Historical validation against real Indian disasters",
            "Bias audit by climate zone — responsible AI built-in",
        ],
    )
    slide_formula(prs)
    slide_metrics(prs)
    slide_tiers(prs)
    slide_bullets(
        prs, "Platform Features",
        [
            "Live Intelligence — gauge, MIAS curves, SHAP bar chart",
            "72-hour early warning trajectory",
            "Interactive India risk map (15 cities live)",
            "Event simulation — Maharashtra flood preset",
            "One-click Judge Demo scenarios in sidebar",
        ],
    )
    slide_demo(prs)
    slide_bullets(
        prs, "Why We Win",
        [
            "Innovation: MIAS — published-style MXene equations, not a black box",
            "Impact: India-first — 40 cities, documented flood events",
            "Technical depth: ROC, F1, confusion matrix, geographic fairness",
            "Demo-ready: polished Streamlit + pitch deck + video script",
        ],
    )
    slide_close(prs)

    OUT.parent.mkdir(parents=True, exist_ok=True)
    prs.save(str(OUT))
    print(f"Saved: {OUT}")
    print(f"Slides: {len(prs.slides)}")


if __name__ == "__main__":
    build()
