"""Sync IMD export into data/combined_imd_export.csv and rebuild combined_cities.csv."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.imd_loader import sync_project_from_imd_export


def main() -> None:
    src = ROOT / "data" / "combined_imd_export.csv"
    if not src.exists():
        alt = Path(r"c:\Users\jawah\Downloads\imd_export(1).csv")
        if alt.exists():
            src = alt
        else:
            print("Place IMD CSV at data/combined_imd_export.csv")
            return

    info = sync_project_from_imd_export(src, ROOT)
    print(f"Synced {info['n_rows']:,} rows, {info['n_cities']} cities")
    print(f"  Cities: {', '.join(info['cities'][:8])} ...")
    print(f"  Rain fraction: {info['rain_fraction']:.1%}")
    print(f"  Saved: {info['cities_path']}")


if __name__ == "__main__":
    main()
