"""Generate synthetic weather dataset for demo/training."""

from pathlib import Path

import numpy as np
import pandas as pd


def generate(n_rows: int = 3000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    temperature = rng.normal(22, 8, n_rows).clip(-5, 45)
    humidity = rng.beta(2, 2, n_rows) * 100
    pressure = rng.normal(1013, 12, n_rows)
    wind_speed = rng.exponential(12, n_rows).clip(0, 80)
    dew_point = temperature - (100 - humidity) / 5 + rng.normal(0, 1, n_rows)

    rain_score = (
        0.06 * humidity
        + 0.04 * (1015 - pressure)
        + 0.02 * wind_speed
        - 0.03 * temperature
        + 0.05 * np.maximum(dew_point - temperature + 5, 0)
        + rng.normal(0, 0.8, n_rows)
    )
    rainfall = (rain_score > np.percentile(rain_score, 55)).astype(int)

    return pd.DataFrame(
        {
            "temperature": np.round(temperature, 1),
            "humidity": np.round(humidity, 1),
            "pressure": np.round(pressure, 1),
            "dew_point": np.round(dew_point, 1),
            "wind_speed": np.round(wind_speed, 1),
            "rainfall": rainfall,
        }
    )


if __name__ == "__main__":
    out = Path(__file__).resolve().parent.parent / "data" / "weather_sample.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    df = generate()
    df.to_csv(out, index=False)
    print(f"Wrote {len(df)} rows to {out}")
