"""Train ensemble on IMD 40-city export (primary)."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import pandas as pd

from src.imd_loader import is_imd_export_path, load_imd_export, resolve_training_path
from src.model_training import save_model, train_ensemble


def main() -> None:
    data_path = resolve_training_path(ROOT)
    print(f"Training data: {data_path}")

    if is_imd_export_path(data_path):
        df = load_imd_export(data_path)
    else:
        df = pd.read_csv(data_path)
        if "rainfall_mm" in df.columns and "rainfall" in df.columns:
            df = df.drop(columns=["rainfall_mm"])

    max_rows = 80_000
    if len(df) > max_rows:
        pos = df[df["rainfall"] == 1]
        neg = df[df["rainfall"] == 0]
        half = max_rows // 2
        df = pd.concat(
            [
                pos.sample(min(len(pos), half), random_state=42),
                neg.sample(min(len(neg), half), random_state=42),
            ]
        ).sample(frac=1, random_state=42)
        print(f"Subsampled to {len(df):,} rows for training speed")

    model, metrics, medians = train_ensemble(df)
    model_dir = ROOT / "models"
    save_model(model, metrics, medians, model_dir)
    metrics["data_source"] = data_path.name
    metrics["n_cities"] = int(df["city"].nunique()) if "city" in df.columns else 0
    import json

    (model_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    print("Training complete.")
    print(f"  Data:      {data_path.name} ({len(df):,} rows)")
    if "city" in df.columns:
        print(f"  Cities:    {df['city'].nunique()}")
    print(f"  Accuracy:  {metrics['accuracy']:.3f}")
    print(f"  F1 Score:  {metrics['f1']:.3f}")
    print(f"  ROC-AUC:   {metrics['roc_auc']:.3f}")


if __name__ == "__main__":
    main()
