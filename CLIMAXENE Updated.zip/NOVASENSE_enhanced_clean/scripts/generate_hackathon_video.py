"""
Generate ClimaXene hackathon demo video (MP4) with TTS narration + slide images.
Run: python scripts/generate_hackathon_video.py
Output: presentations/ClimaXene_Hackathon_Demo.mp4
Requires: pillow, edge-tts, moviepy (installed via pip)
"""

from __future__ import annotations

import asyncio
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont
from pptx import Presentation

ROOT = Path(__file__).resolve().parents[1]
PPT_PATH = ROOT / "presentations" / "ClimaXene_Hackathon.pptx"
OUT_DIR = ROOT / "presentations" / "video_assets"
OUT_VIDEO = ROOT / "presentations" / "ClimaXene_Hackathon_Demo.mp4"

W, H = 1920, 1080
BG = (8, 145, 178)
BG_DARK = (15, 23, 42)
WHITE = (255, 255, 255)
LIGHT = (240, 253, 250)
SLATE = (71, 85, 105)

# Narration per slide index (matches build_hackathon_ppt order)
NARRATIONS = [
    "Introducing ClimaXene — hyperlocal climate intelligence for India. "
    "We combine ensemble machine learning with MIAS, our MXene-inspired adaptive sensing layer, "
    "to deliver five-tier flood early warnings.",
    "The problem is urgent. India loses billions to floods every year. "
    "Flash floods move faster than gauge networks. Humidity rises before rainfall peaks, "
    "but most forecasts ignore that signal. People need clear advisories, not just numbers.",
    "ClimaXene is our answer. We train on forty IMD cities, fuse live OpenWeather data, "
    "and run a Random Forest plus Gradient Boosting ensemble. MIAS amplifies rain risk in humid conditions. "
    "The output is five-tier alerts with SHAP explainability.",
    "The pipeline is simple and powerful. Data flows through feature engineering, "
    "the ensemble model, MIAS physics, and into tiered risk with SMS-style alerts, "
    "a live India map, and historical validation.",
    "MIAS is our innovation. It models MXene sensor behavior with three effects: "
    "activation, saturation, and time response. "
    "Adjusted risk equals machine learning probability times the MIAS factor — "
    "bringing lab humidity physics into software.",
    "On hold-out data, we achieve ROC-AUC of zero point eight one four and F1 of zero point six three. "
    "We trained on over forty-six thousand rows across forty Indian cities.",
    "Risk maps to five tiers: Safe, Advisory, Watch, Warning, and Emergency — "
    "each with clear recommended actions for citizens and responders.",
    "The dashboard includes live intelligence, seventy-two hour forecasts, "
    "an interactive India map, event simulation, and one-click judge demo scenarios.",
    "In the live demo, load the Maharashtra flood scenario, show MIAS curves and SHAP, "
    "validate against Chennai twenty fifteen, and open the model trust tab for ROC and bias audit.",
    "Why ClimaXene wins: real innovation with MIAS, India-first impact, "
    "technical depth with explainability, and a polished demo-ready platform.",
    "Thank you. ClimaXene senses humidity like next-generation MXene hardware "
    "and translates it into life-saving tiers for every city we serve. We welcome your questions.",
]


def _font(size: int, bold: bool = False):
    names = ["arialbd.ttf", "arial.ttf", "segoeuib.ttf", "segoeui.ttf"] if bold else ["arial.ttf", "segoeui.ttf"]
    for name in names:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _wrap(draw, text: str, font, max_width: int) -> list[str]:
    words = text.replace("\n", " \n ").split()
    lines, current = [], ""
    for word in words:
        if word == "\n":
            if current:
                lines.append(current)
            lines.append("")
            current = ""
            continue
        test = f"{current} {word}".strip()
        if draw.textlength(test, font=font) <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines or [""]


def render_slide_image(title: str, body: str, idx: int, total: int) -> Image.Image:
    img = Image.new("RGB", (W, H), BG_DARK)
    draw = ImageDraw.Draw(img)
    draw.rectangle([0, 0, W, 120], fill=BG)
    draw.text((60, 32), title, font=_font(52, True), fill=WHITE)

    y = 160
    title_font = _font(36, True)
    body_font = _font(28)
    for line in _wrap(draw, body, body_font, W - 120):
        if not line.strip():
            y += 20
            continue
        draw.text((60, y), line, font=body_font, fill=LIGHT)
        y += 42

    draw.text((60, H - 50), f"ClimaXene · Slide {idx + 1}/{total}", font=_font(20), fill=SLATE)
    return img


def extract_slide_texts() -> list[tuple[str, str]]:
    if not PPT_PATH.exists():
        raise FileNotFoundError(f"Run build_hackathon_ppt.py first. Missing: {PPT_PATH}")

    prs = Presentation(str(PPT_PATH))
    slides = []
    for slide in prs.slides:
        texts = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                t = shape.text_frame.text.strip()
                if t:
                    texts.append(t)
        title = texts[0] if texts else "ClimaXene"
        body = "\n".join(texts[1:]) if len(texts) > 1 else ""
        slides.append((title, body))
    return slides


async def synthesize_narration(segments: list[str], out_dir: Path) -> list[Path]:
    import edge_tts

    voice = "en-IN-NeerjaNeural"
    paths = []
    for i, text in enumerate(segments):
        path = out_dir / f"narration_{i:02d}.mp3"
        comm = edge_tts.Communicate(text, voice)
        await comm.save(str(path))
        paths.append(path)
        print(f"  Audio {i + 1}/{len(segments)}")
    return paths


def _ffmpeg_exe() -> str | None:
    import shutil
    import subprocess

    if shutil.which("ffmpeg"):
        return "ffmpeg"
    try:
        import imageio_ffmpeg
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if Path(exe).exists():
            return exe
    except ImportError:
        pass
    return None


def _build_with_ffmpeg(slide_images: list[Path], audio_paths: list[Path], output: Path) -> bool:
    import subprocess

    ffmpeg = _ffmpeg_exe()
    if not ffmpeg:
        return False

    work = output.parent / "video_build"
    work.mkdir(parents=True, exist_ok=True)
    segments = []

    for i, (img, aud) in enumerate(zip(slide_images, audio_paths, strict=True)):
        seg = work / f"seg_{i:02d}.mp4"
        subprocess.run(
            [
                ffmpeg, "-y",
                "-loop", "1", "-i", str(img),
                "-i", str(aud),
                "-c:v", "libx264", "-tune", "stillimage",
                "-c:a", "aac", "-b:a", "192k",
                "-pix_fmt", "yuv420p",
                "-shortest",
                "-vf", "scale=1920:1080:force_original_aspect_ratio=decrease,pad=1920:1080:(ow-iw)/2:(oh-ih)/2",
                str(seg),
            ],
            check=True,
            capture_output=True,
        )
        segments.append(seg)

    list_file = work / "concat.txt"
    list_file.write_text("\n".join(f"file '{s.resolve().as_posix()}'" for s in segments), encoding="utf-8")
    subprocess.run(
        [ffmpeg, "-y", "-f", "concat", "-safe", "0", "-i", str(list_file), "-c", "copy", str(output)],
        check=True,
        capture_output=True,
    )
    return True


def build_video(slide_images: list[Path], audio_paths: list[Path], output: Path):
    output.parent.mkdir(parents=True, exist_ok=True)
    if _build_with_ffmpeg(slide_images, audio_paths, output):
        print("Built with ffmpeg")
        return

    from moviepy import AudioFileClip, ImageClip, concatenate_videoclips

    clips = []
    for img_path, audio_path in zip(slide_images, audio_paths, strict=True):
        audio = AudioFileClip(str(audio_path))
        dur = max(audio.duration + 0.5, 4.0)
        clip = ImageClip(str(img_path)).with_duration(dur).with_audio(audio)
        clips.append(clip)

    final = concatenate_videoclips(clips, method="compose")
    final.write_videofile(str(output), fps=24, codec="libx264", audio_codec="aac", logger=None)
    final.close()
    for c in clips:
        c.close()


def main():
    print("Extracting slides...")
    slide_texts = extract_slide_texts()
    n = min(len(slide_texts), len(NARRATIONS))
    narrations = NARRATIONS[:n]

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    print("Rendering slide images...")
    image_paths = []
    for i, (title, body) in enumerate(slide_texts[:n]):
        img = render_slide_image(title, body, i, n)
        p = OUT_DIR / f"slide_{i:02d}.png"
        img.save(p)
        image_paths.append(p)

    audio_dir = OUT_DIR / "audio"
    audio_dir.mkdir(parents=True, exist_ok=True)
    existing = sorted(audio_dir.glob("narration_*.mp3"))
    if len(existing) >= n:
        print("Using cached narration...")
        audio_paths = existing[:n]
    else:
        print("Generating narration (edge-tts)...")
        audio_paths = asyncio.run(synthesize_narration(narrations, audio_dir))

    print("Building MP4...")
    build_video(image_paths, audio_paths, OUT_VIDEO)

    print(f"Done: {OUT_VIDEO}")


if __name__ == "__main__":
    main()
