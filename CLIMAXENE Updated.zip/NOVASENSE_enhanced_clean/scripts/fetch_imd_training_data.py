"""Download real Indian hourly weather (Open-Meteo archive) for ML training."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.imd_loader import fetch_open_meteo_india_training


def main() -> None:
    print("Fetching real hourly weather for Indian cities (2019-2024)...")
    print("For official IMD CDSP exports, place CSV at data/imd_export.csv")
    df = fetch_open_meteo_india_training(
        start_date="2020-01-01",
        end_date="2024-12-31",
    )
    out = ROOT / "data" / "imd_training.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    cols = [
        "datetime",
        "city",
        "temperature",
        "humidity",
        "pressure",
        "dew_point",
        "wind_speed",
        "rainfall_mm",
        "rainfall",
    ]
    df[cols].to_csv(out, index=False)
    print(f"Saved {len(df):,} rows to {out}")
    print(f"Rain days: {df['rainfall'].mean():.1%}")


if __name__ == "__main__":
    main()
