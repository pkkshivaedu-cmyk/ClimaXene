# ClimaXene launcher (streamlit may not be on PATH)
Set-Location $PSScriptRoot
python -m streamlit run app.py
