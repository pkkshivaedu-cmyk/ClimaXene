# Climaxene

**Hyperlocal climate intelligence for India** — ensemble machine learning amplified by **MIAS** (MXene-Inspired Adaptive Sensing) for 5-tier flood early warning.

<p align="center">
  <img src="https://img.shields.io/badge/Python-3.10+-0891b2?style=flat-square" alt="Python"/>
  <img src="https://img.shields.io/badge/Streamlit-Dashboard-06b6d4?style=flat-square" alt="Streamlit"/>
  <img src="https://img.shields.io/badge/Data-40%20IMD%20cities-0e7490?style=flat-square" alt="IMD"/>
  <img src="https://img.shields.io/badge/ML-RF%2BGB%20Ensemble-22c55e?style=flat-square" alt="ML"/>
</p>

---

## Why Climaxene wins

| Pillar | What we built |
|--------|----------------|
| **Innovation** | MIAS — lab MXene physics (A×S×T) as a software humidity amplifier |
| **Impact** | 40 Indian cities, historical flood validation, SMS-style alerts |
| **Depth** | SHAP, ROC/F1, 72h forecast, geographic bias audit |
| **Polish** | Judge demo scenarios, professional dashboard, pitch deck (`PITCH.md`) |

---

## Quick start

```powershell
cd c:\Users\aranu\Downloads\NOVASENSEE\CLIMAXENE
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt

# Sync IMD data + train (if model missing)
python scripts/sync_imd_data.py
python scripts/train_model.py

# Launch dashboard
python -m streamlit run app.py
# Or: .\run.ps1
```

Open **http://localhost:8501**

### Judge demo (90 seconds)

1. Sidebar → **Run demo scenario** → *2021 Maharashtra Floods*
2. Tab **Live Intelligence** — gauge, MIAS curves, SHAP, SMS mockup
3. Tab **Event Validation** — IMD-documented extremes
4. Tab **Model & Trust** — ROC, bias audit

Full script: [`PITCH.md`](PITCH.md)

### Hackathon PPT & video

| Asset | Path |
|-------|------|
| PowerPoint (11 slides) | `presentations/Climaxene_Hackathon.pptx` |
| Auto-narrated MP4 (~2.5 min) | `presentations/Climaxene_Hackathon_Demo.mp4` |
| Recording script | `presentations/VIDEO_SCRIPT.md` |

Rebuild: `.\presentations\build_all.ps1`

---

## Features

- **Ensemble ML** — Random Forest + Gradient Boosting (soft voting)
- **MIAS layer** — MXene Activation × Saturation × Time response
- **5-tier risk** — Safe → Advisory → Watch → Warning → Emergency
- **SHAP explainability** — per-prediction drivers
- **72-hour forecast** — OpenWeather + MIAS scoring
- **Live India map** — Folium, tier-coloured cities
- **Historical validation** — Maharashtra 2021, Chennai 2015, Kerala 2018, …
- **Drought stress** — inverse humidity curve
- **Responsible AI** — bias audit, data provenance

---

## OpenWeather (optional)

```bash
copy .env.example .env
# Set OPENWEATHER_API_KEY=your_key
```

Enables **Fetch live weather**, **72h forecast**, and **India map**.

---

## Project structure

```
CLIMAXENE/
├── app.py                    # Streamlit dashboard
├── PITCH.md                  # Judge presentation script
├── .streamlit/config.toml    # Theme (cyan / slate)
├── src/
│   ├── mias.py               # MXene physics simulation
│   ├── theme.py              # Design system
│   ├── demo_presets.py       # One-click judge scenarios
│   ├── ui_components.py      # Hero, metrics, alerts
│   └── …
├── data/
│   ├── imd_export.csv        # 40-city training data
│   ├── india_cities.csv
│   └── historical_events.json
├── models/                   # Trained ensemble + metrics.json
└── scripts/
    ├── sync_imd_data.py
    └── train_model.py
```

---

## MIAS formula

```
Activation:  A(RH) = 1 / (1 + e^(-k × (RH - RHc)))     RHc=60, k=0.18
Saturation:  S(RH) = 1 - e^(-α × RH)                   α=0.03
Time:        T(t)  = 1 - e^(-t / τ)                     τ=1 s

Response     = A × S × T
mxene_factor = 1 + 0.4 × Response
adjusted     = min(ml_probability × mxene_factor, 1.0)
```

---

## Model metrics (hold-out)

| Metric | Value |
|--------|-------|
| ROC-AUC | ~0.81 |
| F1 | ~0.63 |
| Cities | 40 |
| Training rows | ~46k |

See `models/metrics.json` after training.

---

## Team & license

Hackathon build — **ClimaXene 2025**. Prototype for demonstration; not operational IMD replacement.
