# Climaxene — 3-Minute Judge Pitch

## Elevator (30 seconds)

**Climaxene** turns national weather feeds into **street-level flood early warnings** for India. We train an **RF + Gradient Boosting ensemble** on **40 IMD cities**, then amplify predictions with **MIAS** — a physics model inspired by **MXene humidity sensors** (Activation × Saturation × Time). The output is a **5-tier advisory** (Safe → Emergency) with **SHAP explainability**, **72-hour trajectories**, and **historical validation** against real Indian disasters.

## Problem

- Floods cost India **billions** annually; flash floods hit faster than gauge networks update.
- Humidity spikes **before** rainfall peaks — but standard forecasts under-use this signal.
- Communities need **actionable tiers**, not raw millimetres.

## Solution

| Layer | What it does |
|-------|----------------|
| **Data** | IMD 40-city export + OpenWeather live/forecast |
| **ML** | Soft-voting ensemble, ROC-AUC ~0.81 on hold-out |
| **MIAS** | Sigmoid MXene response amplifies rain probability in humid conditions |
| **Delivery** | Dashboard, SMS mockup, India map, natural-language alerts |

## Live demo script (90 seconds)

1. **Overview** — Show metrics and pipeline diagram.
2. Sidebar → **Run demo scenario** → *2021 Maharashtra Floods*.
3. **Live Intelligence** — Gauge, MIAS curves, SHAP, SMS alert.
4. **Event Validation** — Pass rate on Chennai 2015, Kerala 2018, etc.
5. **India Map** — Refresh 10 cities (needs API key).
6. **Model & Trust** — ROC, confusion matrix, bias audit.

## Differentiators (say these clearly)

1. **MIAS is not a black box** — published-style MXene equations on screen.
2. **India-first** — 40 cities, historical Indian events, zone bias audit.
3. **Responsible AI** — SHAP + provenance tab + documented arid-zone limitation.
4. **Production-shaped** — Retrain button, alert log, forecast trajectory.

## Q&A prep

| Question | Answer |
|----------|--------|
| Why MXene? | Lab Ti₃C₂Tₓ sensors show fast humidity response; MIAS transfers that curve to software when physical sensors aren't deployed. |
| How accurate? | Hold-out ROC-AUC ~0.81, F1 ~0.63 on rain events (see `models/metrics.json`). |
| Without API key? | Full ML + MIAS + validation works; map/forecast need OpenWeather. |
| vs IMD alerts? | We add **hyperlocal ML + humidity amplification** and **explainability** ahead of gauge-triggered warnings. |

## One-line close

> *Climaxene doesn't just predict rain — it senses humidity like next-gen MXene hardware and translates it into life-saving tiers for every Indian city we serve.*
