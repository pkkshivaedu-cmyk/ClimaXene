"""
Load and normalize IMD export CSVs (40-city daily gridded data).
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import requests

from src.preprocessing import _encode_rainfall, compute_heat_index

def _load_city_climate_zones(root: Path | None = None) -> dict[str, str]:
    """Climate zones from data/combined_cities.csv (India + Central Asia combined)."""
    base = root or Path(__file__).resolve().parent.parent
    path = base / "data" / "combined_cities.csv"
    if not path.exists():
        path = base / "data" / "india_cities.csv"
    if not path.exists():
        return {}
    df = pd.read_csv(path)
    if "climate_zone" not in df.columns:
        return {}
    return dict(zip(df["city"], df["climate_zone"]))


CITY_CLIMATE_ZONES: dict[str, str] = _load_city_climate_zones()


def load_imd_export(path: Path) -> pd.DataFrame:
    """
    Load Climaxene IMD 40-city daily export:
    date, city, latitude, longitude, rainfall (mm), tmax, tmin, humidity, ...
    """
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]

    cols_lower = {c.lower() for c in df.columns}
    if "tmax" in cols_lower and "tmin" in cols_lower and "city" in cols_lower:
        return _from_imd_city_daily(df)

    # Legacy wide / other formats
    lower = {c.lower(): c for c in df.columns}
    if "rainfall" not in cols_lower:
        for cand in ("rainfall_mm", "rain", "precipitation", "rain_mm"):
            if cand in lower:
                df = df.rename(columns={lower[cand]: "rainfall"})
                break

    from src.preprocessing import _normalize_column_names

    out = _normalize_column_names(df)
    if "rainfall" in out.columns:
        col = out["rainfall"]
        if isinstance(col, pd.DataFrame):
            col = col.iloc[:, 0]
        out["rainfall"] = _encode_rainfall(col)
    return out


def _from_imd_city_daily(df: pd.DataFrame) -> pd.DataFrame:
    """IMD 40-city daily gridded export → ML training schema."""
    out = df.copy()
    out.columns = [c.strip().lower() for c in out.columns]

    out["temperature"] = (out["tmax"] + out["tmin"]) / 2.0
    out["rainfall_mm"] = out["rainfall"]
    if "flood_label" in out.columns:
        out["rainfall"] = out["flood_label"].astype(int)
    else:
        out["rainfall"] = (out["rainfall_mm"] > 0.1).astype(int)
    out = out.rename(columns={"latitude": "lat", "longitude": "lon"})

    keep = [
        "date",
        "city",
        "lat",
        "lon",
        "temperature",
        "humidity",
        "pressure",
        "pressure_change",
        "dew_point",
        "wind_speed",
        "rainfall",
        "rainfall_mm",
        "rainfall_3d",
        "rainfall_7d",
        "rainfall_14d",
        "flood_label",
        "data_source",
    ]
    keep = [c for c in keep if c in out.columns]
    out = out[keep].dropna(subset=["temperature", "humidity", "pressure", "dew_point", "wind_speed", "rainfall"])

    out["heat_index"] = [
        compute_heat_index(t, h)
        for t, h in zip(out["temperature"], out["humidity"], strict=False)
    ]
    return out.sort_values(["city", "date"]).reset_index(drop=True)


def fetch_open_meteo_india_training(
    cities_df: pd.DataFrame,
    *,
    start_date: str = "2020-01-01",
    end_date: str = "2024-12-31",
) -> pd.DataFrame:
    """Fallback hourly archive if only daily IMD export exists."""
    hourly_vars = [
        "temperature_2m",
        "relative_humidity_2m",
        "pressure_msl",
        "dew_point_2m",
        "wind_speed_10m",
        "precipitation",
    ]
    chunks = []
    for _, row in cities_df.iterrows():
        url = "https://archive-api.open-meteo.com/v1/archive"
        params = {
            "latitude": row["lat"],
            "longitude": row["lon"],
            "start_date": start_date,
            "end_date": end_date,
            "hourly": ",".join(hourly_vars),
            "timezone": "Asia/Tashkent",
        }
        resp = requests.get(url, params=params, timeout=120)
        resp.raise_for_status()
        data = resp.json()["hourly"]
        chunk = pd.DataFrame(
            {
                "datetime": data["time"],
                "city": row["city"],
                "temperature": data["temperature_2m"],
                "humidity": data["relative_humidity_2m"],
                "pressure": data["pressure_msl"],
                "dew_point": data["dew_point_2m"],
                "wind_speed": [w * 3.6 for w in data["wind_speed_10m"]],
                "rainfall_mm": data["precipitation"],
            }
        )
        chunk = chunk.dropna()
        chunk["rainfall"] = (chunk["rainfall_mm"] > 0.2).astype(int)
        chunks.append(chunk)
    combined = pd.concat(chunks, ignore_index=True)
    return combined


def resolve_training_path(root: Path) -> Path:
    """Prefer combined IMD export, then training archive, then sample."""
    export = root / "data" / "combined_imd_export.csv"
    hourly = root / "data" / "combined_imd_training.csv"
    sample = root / "data" / "combined_weather_sample.csv"
    if export.exists():
        return export
    if hourly.exists():
        return hourly
    return sample


def is_imd_export_path(path: Path) -> bool:
    return path.name in ("combined_imd_export.csv", "imd_export.csv")


def sync_project_from_imd_export(export_path: Path, root: Path) -> dict:
    """
    Copy IMD export into data/, rebuild india_cities.csv, return summary.
    """
    data_dir = root / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    target = data_dir / "combined_imd_export.csv"
    if export_path.resolve() != target.resolve():
        import shutil

        shutil.copy2(export_path, target)

    raw = pd.read_csv(target)
    cities = raw.groupby("city", as_index=False).agg(
        lat=("latitude", "first"),
        lon=("longitude", "first"),
    )
    zones = _load_city_climate_zones(root) or CITY_CLIMATE_ZONES
    cities["climate_zone"] = cities["city"].map(zones).fillna("Semi-Arid")
    cities_path = data_dir / "combined_cities.csv"
    cities.to_csv(cities_path, index=False)

    train_df = load_imd_export(target)
    return {
        "export_path": str(target),
        "cities_path": str(cities_path),
        "n_cities": int(raw["city"].nunique()),
        "n_rows": len(train_df),
        "rain_fraction": float(train_df["rainfall"].mean()),
        "cities": sorted(raw["city"].unique().tolist()),
    }
