"""Judge demo presets — one-click scenarios for hackathon presentations.
Now includes multi-hazard scenarios for Central Asian cities.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DemoScenario:
    id: str
    title: str
    city: str
    description: str
    tab_hint: str
    temperature: float
    humidity: float
    pressure: float
    dew_point: float
    wind_speed: float
    elapsed_seconds: float


DEMO_SCENARIOS: dict[str, DemoScenario] = {
    # ── Flood scenarios ────────────────────────────────────────────────────────
    "kyrgyzstan_flood": DemoScenario(
        id="kyrgyzstan_flood",
        title="2024 Kyrgyzstan Spring Floods",
        city="Bishkek",
        description="Glacial melt + heavy rain — MIAS amplifies ML rain probability into Warning tier.",
        tab_hint="Live Intelligence",
        temperature=14.0, humidity=88.0, pressure=1007.0,
        dew_point=12.0, wind_speed=25.0, elapsed_seconds=2.0,
    ),
    "tbilisi_emergency": DemoScenario(
        id="tbilisi_emergency",
        title="2015 Tbilisi Flash Flood",
        city="Tbilisi",
        description="River overflow saturation — validates historical Emergency classification.",
        tab_hint="Event Validation",
        temperature=21.0, humidity=93.0, pressure=1002.0,
        dew_point=20.0, wind_speed=40.0, elapsed_seconds=2.0,
    ),
    "kazakhstan_flood": DemoScenario(
        id="kazakhstan_flood",
        title="2024 Kazakhstan Spring Flooding",
        city="Aktobe",
        description="Spring melt flooding — ensemble confidence and SHAP drivers.",
        tab_hint="Model & Trust",
        temperature=10.0, humidity=87.0, pressure=1005.0,
        dew_point=8.0, wind_speed=28.0, elapsed_seconds=2.0,
    ),
    # ── Sandstorm scenarios ────────────────────────────────────────────────────
    "uzbekistan_sandstorm": DemoScenario(
        id="uzbekistan_sandstorm",
        title="Tashkent Dust Storm Warning",
        city="Tashkent",
        description="Hot, dry, high-wind conditions near Kyzylkum desert — sandstorm risk.",
        tab_hint="Simulate Event",
        temperature=38.0, humidity=14.0, pressure=1012.0,
        dew_point=3.0, wind_speed=62.0, elapsed_seconds=2.0,
    ),
    "ashgabat_sandstorm": DemoScenario(
        id="ashgabat_sandstorm",
        title="Ashgabat Karakum Sandstorm",
        city="Ashgabat",
        description="Karakum desert winds — extreme sandstorm and heat dual hazard.",
        tab_hint="Simulate Event",
        temperature=42.0, humidity=10.0, pressure=1013.0,
        dew_point=1.0, wind_speed=72.0, elapsed_seconds=2.0,
    ),
    # ── Heatwave scenarios ─────────────────────────────────────────────────────
    "uzbekistan_heat": DemoScenario(
        id="uzbekistan_heat",
        title="2018 Central Asia Heatwave",
        city="Tashkent",
        description="Low humidity arid heat stress — drought MIAS inverse curve; flood tier stays Safe.",
        tab_hint="Simulate Event",
        temperature=44.0, humidity=18.0, pressure=1008.0,
        dew_point=8.0, wind_speed=20.0, elapsed_seconds=2.0,
    ),
    "kandahar_heat": DemoScenario(
        id="kandahar_heat",
        title="Kandahar Extreme Heat Event",
        city="Kandahar",
        description="Southern Afghan extreme summer heat — heat stroke risk at population level.",
        tab_hint="Live Intelligence",
        temperature=47.0, humidity=12.0, pressure=1006.0,
        dew_point=2.0, wind_speed=22.0, elapsed_seconds=2.0,
    ),
    # ── Snowfall scenarios ─────────────────────────────────────────────────────
    "srinagar_snowfall": DemoScenario(
        id="srinagar_snowfall",
        title="Srinagar Heavy Snowfall",
        city="Srinagar",
        description="Kashmir alpine blizzard — snowfall risk with secondary avalanche/landslide hazard.",
        tab_hint="Live Intelligence",
        temperature=-6.0, humidity=82.0, pressure=1020.0,
        dew_point=-9.0, wind_speed=45.0, elapsed_seconds=2.0,
    ),
    "karakol_blizzard": DemoScenario(
        id="karakol_blizzard",
        title="Karakol Alpine Blizzard",
        city="Karakol",
        description="Kyrgyz alpine zone — snowfall + wind → blizzard conditions.",
        tab_hint="Simulate Event",
        temperature=-12.0, humidity=78.0, pressure=1018.0,
        dew_point=-15.0, wind_speed=55.0, elapsed_seconds=2.0,
    ),
    # ── Frost scenarios ────────────────────────────────────────────────────────
    "ulaanbaatar_frost": DemoScenario(
        id="ulaanbaatar_frost",
        title="Ulaanbaatar Dzud Frost Event",
        city="Ulaanbaatar",
        description="Mongolian dzud — extreme continental frost with infrastructure freeze risk.",
        tab_hint="Simulate Event",
        temperature=-28.0, humidity=65.0, pressure=1035.0,
        dew_point=-32.0, wind_speed=38.0, elapsed_seconds=2.0,
    ),
    # ── Landslide scenarios ────────────────────────────────────────────────────
    "osh_landslide": DemoScenario(
        id="osh_landslide",
        title="Osh Southern Kyrgyzstan Landslide",
        city="Osh",
        description="Heavy spring rain on saturated mountain slopes — landslide alert.",
        tab_hint="Event Validation",
        temperature=18.0, humidity=84.0, pressure=1004.0,
        dew_point=15.0, wind_speed=30.0, elapsed_seconds=2.0,
    ),
}


def apply_scenario(scenario: DemoScenario) -> None:
    """Write scenario weather into Streamlit session state."""
    import streamlit as st

    st.session_state["weather"] = {
        "city": scenario.city,
        "country": "IN",
        "temperature": scenario.temperature,
        "humidity": scenario.humidity,
        "pressure": scenario.pressure,
        "dew_point": scenario.dew_point,
        "wind_speed": scenario.wind_speed,
    }
    st.session_state["demo_city"] = scenario.city
    st.session_state["demo_elapsed"] = scenario.elapsed_seconds
    st.session_state["demo_active"] = scenario.id
    st.session_state["demo_tab_hint"] = scenario.tab_hint
