"""
Multi-Hazard Risk Engine for ClimaXene.

Given a city + weather readings, this module computes the appropriate
risk score for the city's PRIMARY hazard type, rather than always
treating everything as a flood.

Hazard score functions return a float [0, 1] where 1 = maximum risk.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from src.city_hazard_profile import HazardProfile, get_hazard_profile


@dataclass
class HazardResult:
    """Result from the multi-hazard risk engine."""
    hazard_type: str       # flood | snowfall | sandstorm | heatwave | blizzard
    primary_score: float   # 0–1 hazard-adjusted risk score
    raw_score: float       # 0–1 original ML/HIE score
    amplifier: float       # multiplier applied
    label: str             # human-readable label
    icon: str
    color: str
    risk_label: str
    alert_msg: str         # short alert message
    action_msg: str        # short action message
    sensor_note: str       # sensor pipeline note


# ── Individual hazard score functions ──────────────────────────────────────

def _snowfall_score(
    temperature: float,
    humidity: float,
    wind_speed: float,
    pressure: float,
    ml_base: float,
) -> tuple[float, float]:
    """
    Snowfall / avalanche risk.
    High risk when: temp near/below 0°C, high humidity, strong wind, low pressure.
    """
    # Temperature factor: riskiest around -2 to -15°C (active snowfall band)
    if temperature > 5:
        temp_factor = 0.0
    elif temperature > 0:
        temp_factor = (5 - temperature) / 5 * 0.4
    elif temperature >= -20:
        temp_factor = 0.4 + (abs(temperature) / 20) * 0.6
    else:
        temp_factor = 0.8  # extreme cold but dry snow — slightly lower snowfall risk

    # Humidity factor: snowfall needs moisture
    hum_factor = min(humidity / 100, 1.0)

    # Wind factor: contributes to blizzard/drifting
    wind_factor = min(wind_speed / 80, 1.0)

    # Pressure drop factor (low pressure = active storm)
    press_factor = max(0.0, (1020 - pressure) / 50)
    press_factor = min(press_factor, 1.0)

    raw = (temp_factor * 0.45 + hum_factor * 0.25 + wind_factor * 0.15 + press_factor * 0.15)
    # Blend with ML base (ML trained on rain but partial correlation)
    score = min(raw * 0.75 + ml_base * 0.25, 1.0)
    amplifier = score / max(ml_base, 0.01)
    return score, amplifier


def _sandstorm_score(
    temperature: float,
    humidity: float,
    wind_speed: float,
    pressure: float,
    ml_base: float,
) -> tuple[float, float]:
    """
    Sandstorm / dust storm risk.
    High risk when: high temp, very low humidity, strong wind, bare desert terrain.
    """
    # Low humidity = dry, dusty
    dry_factor = max(0.0, (50 - humidity) / 50)
    dry_factor = min(dry_factor, 1.0)

    # High temperature = thermal convection lifts dust
    temp_factor = min(max(0.0, (temperature - 25) / 20), 1.0)

    # Strong winds are necessary
    wind_factor = min(wind_speed / 60, 1.0)

    # Rapid pressure change (front passage can lift dust)
    press_factor = abs(pressure - 1010) / 30
    press_factor = min(press_factor, 1.0)

    raw = (dry_factor * 0.40 + wind_factor * 0.35 + temp_factor * 0.15 + press_factor * 0.10)
    score = min(raw, 1.0)
    amplifier = score / max(ml_base, 0.01)
    return score, amplifier


def _heatwave_score(
    temperature: float,
    humidity: float,
    wind_speed: float,
    pressure: float,
    ml_base: float,
) -> tuple[float, float]:
    """
    Heatwave / extreme heat risk.
    Uses Heat Index (apparent temperature) logic.
    """
    # Heat Index approximation
    if temperature < 27:
        hi = temperature
    else:
        # Rothfusz regression approximation
        hi = (-8.784695 + 1.61139411 * temperature + 2.338549 * humidity
              - 0.14611605 * temperature * humidity
              - 0.01230809 * temperature ** 2
              - 0.01642482 * humidity ** 2
              + 0.00221173 * temperature ** 2 * humidity
              + 0.00072546 * temperature * humidity ** 2
              - 0.00000358 * temperature ** 2 * humidity ** 2)

    # Score based on heat index
    if hi < 32:
        heat_factor = 0.0
    elif hi < 40:
        heat_factor = (hi - 32) / 8 * 0.3
    elif hi < 48:
        heat_factor = 0.3 + (hi - 40) / 8 * 0.4
    elif hi < 54:
        heat_factor = 0.7 + (hi - 48) / 6 * 0.2
    else:
        heat_factor = min(0.9 + (hi - 54) / 10 * 0.1, 1.0)

    # Low wind means more heat stress
    wind_mod = max(0.0, 1.0 - wind_speed / 30)
    heat_factor = heat_factor * (0.85 + 0.15 * wind_mod)

    score = min(heat_factor, 1.0)
    amplifier = score / max(ml_base, 0.01)
    return score, amplifier


def _blizzard_score(
    temperature: float,
    humidity: float,
    wind_speed: float,
    pressure: float,
    ml_base: float,
) -> tuple[float, float]:
    """
    Blizzard / dzud risk.
    High risk when: very cold, strong winds, moisture, rapid pressure drop.
    """
    # Temperature must be freezing
    if temperature > 2:
        cold_factor = 0.0
    elif temperature > -10:
        cold_factor = (2 - temperature) / 12 * 0.5
    elif temperature > -30:
        cold_factor = 0.5 + (-10 - temperature) / 20 * 0.4
    else:
        cold_factor = 0.9 + min((-30 - temperature) / 20, 0.1)

    # High winds = blizzard
    wind_factor = min(wind_speed / 70, 1.0)

    # Humidity contributes to snowfall
    hum_factor = min(humidity / 100, 1.0)

    # Low pressure = active storm
    press_factor = max(0.0, (1020 - pressure) / 40)
    press_factor = min(press_factor, 1.0)

    raw = (cold_factor * 0.40 + wind_factor * 0.35 + hum_factor * 0.15 + press_factor * 0.10)
    score = min(raw, 1.0)
    amplifier = score / max(ml_base, 0.01)
    return score, amplifier


def _flood_score(
    ml_base: float,
    humidity: float,
    elapsed_seconds: float,
) -> tuple[float, float]:
    """Standard HIE flood score (pass-through from existing engine)."""
    from src.mias import final_risk_score
    adjusted = final_risk_score(ml_base, humidity, elapsed_seconds)
    amplifier = adjusted / max(ml_base, 0.01)
    return adjusted, amplifier


# ── Alert messages per hazard × tier ──────────────────────────────────────

_ALERT_MESSAGES: dict[str, dict[str, tuple[str, str]]] = {
    "snowfall": {
        "Safe":      ("No significant snowfall expected.", "Normal activities are fine."),
        "Advisory":  ("Light snowfall possible.", "Carry warm clothing & check road conditions."),
        "Watch":     ("Moderate snowfall expected.", "Limit travel, keep de-icer and snow gear ready."),
        "Warning":   ("Heavy snowfall imminent.", "Avoid travel. Stock food & heating fuel. Power may fail."),
        "Emergency": ("EXTREME SNOWFALL / AVALANCHE RISK.", "Stay indoors. Call emergency services if trapped."),
    },
    "sandstorm": {
        "Safe":      ("Air quality is good. No dust storm risk.", "Normal activities are fine."),
        "Advisory":  ("Dusty conditions developing.", "Keep windows closed. Carry a dust mask."),
        "Watch":     ("Sandstorm approaching.", "Stay indoors. Protect eyes & respiratory system."),
        "Warning":   ("Severe sandstorm imminent.", "Do not go outside. Seal doors and windows."),
        "Emergency": ("EXTREME HABOOB / SANDSTORM.", "Evacuate vehicles. Take shelter immediately. Visibility near zero."),
    },
    "heatwave": {
        "Safe":      ("Temperature is manageable.", "Stay hydrated and use sunscreen."),
        "Advisory":  ("Elevated heat stress expected.", "Drink water every 30 min. Avoid midday sun."),
        "Watch":     ("Dangerous heat building.", "Reduce outdoor activity. Check on elderly & children."),
        "Warning":   ("Extreme heat alert.", "Avoid all outdoor activity 11 AM–4 PM. Seek cool shelter."),
        "Emergency": ("LIFE-THREATENING HEAT.", "Move to air-conditioned shelter immediately. Call emergency services for at-risk persons."),
    },
    "blizzard": {
        "Safe":      ("Calm winter conditions.", "Normal winter precautions are sufficient."),
        "Advisory":  ("Cold spell developing.", "Dress in layers. Check heating systems."),
        "Watch":     ("Blizzard watch: strong winds and snow expected.", "Stock emergency supplies. Avoid travel."),
        "Warning":   ("Blizzard warning: dangerous conditions.", "Stay indoors. Roads may become impassable."),
        "Emergency": ("EXTREME BLIZZARD / DZUD.", "Life-threatening conditions. Do not travel. Call 112 for assistance."),
    },
    "flood": {
        "Safe":      ("No significant flood risk.", "Continue normal activities."),
        "Advisory":  ("Elevated moisture detected.", "Prepare emergency kit. Monitor updates."),
        "Watch":     ("Moderate flood risk.", "Avoid drainage channels. Keep emergency bag ready."),
        "Warning":   ("High flood risk.", "Move valuables to high ground. Limit travel."),
        "Emergency": ("EXTREME FLOOD RISK.", "Evacuate immediately. Call 112 for rescue."),
    },
}


def _get_alert_msg(hazard: str, tier_name: str) -> tuple[str, str]:
    tiers = _ALERT_MESSAGES.get(hazard, _ALERT_MESSAGES["flood"])
    return tiers.get(tier_name, tiers["Safe"])


# ── Sensor pipeline notes ──────────────────────────────────────────────────

_SENSOR_NOTES: dict[str, str] = {
    "flood":     "ML rain prob × HIE (Humidity Intelligence Engine) amplification",
    "snowfall":  "SIE: T(°C) × Humidity × Wind × Pressure → snowfall probability",
    "sandstorm": "DIE: Dryness × Wind × Thermal convection → dust storm index",
    "heatwave":  "TIE: Heat Index (Rothfusz) → apparent temperature risk",
    "blizzard":  "BIE: Cold factor × Wind × Humidity × Pressure drop → blizzard index",
}


# ── Main entry point ────────────────────────────────────────────────────────

def compute_hazard_risk(
    city: str,
    ml_base: float,
    temperature: float,
    humidity: float,
    wind_speed: float,
    pressure: float,
    elapsed_seconds: float,
    tier_name: str,
) -> HazardResult:
    """
    Compute hazard-aware risk for a given city and weather conditions.
    Returns a HazardResult with city-appropriate risk score and messaging.
    """
    profile: HazardProfile = get_hazard_profile(city)
    hazard = profile.primary

    if hazard == "snowfall":
        score, amp = _snowfall_score(temperature, humidity, wind_speed, pressure, ml_base)
    elif hazard == "sandstorm":
        score, amp = _sandstorm_score(temperature, humidity, wind_speed, pressure, ml_base)
    elif hazard == "heatwave":
        score, amp = _heatwave_score(temperature, humidity, wind_speed, pressure, ml_base)
    elif hazard == "blizzard":
        score, amp = _blizzard_score(temperature, humidity, wind_speed, pressure, ml_base)
    else:  # flood (default)
        score, amp = _flood_score(ml_base, humidity, elapsed_seconds)

    alert_msg, action_msg = _get_alert_msg(hazard, tier_name)

    return HazardResult(
        hazard_type=hazard,
        primary_score=score,
        raw_score=ml_base,
        amplifier=amp,
        label=profile.risk_label,
        icon=profile.icon,
        color=profile.color,
        risk_label=profile.risk_label,
        alert_msg=alert_msg,
        action_msg=action_msg,
        sensor_note=_SENSOR_NOTES.get(hazard, _SENSOR_NOTES["flood"]),
    )
