"""5-tier risk index aligned with meteorological advisory standards."""

from dataclasses import dataclass


@dataclass(frozen=True)
class RiskTier:
    name: str
    color: str
    hex_color: str
    message: str
    action: str


TIERS = [
    RiskTier(
        "Safe",
        "green",
        "#22c55e",
        "Conditions are stable. No significant rain or flood risk detected.",
        "Continue normal activities. Monitor updates periodically.",
    ),
    RiskTier(
        "Advisory",
        "yellow",
        "#eab308",
        "Elevated moisture detected. Light rain possible in the next few hours.",
        "Stay informed. Secure loose outdoor items.",
    ),
    RiskTier(
        "Watch",
        "orange",
        "#f97316",
        "Moderate rain probability. Localized flooding possible in low-lying areas.",
        "Avoid drainage channels. Check local advisories.",
    ),
    RiskTier(
        "Warning",
        "red",
        "#ef4444",
        "High rain and flood risk. Heavy rainfall likely.",
        "Move valuables to higher ground. Limit travel in flood-prone zones.",
    ),
    RiskTier(
        "Emergency",
        "darkred",
        "#7f1d1d",
        "Extreme flood risk. Life-threatening conditions possible.",
        "Evacuate low-lying areas immediately. Follow emergency services.",
    ),
]

THRESHOLDS = [0.20, 0.40, 0.60, 0.80]


def classify_risk(adjusted_score: float) -> RiskTier:
    """Map adjusted risk score (0–1) to a 5-tier risk level."""
    if adjusted_score < THRESHOLDS[0]:
        return TIERS[0]
    if adjusted_score < THRESHOLDS[1]:
        return TIERS[1]
    if adjusted_score < THRESHOLDS[2]:
        return TIERS[2]
    if adjusted_score < THRESHOLDS[3]:
        return TIERS[3]
    return TIERS[4]
