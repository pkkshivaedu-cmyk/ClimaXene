"""
Multi-hazard profile engine for NOVASENSE.

Maps cities (and their climate zones) to their primary natural hazard risks:
  - Flood / Heavy Rainfall   (original India focus)
  - Snowfall / Blizzard      (Alpine, high-latitude Semi-Arid)
  - Sandstorm / Dust Storm   (Arid / desert interiors)
  - Extreme Heat             (Arid summer cities)
  - Landslide                (Alpine + high humidity mountainous)
  - Drought                  (persistent low-humidity arid)

Each city gets a primary hazard, optional secondary hazard, and
region-specific emergency contacts / agencies.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


# ─── Hazard types ──────────────────────────────────────────────────────────────

class HazardType(str, Enum):
    FLOOD        = "Flood / Heavy Rainfall"
    SNOWFALL     = "Snowfall / Blizzard"
    SANDSTORM    = "Sandstorm / Dust Storm"
    HEAT         = "Extreme Heat"
    LANDSLIDE    = "Landslide / Debris Flow"
    DROUGHT      = "Drought"
    FROST        = "Hard Frost / Freeze"


# ─── Hazard metadata ───────────────────────────────────────────────────────────

@dataclass(frozen=True)
class HazardMeta:
    hazard: HazardType
    icon: str
    color: str           # hex, used in UI
    risk_label: str      # short e.g. "Snowfall Risk"
    score_label: str     # e.g. "Snow Risk"
    description: str     # one-liner shown in UI


HAZARD_META: dict[HazardType, HazardMeta] = {
    HazardType.FLOOD: HazardMeta(
        HazardType.FLOOD, "🌧️", "#3b82f6",
        "Flood / Rainfall Risk", "Flood Risk",
        "Heavy rainfall and flash-flood probability based on humidity, pressure and ML ensemble.",
    ),
    HazardType.SNOWFALL: HazardMeta(
        HazardType.SNOWFALL, "❄️", "#93c5fd",
        "Snowfall / Blizzard Risk", "Snow Risk",
        "Risk of heavy snowfall, whiteout conditions, or blizzard based on temperature and humidity.",
    ),
    HazardType.SANDSTORM: HazardMeta(
        HazardType.SANDSTORM, "🌪️", "#d97706",
        "Sandstorm / Dust Storm Risk", "Dust Risk",
        "Risk of dust storms or sandstorm events driven by high wind, low humidity and arid terrain.",
    ),
    HazardType.HEAT: HazardMeta(
        HazardType.HEAT, "🌡️", "#ef4444",
        "Extreme Heat Risk", "Heat Risk",
        "Dangerous heat stress index based on temperature, humidity and urban heat amplification.",
    ),
    HazardType.LANDSLIDE: HazardMeta(
        HazardType.LANDSLIDE, "⛰️", "#78350f",
        "Landslide / Debris Risk", "Slide Risk",
        "Landslide probability in mountainous terrain amplified by rainfall and soil saturation.",
    ),
    HazardType.DROUGHT: HazardMeta(
        HazardType.DROUGHT, "☀️", "#f59e0b",
        "Drought Stress Risk", "Drought Risk",
        "Prolonged moisture deficit stress in arid/semi-arid zones.",
    ),
    HazardType.FROST: HazardMeta(
        HazardType.FROST, "🥶", "#bfdbfe",
        "Hard Frost / Freeze Risk", "Frost Risk",
        "Risk of hard frost, pipe-freeze or crop damage in cold continental climates.",
    ),
}


# ─── City hazard profile ───────────────────────────────────────────────────────

@dataclass
class CityHazardProfile:
    city: str
    country: str
    region: str                          # human-readable region name
    primary_hazard: HazardType
    secondary_hazard: HazardType | None  # optional second threat
    climate_zone: str
    # Seasonal modifiers: which months amplify each hazard (1=Jan … 12=Dec)
    primary_peak_months: list[int] = field(default_factory=list)
    secondary_peak_months: list[int] = field(default_factory=list)
    # Region-specific emergency contact text
    emergency_agency: str = "National Emergency: 112"
    emergency_note: str = ""


# ─── Per-city profile database ─────────────────────────────────────────────────

_PROFILES: dict[str, CityHazardProfile] = {}


def _reg(profile: CityHazardProfile) -> None:
    _PROFILES[profile.city] = profile


# ── India (original; flood-first) ─────────────────────────────────────────────

for _city in [
    "Mumbai", "Chennai", "Kolkata", "Hyderabad", "Bengaluru", "Pune",
    "Nagpur", "Nashik", "Aurangabad", "Surat", "Thane", "Vadodara",
    "Visakhapatnam", "Vijayawada", "Howrah", "Coimbatore", "Madurai",
    "Patna", "Ranchi", "Dhanbad",
]:
    _reg(CityHazardProfile(
        city=_city, country="India", region="India",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.DROUGHT,
        climate_zone="Coastal/Tropical",
        primary_peak_months=[6, 7, 8, 9, 10],
        secondary_peak_months=[3, 4, 5],
        emergency_agency="NDRF: 011-24363260 | IMD: 1800-180-1717",
        emergency_note="Call 112 (national emergency) or 108 (NDRF/ambulance).",
    ))

for _city in [
    "Delhi", "Jaipur", "Jodhpur", "Rajkot", "Ahmedabad",
    "Indore", "Bhopal", "Gwalior", "Agra", "Meerut",
    "Kanpur", "Lucknow", "Allahabad", "Varanasi", "Ludhiana",
    "Amritsar", "Faridabad", "Ghaziabad", "Jabalpur",
]:
    _reg(CityHazardProfile(
        city=_city, country="India", region="India",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.HEAT,
        climate_zone="Semi-Arid/Subtropical",
        primary_peak_months=[7, 8, 9],
        secondary_peak_months=[5, 6],
        emergency_agency="NDRF: 011-24363260 | IMD: 1800-180-1717",
        emergency_note="Call 112 (national emergency) or 108 (NDRF/ambulance).",
    ))

_reg(CityHazardProfile(
    city="Srinagar", country="India", region="India (Kashmir)",
    primary_hazard=HazardType.SNOWFALL,
    secondary_hazard=HazardType.LANDSLIDE,
    climate_zone="Alpine",
    primary_peak_months=[12, 1, 2, 3],
    secondary_peak_months=[4, 5],
    emergency_agency="J&K SDMA: 0194-2501357 | NDRF: 011-24363260",
    emergency_note="Alert: avalanche & snowfall risk in winter. Landslide risk in spring.",
))

# ── Kazakhstan ────────────────────────────────────────────────────────────────

for _city in ["Almaty", "Taldykorgan"]:
    _reg(CityHazardProfile(
        city=_city, country="Kazakhstan", region="South Kazakhstan",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.LANDSLIDE,
        climate_zone="Semi-Arid (Mountain Foothills)",
        primary_peak_months=[3, 4, 5],
        secondary_peak_months=[4, 5, 6],
        emergency_agency="KZ Emergency: 112 | KZ Ministry of Emergency: +7 717 292-07-77",
        emergency_note="Spring glacial melt + rain = flash flood risk. Mountain slopes: landslide alert.",
    ))

for _city in ["Astana", "Kostanay", "Petropavl"]:
    _reg(CityHazardProfile(
        city=_city, country="Kazakhstan", region="North Kazakhstan",
        primary_hazard=HazardType.FROST,
        secondary_hazard=HazardType.FLOOD,
        climate_zone="Semi-Arid (Continental)",
        primary_peak_months=[11, 12, 1, 2],
        secondary_peak_months=[4, 5],
        emergency_agency="KZ Emergency: 112",
        emergency_note="Severe winter frost & blizzard. Spring snowmelt flooding.",
    ))

for _city in ["Aktobe", "Semey", "Pavlodar", "Ust-Kamenogorsk",
              "Rudny", "Ekibastuz", "Temirtau"]:
    _reg(CityHazardProfile(
        city=_city, country="Kazakhstan", region="Central Kazakhstan",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.FROST,
        climate_zone="Semi-Arid",
        primary_peak_months=[3, 4, 5],
        secondary_peak_months=[11, 12, 1],
        emergency_agency="KZ Emergency: 112",
        emergency_note="Spring snowmelt floods dominant risk. Hard frost in winter.",
    ))

for _city in ["Shymkent", "Taraz", "Kyzylorda", "Turkestan",
              "Atyrau", "Aktau", "Zhanaozen", "Balqash"]:
    _reg(CityHazardProfile(
        city=_city, country="Kazakhstan", region="South/West Kazakhstan",
        primary_hazard=HazardType.SANDSTORM,
        secondary_hazard=HazardType.HEAT,
        climate_zone="Arid",
        primary_peak_months=[4, 5, 6],
        secondary_peak_months=[6, 7, 8],
        emergency_agency="KZ Emergency: 112",
        emergency_note="Dust storms common in spring. Extreme heat in summer.",
    ))

# ── Uzbekistan ────────────────────────────────────────────────────────────────

for _city in [
    "Tashkent", "Samarkand", "Namangan", "Andijan", "Fergana",
    "Margilan", "Navoi", "Gulistan", "Jizzakh", "Kokand",
]:
    _reg(CityHazardProfile(
        city=_city, country="Uzbekistan", region="Uzbekistan",
        primary_hazard=HazardType.HEAT,
        secondary_hazard=HazardType.SANDSTORM,
        climate_zone="Arid",
        primary_peak_months=[6, 7, 8],
        secondary_peak_months=[4, 5],
        emergency_agency="UZ Emergency: 112 | Ministry of Emergency Situations: +998 71 244-43-22",
        emergency_note="Extreme heat risk Jun-Aug. Dust/sandstorm risk Apr-May.",
    ))

for _city in ["Nukus", "Urgench", "Termez", "Qarshi", "Bukhara"]:
    _reg(CityHazardProfile(
        city=_city, country="Uzbekistan", region="Uzbekistan (Arid/Desert)",
        primary_hazard=HazardType.SANDSTORM,
        secondary_hazard=HazardType.HEAT,
        climate_zone="Arid",
        primary_peak_months=[4, 5, 6],
        secondary_peak_months=[6, 7, 8],
        emergency_agency="UZ Emergency: 112",
        emergency_note="Near Karakum/Kyzylkum deserts. Sandstorm and heat are primary risks.",
    ))

# ── Kyrgyzstan ────────────────────────────────────────────────────────────────

for _city in ["Bishkek", "Tokmok", "Kara-Balta", "Balykchy"]:
    _reg(CityHazardProfile(
        city=_city, country="Kyrgyzstan", region="Kyrgyzstan (Chui Valley)",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.LANDSLIDE,
        climate_zone="Semi-Arid (Mountain Piedmont)",
        primary_peak_months=[4, 5, 6, 7],
        secondary_peak_months=[4, 5],
        emergency_agency="KG Emergency: 112 | Ministry of Emergency Situations: +996 312 565-656",
        emergency_note="Glacial melt + rain → spring floods. Mountain slopes: landslide risk.",
    ))

for _city in ["Osh", "Jalal-Abad", "Uzgen", "Batken"]:
    _reg(CityHazardProfile(
        city=_city, country="Kyrgyzstan", region="Kyrgyzstan (South)",
        primary_hazard=HazardType.LANDSLIDE,
        secondary_hazard=HazardType.FLOOD,
        climate_zone="Semi-Arid/Arid",
        primary_peak_months=[4, 5, 6],
        secondary_peak_months=[5, 6, 7],
        emergency_agency="KG Emergency: 112",
        emergency_note="Southern mountains: high landslide risk. Flash floods in gorges.",
    ))

for _city in ["Karakol", "Naryn"]:
    _reg(CityHazardProfile(
        city=_city, country="Kyrgyzstan", region="Kyrgyzstan (Alpine)",
        primary_hazard=HazardType.SNOWFALL,
        secondary_hazard=HazardType.LANDSLIDE,
        climate_zone="Alpine",
        primary_peak_months=[11, 12, 1, 2, 3],
        secondary_peak_months=[5, 6],
        emergency_agency="KG Emergency: 112",
        emergency_note="High-altitude alpine zones. Heavy snowfall and avalanche risk.",
    ))

# ── Tajikistan ────────────────────────────────────────────────────────────────

for _city in ["Dushanbe", "Khujand", "Istaravshan", "Vahdat", "Hisor"]:
    _reg(CityHazardProfile(
        city=_city, country="Tajikistan", region="Tajikistan (Lowland)",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.LANDSLIDE,
        climate_zone="Semi-Arid",
        primary_peak_months=[4, 5, 6],
        secondary_peak_months=[4, 5],
        emergency_agency="TJ Emergency: 112 | Committee on Emergency Situations: +992 37 221-23-29",
        emergency_note="Spring melt floods major risk. Loess slopes: high landslide hazard.",
    ))

for _city in ["Bokhtar", "Qurghonteppa", "Panjakent"]:
    _reg(CityHazardProfile(
        city=_city, country="Tajikistan", region="Tajikistan (South)",
        primary_hazard=HazardType.HEAT,
        secondary_hazard=HazardType.FLOOD,
        climate_zone="Arid",
        primary_peak_months=[6, 7, 8],
        secondary_peak_months=[4, 5],
        emergency_agency="TJ Emergency: 112",
        emergency_note="Extreme heat in Vakhsh valley. Spring rain-on-snow flooding.",
    ))

_reg(CityHazardProfile(
    city="Khorugh", country="Tajikistan", region="Tajikistan (Pamir Alpine)",
    primary_hazard=HazardType.SNOWFALL,
    secondary_hazard=HazardType.LANDSLIDE,
    climate_zone="Alpine",
    primary_peak_months=[11, 12, 1, 2, 3],
    secondary_peak_months=[5, 6],
    emergency_agency="TJ Emergency: 112",
    emergency_note="Pamir high-altitude zone. Avalanche and snowfall primary risk.",
))

_reg(CityHazardProfile(
    city="Kulob", country="Tajikistan", region="Tajikistan (South Mountains)",
    primary_hazard=HazardType.LANDSLIDE,
    secondary_hazard=HazardType.FLOOD,
    climate_zone="Semi-Arid",
    primary_peak_months=[4, 5, 6],
    secondary_peak_months=[5, 6],
    emergency_agency="TJ Emergency: 112",
    emergency_note="Mountainous southern zone. Landslide-prone slopes.",
))

# ── Turkmenistan ──────────────────────────────────────────────────────────────

for _city in [
    "Ashgabat", "Mary", "Turkmenabat", "Bayramaly", "Tejen",
    "Serdar", "Sarahs",
]:
    _reg(CityHazardProfile(
        city=_city, country="Turkmenistan", region="Turkmenistan (Desert)",
        primary_hazard=HazardType.SANDSTORM,
        secondary_hazard=HazardType.HEAT,
        climate_zone="Arid",
        primary_peak_months=[4, 5, 6],
        secondary_peak_months=[6, 7, 8],
        emergency_agency="TM Emergency: 112 | State Emergency Management: +993 12 39-23-93",
        emergency_note="Karakum Desert proximity. Severe sandstorms and extreme heat.",
    ))

for _city in ["Turkmenbashi", "Balkanabat"]:
    _reg(CityHazardProfile(
        city=_city, country="Turkmenistan", region="Turkmenistan (Caspian)",
        primary_hazard=HazardType.SANDSTORM,
        secondary_hazard=HazardType.FLOOD,
        climate_zone="Arid",
        primary_peak_months=[4, 5, 6],
        secondary_peak_months=[3, 4],
        emergency_agency="TM Emergency: 112",
        emergency_note="Caspian coastal and desert zone. Sandstorm dominant; spring flood from Caspian.",
    ))

_reg(CityHazardProfile(
    city="Dashoguz", country="Turkmenistan", region="Turkmenistan (North)",
    primary_hazard=HazardType.SANDSTORM,
    secondary_hazard=HazardType.FROST,
    climate_zone="Arid",
    primary_peak_months=[4, 5, 6],
    secondary_peak_months=[12, 1, 2],
    emergency_agency="TM Emergency: 112",
    emergency_note="Near Aral Sea basin. Dust storms; cold winters with frost risk.",
))

# ── Afghanistan ───────────────────────────────────────────────────────────────

for _city in ["Kabul", "Mazar-i-Sharif", "Kunduz", "Taloqan", "Baghlan"]:
    _reg(CityHazardProfile(
        city=_city, country="Afghanistan", region="Afghanistan (Lowland/Valley)",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.SANDSTORM,
        climate_zone="Arid",
        primary_peak_months=[3, 4, 5],
        secondary_peak_months=[6, 7, 8],
        emergency_agency="AF Emergency: 119 | ANDMA: +93 20 220-0588",
        emergency_note="Spring rain and snowmelt floods. Summer dust storms.",
    ))

for _city in ["Kandahar", "Jalalabad"]:
    _reg(CityHazardProfile(
        city=_city, country="Afghanistan", region="Afghanistan (South/East)",
        primary_hazard=HazardType.HEAT,
        secondary_hazard=HazardType.SANDSTORM,
        climate_zone="Arid",
        primary_peak_months=[6, 7, 8],
        secondary_peak_months=[5, 6],
        emergency_agency="AF Emergency: 119",
        emergency_note="Extreme heat in south. Wind-driven dust storms.",
    ))

for _city in ["Herat"]:
    _reg(CityHazardProfile(
        city=_city, country="Afghanistan", region="Afghanistan (West)",
        primary_hazard=HazardType.SANDSTORM,
        secondary_hazard=HazardType.FLOOD,
        climate_zone="Arid",
        primary_peak_months=[5, 6, 7],
        secondary_peak_months=[3, 4],
        emergency_agency="AF Emergency: 119",
        emergency_note="120-day wind (Sad-o-Bist Roza) → severe sandstorm season.",
    ))

for _city in ["Ghazni", "Bamyan"]:
    _reg(CityHazardProfile(
        city=_city, country="Afghanistan", region="Afghanistan (Highland)",
        primary_hazard=HazardType.SNOWFALL,
        secondary_hazard=HazardType.FLOOD,
        climate_zone="Alpine",
        primary_peak_months=[12, 1, 2, 3],
        secondary_peak_months=[4, 5],
        emergency_agency="AF Emergency: 119",
        emergency_note="High-altitude plateau. Heavy snow; spring melt floods.",
    ))

# ── Mongolia ──────────────────────────────────────────────────────────────────

for _city in ["Ulaanbaatar", "Erdenet", "Darkhan"]:
    _reg(CityHazardProfile(
        city=_city, country="Mongolia", region="Mongolia (Central)",
        primary_hazard=HazardType.FROST,
        secondary_hazard=HazardType.SANDSTORM,
        climate_zone="Semi-Arid",
        primary_peak_months=[11, 12, 1, 2, 3],
        secondary_peak_months=[3, 4, 5],
        emergency_agency="MN Emergency: 105/102 | NEMA: +976 11 312-418",
        emergency_note="Extreme continental winters (-40°C possible). Spring dzud/dust storms.",
    ))

for _city in ["Khovd", "Murun"]:
    _reg(CityHazardProfile(
        city=_city, country="Mongolia", region="Mongolia (West/North)",
        primary_hazard=HazardType.FROST,
        secondary_hazard=HazardType.FLOOD,
        climate_zone="Arid/Semi-Arid",
        primary_peak_months=[11, 12, 1, 2],
        secondary_peak_months=[5, 6],
        emergency_agency="MN Emergency: 105",
        emergency_note="Severe continental frost. Spring river floods from snowmelt.",
    ))

# ── Georgia ───────────────────────────────────────────────────────────────────

for _city in ["Tbilisi", "Rustavi"]:
    _reg(CityHazardProfile(
        city=_city, country="Georgia", region="Georgia (Eastern)",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.LANDSLIDE,
        climate_zone="Subtropical",
        primary_peak_months=[5, 6, 7],
        secondary_peak_months=[5, 6],
        emergency_agency="GE Emergency: 112 | EMSA: +995 32 291-91-91",
        emergency_note="Flash floods (Vere/Mtkvari rivers). Landslide risk on slopes.",
    ))

_reg(CityHazardProfile(
    city="Batumi", country="Georgia", region="Georgia (Black Sea Coast)",
    primary_hazard=HazardType.FLOOD,
    secondary_hazard=HazardType.LANDSLIDE,
    climate_zone="Coastal",
    primary_peak_months=[10, 11, 12, 1, 2],
    secondary_peak_months=[5, 6],
    emergency_agency="GE Emergency: 112",
    emergency_note="Highest rainfall in Caucasus. Year-round flood risk; landslides on Adjara mountains.",
))

for _city in ["Kutaisi", "Zugdidi"]:
    _reg(CityHazardProfile(
        city=_city, country="Georgia", region="Georgia (Western)",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.LANDSLIDE,
        climate_zone="Humid Subtropical",
        primary_peak_months=[4, 5, 6, 10, 11],
        secondary_peak_months=[5, 6],
        emergency_agency="GE Emergency: 112",
        emergency_note="High annual rainfall. River flooding and mudslide risk.",
    ))

# ── Azerbaijan ────────────────────────────────────────────────────────────────

for _city in ["Baku", "Sumqayit"]:
    _reg(CityHazardProfile(
        city=_city, country="Azerbaijan", region="Azerbaijan (Caspian)",
        primary_hazard=HazardType.SANDSTORM,
        secondary_hazard=HazardType.FLOOD,
        climate_zone="Semi-Arid",
        primary_peak_months=[3, 4, 5],
        secondary_peak_months=[4, 5],
        emergency_agency="AZ Emergency: 112 | Ministry of Emergency Situations: +994 12 493-16-76",
        emergency_note="Khazri (north wind) drives dust storms. Spring Caspian flooding.",
    ))

for _city in ["Ganja", "Mingachevir"]:
    _reg(CityHazardProfile(
        city=_city, country="Azerbaijan", region="Azerbaijan (Interior)",
        primary_hazard=HazardType.FLOOD,
        secondary_hazard=HazardType.HEAT,
        climate_zone="Semi-Arid",
        primary_peak_months=[4, 5, 6],
        secondary_peak_months=[7, 8],
        emergency_agency="AZ Emergency: 112",
        emergency_note="Kura river flood risk. Hot dry summers.",
    ))

_reg(CityHazardProfile(
    city="Nakhchivan", country="Azerbaijan", region="Azerbaijan (Exclave)",
    primary_hazard=HazardType.HEAT,
    secondary_hazard=HazardType.SANDSTORM,
    climate_zone="Arid",
    primary_peak_months=[6, 7, 8],
    secondary_peak_months=[5, 6],
    emergency_agency="AZ Emergency: 112",
    emergency_note="Enclosed valley, hot summers. Dust from surrounding steppes.",
))


# ─── Lookup functions ──────────────────────────────────────────────────────────

def get_profile(city: str) -> CityHazardProfile | None:
    """Return the hazard profile for a city, or None if not registered."""
    return _PROFILES.get(city)


def get_profile_by_climate(climate_zone: str, city: str) -> CityHazardProfile:
    """
    Fallback: derive a sensible profile from climate zone when no specific
    city profile exists.
    """
    zone = climate_zone.lower()
    if "alpine" in zone:
        h, s = HazardType.SNOWFALL, HazardType.LANDSLIDE
        region = "Alpine/Mountain Region"
        agency = "National Emergency: 112"
    elif "coastal" in zone:
        h, s = HazardType.FLOOD, HazardType.HEAT
        region = "Coastal Region"
        agency = "National Emergency: 112"
    elif "arid" in zone and "semi" not in zone:
        h, s = HazardType.SANDSTORM, HazardType.HEAT
        region = "Arid/Desert Region"
        agency = "National Emergency: 112"
    elif "semi-arid" in zone or "semi arid" in zone:
        h, s = HazardType.FLOOD, HazardType.HEAT
        region = "Semi-Arid Region"
        agency = "National Emergency: 112"
    elif "tropical" in zone or "humid subtropical" in zone:
        h, s = HazardType.FLOOD, HazardType.HEAT
        region = "Tropical/Humid Region"
        agency = "National Emergency: 112"
    else:
        h, s = HazardType.FLOOD, HazardType.HEAT
        region = "Mixed Climate Region"
        agency = "National Emergency: 112"

    return CityHazardProfile(
        city=city, country="Unknown", region=region,
        primary_hazard=h, secondary_hazard=s,
        climate_zone=climate_zone,
        primary_peak_months=[],
        secondary_peak_months=[],
        emergency_agency=agency,
        emergency_note="",
    )


# ─── Hazard scoring functions ──────────────────────────────────────────────────

def score_flood(temperature: float, humidity: float, pressure: float,
                dew_point: float, wind_speed: float) -> float:
    """Original flood probability proxy (0-1)."""
    hum_factor = max(0.0, (humidity - 50) / 50)
    pressure_factor = max(0.0, (1015 - pressure) / 30)
    dew_factor = max(0.0, (dew_point - 10) / 20)
    wind_factor = min(wind_speed / 80, 1.0)
    raw = 0.40 * hum_factor + 0.30 * pressure_factor + 0.20 * dew_factor + 0.10 * wind_factor
    return min(raw, 1.0)


def score_snowfall(temperature: float, humidity: float, wind_speed: float) -> float:
    """Snowfall/blizzard risk (0-1). Peaks when temp < 0°C + high humidity + wind."""
    if temperature > 4.0:
        return 0.0
    temp_factor = max(0.0, (4.0 - temperature) / 20)   # 0 at 4°C, 1 at -16°C
    hum_factor = max(0.0, (humidity - 40) / 60)
    wind_factor = min(wind_speed / 70, 1.0)
    # Blizzard amplification when all three combine
    raw = 0.50 * temp_factor + 0.30 * hum_factor + 0.20 * wind_factor
    blizzard_amp = 1.0 + 0.5 * temp_factor * hum_factor * wind_factor
    return min(raw * blizzard_amp, 1.0)


def score_sandstorm(temperature: float, humidity: float, wind_speed: float,
                    pressure: float) -> float:
    """Sandstorm/dust storm risk (0-1). High wind + low humidity = danger."""
    if humidity > 55:
        return 0.0
    dryness = max(0.0, (55 - humidity) / 55)
    wind_factor = min(max(0.0, (wind_speed - 15) / 65), 1.0)
    pressure_factor = max(0.0, (pressure - 1005) / 15)  # rising pressure drives winds
    raw = 0.50 * wind_factor + 0.35 * dryness + 0.15 * pressure_factor
    return min(raw, 1.0)


def score_heat(temperature: float, humidity: float) -> float:
    """Extreme heat / heat-stress risk (0-1)."""
    if temperature < 30:
        return 0.0
    temp_factor = min((temperature - 30) / 20, 1.0)
    # Wet-bulb: high humidity amplifies heat risk significantly
    humidity_amp = 1.0 + 0.8 * (humidity / 100) if humidity > 40 else 1.0
    raw = temp_factor * humidity_amp
    return min(raw, 1.0)


def score_landslide(temperature: float, humidity: float, pressure: float,
                    wind_speed: float) -> float:
    """Landslide risk (0-1) — for alpine/mountainous zones."""
    hum_factor = max(0.0, (humidity - 60) / 40)
    pressure_drop = max(0.0, (1015 - pressure) / 25)
    wind_factor = min(wind_speed / 60, 1.0)
    raw = 0.50 * hum_factor + 0.30 * pressure_drop + 0.20 * wind_factor
    return min(raw, 1.0)


def score_frost(temperature: float, humidity: float, wind_speed: float) -> float:
    """Hard frost / freeze risk (0-1)."""
    if temperature > 5:
        return 0.0
    temp_factor = max(0.0, (5 - temperature) / 35)   # scales from 5°C to -30°C
    # Wind chill amplification
    wind_chill = 1.0 + 0.4 * min(wind_speed / 50, 1.0)
    raw = temp_factor * wind_chill
    return min(raw, 1.0)


def score_drought(humidity: float, temperature: float) -> float:
    """Drought stress proxy (0-1)."""
    if humidity > 40:
        return 0.0
    dryness = max(0.0, (40 - humidity) / 40)
    heat_amp = 1.0 + 0.5 * max(0, (temperature - 25) / 25)
    return min(dryness * heat_amp, 1.0)


def compute_primary_score(
    profile: CityHazardProfile,
    temperature: float,
    humidity: float,
    pressure: float,
    dew_point: float,
    wind_speed: float,
) -> float:
    """Compute the primary hazard score (0-1) for the given city profile."""
    h = profile.primary_hazard
    if h == HazardType.FLOOD:
        return score_flood(temperature, humidity, pressure, dew_point, wind_speed)
    if h == HazardType.SNOWFALL:
        return score_snowfall(temperature, humidity, wind_speed)
    if h == HazardType.SANDSTORM:
        return score_sandstorm(temperature, humidity, wind_speed, pressure)
    if h == HazardType.HEAT:
        return score_heat(temperature, humidity)
    if h == HazardType.LANDSLIDE:
        return score_landslide(temperature, humidity, pressure, wind_speed)
    if h == HazardType.FROST:
        return score_frost(temperature, humidity, wind_speed)
    if h == HazardType.DROUGHT:
        return score_drought(humidity, temperature)
    return 0.0


def compute_secondary_score(
    profile: CityHazardProfile,
    temperature: float,
    humidity: float,
    pressure: float,
    dew_point: float,
    wind_speed: float,
) -> float | None:
    """Compute the secondary hazard score (0-1) or None if no secondary hazard."""
    if profile.secondary_hazard is None:
        return None
    h = profile.secondary_hazard
    if h == HazardType.FLOOD:
        return score_flood(temperature, humidity, pressure, dew_point, wind_speed)
    if h == HazardType.SNOWFALL:
        return score_snowfall(temperature, humidity, wind_speed)
    if h == HazardType.SANDSTORM:
        return score_sandstorm(temperature, humidity, wind_speed, pressure)
    if h == HazardType.HEAT:
        return score_heat(temperature, humidity)
    if h == HazardType.LANDSLIDE:
        return score_landslide(temperature, humidity, pressure, wind_speed)
    if h == HazardType.FROST:
        return score_frost(temperature, humidity, wind_speed)
    if h == HazardType.DROUGHT:
        return score_drought(humidity, temperature)
    return None
