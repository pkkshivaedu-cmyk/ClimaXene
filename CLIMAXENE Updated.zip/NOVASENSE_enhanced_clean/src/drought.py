"""Drought risk — inverse MXene logic (low humidity activation + saturation)."""

from __future__ import annotations

from src.mias import (
    DEFAULT_ELAPSED_SECONDS,
    DEFAULT_K_ACTIVATION,
    MAX_AMPLIFICATION,
    activation,
    saturation,
    time_response,
)


def drought_response(
    humidity: float,
    elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS,
    *,
    rh_critical: float = 40.0,
    alpha: float = 0.03,
    tau_seconds: float = 1.0,
) -> float:
    drought_activation = 1.0 - activation(humidity, rh_critical=rh_critical, k=DEFAULT_K_ACTIVATION)
    site_limit = 1.0 - saturation(humidity, alpha=alpha)
    tr = time_response(elapsed_seconds, tau_seconds=tau_seconds)
    return drought_activation * site_limit * tr


def drought_factor(humidity: float, elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS) -> float:
    return 1.0 + MAX_AMPLIFICATION * drought_response(humidity, elapsed_seconds)


def drought_risk_score(
    base_prob: float,
    humidity: float,
    temperature: float,
    elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS,
) -> float:
    temp_stress = min(max((temperature - 32) / 15, 0), 1) * 0.15
    raw = base_prob * drought_factor(humidity, elapsed_seconds) + temp_stress
    return min(raw, 1.0)
