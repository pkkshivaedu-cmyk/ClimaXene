"""Multi-hazard Disaster Assistant for NOVASENSE.

Provides contextual guidance based on the primary hazard profile of each city
(flood, snowfall, sandstorm, extreme heat, landslide, frost, drought).
"""

from __future__ import annotations

import re

from src.hazard_profile import HazardType

# ── Generic tier actions (used when hazard-specific not found) ─────────────────

_TIER_ACTIONS_GENERIC: dict[str, str] = {
    "Safe": "✅ No immediate action required. Stay informed and monitor conditions.",
    "Advisory": (
        "⚠️ **Advisory level active.**\n"
        "• Prepare a 72-hour emergency kit (water, food, torch, first aid).\n"
        "• Stay tuned to official alerts and local news."
    ),
    "Watch": (
        "🟠 **Watch level active.**\n"
        "• Take precautionary measures based on your city's primary hazard.\n"
        "• Avoid high-risk zones.\n"
        "• Keep family informed of your location."
    ),
    "Warning": (
        "🔴 **Warning level active — take immediate action!**\n"
        "• Follow all local authority advisories.\n"
        "• Keep emergency contacts on speed dial.\n"
        "• Monitor for evacuation orders."
    ),
    "Emergency": (
        "🆘 **EMERGENCY — Evacuate immediately!**\n"
        "• Follow official evacuation routes only.\n"
        "• Call your national emergency number for rescue assistance."
    ),
}

# ── Hazard-specific preparedness knowledge ─────────────────────────────────────

_PREPAREDNESS: dict[HazardType, str] = {

    HazardType.FLOOD: """
**Before a flood:**
• Store drinking water, dry food, medicines and important documents in a waterproof bag.
• Charge all devices and keep a battery-powered torch ready.
• Know your nearest evacuation route and community shelter.
• Move electrical appliances and valuables to higher shelves.

**During a flood:**
• Stay indoors; avoid walking or driving through flooded streets.
• Do not touch electrical switches or wiring in wet conditions.
• Move to the highest floor if water is entering your home.
• Call national emergency services for help.

**After a flood:**
• Wait for official "all-clear" before returning home.
• Boil drinking water; avoid floodwater contact — it may carry disease.
• Check for structural damage before re-entering buildings.
• Report gas leaks or fallen power lines immediately.
""".strip(),

    HazardType.SNOWFALL: """
**Before a snowstorm/blizzard:**
• Stock at least 3 days of food, water, medicines and fuel.
• Insulate your home — check pipes, windows and doors.
• Prepare a vehicle emergency kit: blankets, shovel, sand/salt, booster cables.
• Charge all devices; have a battery radio for news.

**During heavy snowfall/blizzard:**
• Stay indoors; avoid travel unless absolutely necessary.
• If caught outside: seek shelter immediately; never lie down in snow.
• Do NOT use generators or gas heaters indoors — carbon monoxide risk.
• Keep exits clear of snow accumulation.

**After a blizzard:**
• Check on elderly or vulnerable neighbours.
• Clear snow from roofs cautiously — avalanche/collapse risk.
• Watch for black ice when roads reopen.
• Report downed power lines to authorities.
""".strip(),

    HazardType.SANDSTORM: """
**Before a sandstorm:**
• Seal windows and doors with damp towels or tape.
• Prepare N95 masks or damp cloth face coverings.
• Stock water, food and medications — roads may close.
• Park vehicles in a sheltered position, away from trees.

**During a sandstorm:**
• Stay indoors and keep windows/doors closed.
• If caught outdoors: cover nose and mouth; take shelter behind solid objects; do not drive.
• Turn on hazard lights if driving; pull off road slowly and stay in vehicle.
• Protect eyes with goggles; do not rub eyes.

**After a sandstorm:**
• Wear a mask when outdoors — fine particles remain suspended.
• Check water sources and food for contamination.
• Inspect buildings for structural damage and clear sand from drains.
• Seek medical help if you experience breathing difficulties.
""".strip(),

    HazardType.HEAT: """
**Before extreme heat:**
• Identify your nearest cooling centre (library, mall, community hall).
• Stock oral rehydration salts, water and electrolyte drinks.
• Install reflective window film or external shading.
• Check on elderly, children and outdoor workers in your community.

**During extreme heat:**
• Stay indoors in the coolest room, especially 11:00–17:00.
• Drink 2–3 litres of water per day even without thirst.
• Avoid strenuous outdoor activity; wear light, loose, light-coloured clothing.
• Use fans + damp cloth on neck/wrists to cool down; avoid ice baths (shock risk).

**Warning signs of heat stroke:**
• Confusion, no sweating, skin hot and dry, body temp above 40°C → medical emergency.
• Call emergency services and move person to shade immediately.
• Apply cool water to skin while waiting for help.
""".strip(),

    HazardType.LANDSLIDE: """
**Before a landslide event:**
• Learn if your area is on a landslide-prone slope — consult local hazard maps.
• Know evacuation routes leading away from hillsides and gorges.
• Watch for warning signs: new cracks in walls, tilting trees, unusual water flows.
• Secure drainage around your home to prevent soil saturation.

**During heavy rain in landslide-prone areas:**
• Evacuate immediately if local authorities issue a warning.
• Avoid river gorges, valleys and slopes during or after heavy rain.
• If caught on a slope: move perpendicular to the flow direction, not down the slope.
• Listen for rumbling sounds — they may precede a debris flow.

**After a landslide:**
• Do NOT re-enter slide area — secondary slides are common.
• Check for injured persons and call emergency services.
• Watch for broken gas, water and power lines.
• Report the incident to local disaster management authority.
""".strip(),

    HazardType.FROST: """
**Before a hard frost:**
• Insulate water pipes and outdoor taps — wrap with foam or cloth.
• Stock additional heating fuel; have backup heating source ready.
• Protect vehicles: antifreeze levels, battery health, winter tyres.
• Prepare emergency supplies in case roads become impassable.

**During extreme frost:**
• Stay indoors and layer clothing; keep extremities covered.
• Never use outdoor gas equipment, charcoal or wood-burning devices indoors.
• Check on livestock, pets and vulnerable people in your community.
• Reduce thermostat draughts; block gaps under doors.

**After a frost event:**
• Inspect pipes for bursting or cracking; turn off mains water if pipes burst.
• Treat outdoor walkways with sand/salt before clearing ice.
• Report downed power lines from ice weight to authorities.
""".strip(),

    HazardType.DROUGHT: """
**During drought / water shortage:**
• Limit water use to essential needs — drinking, cooking, hygiene.
• Repair all leaking taps, pipes and cisterns immediately.
• Collect and reuse grey water for non-drinking purposes.
• Avoid irrigating crops or gardens during peak heat hours.

**Health risks during drought:**
• Dust exposure increases — use face masks outdoors.
• Wildfire risk rises — maintain clear firebreaks around buildings.
• Protect stored food and water from heat-induced spoilage.
• Monitor livestock health and supplement feed if pasture fails.

**Longer-term:**
• Report critical water shortages to local authorities.
• Follow government water-rationing guidelines strictly.
""".strip(),
}

# ── Hazard-specific tier emergency actions ─────────────────────────────────────

_TIER_ACTIONS: dict[HazardType, dict[str, str]] = {

    HazardType.SNOWFALL: {
        "Safe":      "✅ No significant snowfall risk. Normal travel conditions.",
        "Advisory":  "⚠️ Snow possible — check tyre condition and carry blankets in vehicles.",
        "Watch":     "🟠 Heavy snowfall likely. Limit travel; prepare heating fuel supplies.",
        "Warning":   "🔴 Blizzard warning — stay indoors. Do NOT travel. Heat source & food stocks essential.",
        "Emergency": "🆘 Whiteout/blizzard EMERGENCY. Stay sheltered. Call emergency services if trapped.",
    },

    HazardType.SANDSTORM: {
        "Safe":      "✅ No dust storm risk. Normal outdoor conditions.",
        "Advisory":  "⚠️ Reduced visibility possible. Wear a mask if going outside.",
        "Watch":     "🟠 Sandstorm likely. Seal windows. Avoid outdoor travel.",
        "Warning":   "🔴 Severe sandstorm — remain indoors. Protect airways. Avoid driving.",
        "Emergency": "🆘 EXTREME DUST EVENT. Do NOT go outside. If trapped in vehicle, pull over and stay inside.",
    },

    HazardType.HEAT: {
        "Safe":      "✅ Temperatures within normal range. Stay hydrated.",
        "Advisory":  "⚠️ Heat advisory — drink water regularly; limit midday outdoor activity.",
        "Watch":     "🟠 Heat watch — check on vulnerable people. Use cooling centres.",
        "Warning":   "🔴 Dangerous heat — minimise all outdoor exposure. Emergency cooling required.",
        "Emergency": "🆘 LIFE-THREATENING HEAT. Move to cool environment immediately. Call emergency services for heat stroke.",
    },

    HazardType.LANDSLIDE: {
        "Safe":      "✅ Stable slopes. No immediate landslide risk.",
        "Advisory":  "⚠️ Watch slopes and drainage. Moderate rain forecast.",
        "Watch":     "🟠 Landslide watch — evacuate vulnerable slope-side properties.",
        "Warning":   "🔴 Landslide warning — evacuate from hillsides and gorges NOW.",
        "Emergency": "🆘 ACTIVE LANDSLIDE RISK. Evacuate immediately. Call emergency services.",
    },

    HazardType.FROST: {
        "Safe":      "✅ Above freezing. No frost risk.",
        "Advisory":  "⚠️ Frost possible overnight. Protect pipes and outdoor plants.",
        "Watch":     "🟠 Hard frost expected. Insulate pipes; bring animals indoors.",
        "Warning":   "🔴 Severe frost — protect infrastructure. Limit outdoor activity.",
        "Emergency": "🆘 EXTREME FREEZE. Pipes at high burst risk. Seek shelter. Call emergency services if needed.",
    },

    HazardType.DROUGHT: {
        "Safe":      "✅ Moisture levels adequate. No drought stress.",
        "Advisory":  "⚠️ Moisture slightly below normal. Conserve water.",
        "Watch":     "🟠 Drought watch — implement water conservation measures.",
        "Warning":   "🔴 Severe drought — emergency water rationing advised.",
        "Emergency": "🆘 CRITICAL DROUGHT. Water supply may fail. Follow government emergency orders.",
    },
}

# ── Regional emergency contact overrides ───────────────────────────────────────

_COUNTRY_CONTACTS: dict[str, str] = {
    "India": (
        "**Emergency:** 112\n"
        "**Ambulance / NDRF:** 108\n"
        "**NDRF HQ:** 011-24363260\n"
        "**IMD Flood Forecast:** 1800-180-1717 (toll-free)\n"
        "**Police:** 100 | **Fire:** 101"
    ),
    "Kazakhstan": (
        "**Emergency:** 112\n"
        "**Ministry of Emergency Situations:** +7 717 292-07-77\n"
        "**Police:** 102 | **Ambulance:** 103 | **Fire:** 101"
    ),
    "Uzbekistan": (
        "**Emergency:** 112\n"
        "**Ministry of Emergency Situations:** +998 71 244-43-22\n"
        "**Police:** 102 | **Ambulance:** 103 | **Fire:** 101"
    ),
    "Kyrgyzstan": (
        "**Emergency:** 112\n"
        "**Ministry of Emergency Situations:** +996 312 565-656\n"
        "**Police:** 102 | **Ambulance:** 103 | **Fire:** 101"
    ),
    "Tajikistan": (
        "**Emergency:** 112\n"
        "**Committee on Emergency Situations:** +992 37 221-23-29\n"
        "**Police:** 02 | **Ambulance:** 03 | **Fire:** 01"
    ),
    "Turkmenistan": (
        "**Emergency:** 112\n"
        "**State Emergency Management:** +993 12 39-23-93\n"
        "**Police:** 02 | **Ambulance:** 03 | **Fire:** 01"
    ),
    "Afghanistan": (
        "**Emergency:** 119\n"
        "**ANDMA (Disaster Mgmt Authority):** +93 20 220-0588\n"
        "**Police:** 119 | **Ambulance:** 112"
    ),
    "Mongolia": (
        "**Emergency:** 105 / 102\n"
        "**National Emergency Management Agency:** +976 11 312-418\n"
        "**Police:** 102 | **Ambulance:** 103 | **Fire:** 101"
    ),
    "Georgia": (
        "**Emergency:** 112\n"
        "**Emergency Management Services Agency:** +995 32 291-91-91\n"
        "**Police:** 112 | **Ambulance:** 112 | **Fire:** 112"
    ),
    "Azerbaijan": (
        "**Emergency:** 112\n"
        "**Ministry of Emergency Situations:** +994 12 493-16-76\n"
        "**Police:** 102 | **Ambulance:** 103 | **Fire:** 101"
    ),
}

# ── Intent matching ────────────────────────────────────────────────────────────

_INTENTS: list[tuple[list[str], str]] = [
    (["what should i do", "what to do", "how to stay safe", "safety tips",
      "safe during", "stay safe", "protect myself"], "preparedness"),
    (["explain risk", "current risk", "what is the risk", "risk level",
      "risk score", "how risky", "how dangerous"], "explain_risk"),
    (["emergency action", "emergency steps", "emergency procedure",
      "what to do in emergency", "evacuate", "evacuation"], "emergency_actions"),
    (["disaster preparedness", "prepare for disaster", "prepare for flood",
      "flood preparedness", "snow preparedness", "sandstorm preparedness",
      "be prepared", "prepare", "getting ready"], "preparedness"),
    (["contact", "helpline", "phone number", "emergency number",
      "who to call", "ndrf", "authority", "call"], "contacts"),
    (["what hazard", "what risk", "what type of risk", "primary hazard",
      "city risk", "what disaster", "what danger"], "hazard_type"),
    (["hello", "hi", "hey", "namaste", "vanakkam", "salam", "help", "start"], "greet"),
]


def _match_intent(query: str) -> str:
    q = query.lower().strip()
    q = re.sub(r"[^\w\s]", " ", q)
    for keywords, intent in _INTENTS:
        for kw in keywords:
            if kw in q:
                return intent
    return "unknown"


# ── Main response generator ────────────────────────────────────────────────────

def get_response(
    query: str,
    *,
    city: str = "your city",
    tier_name: str = "Safe",
    risk_pct: float = 0.0,
    ml_prob: float = 0.0,
    mias_factor: float = 1.0,
    confidence: float = 90.0,
    hazard_type: HazardType | None = None,
    country: str = "India",
    secondary_hazard: HazardType | None = None,
    primary_score: float = 0.0,
    secondary_score: float | None = None,
) -> str:
    """Return a hazard-aware response for the given query and risk context."""
    intent = _match_intent(query)
    ht = hazard_type or HazardType.FLOOD
    from src.hazard_profile import HAZARD_META
    meta = HAZARD_META[ht]

    if intent == "greet":
        sec_txt = ""
        if secondary_hazard:
            sec_meta = HAZARD_META[secondary_hazard]
            sec_txt = f"\n• Secondary risk: **{secondary_hazard.value}** {sec_meta.icon}"
        return (
            f"{meta.icon} Hello! I'm the **NOVASENSE Multi-Hazard Assistant**.\n\n"
            f"For **{city}**, the primary monitored hazard is:\n"
            f"**{ht.value}** {meta.icon}{sec_txt}\n\n"
            f"I can help you with:\n"
            f"• What to do during a **{ht.value.lower()}** event\n"
            f"• Understanding the current risk level for **{city}**\n"
            f"• Emergency actions and local contacts\n"
            f"• Disaster preparedness guidance\n\n"
            f"Try asking: *\"What should I do during a {ht.value.lower()}?\"* or *\"Explain current risk\"*"
        )

    if intent == "hazard_type":
        sec_txt = ""
        if secondary_hazard and secondary_score is not None:
            sec_meta = HAZARD_META[secondary_hazard]
            sec_txt = (
                f"\n\n**Secondary hazard:** {secondary_hazard.value} {sec_meta.icon}\n"
                f"Secondary risk score: **{secondary_score * 100:.0f}%**\n"
                f"_{sec_meta.description}_"
            )
        return (
            f"{meta.icon} **Primary hazard for {city}:** {ht.value}\n\n"
            f"_{meta.description}_\n\n"
            f"Current {meta.score_label}: **{primary_score * 100:.0f}%** (tier: **{tier_name}**)"
            + sec_txt
        )

    if intent == "explain_risk":
        tier_actions = _TIER_ACTIONS.get(ht, _TIER_ACTIONS_GENERIC)
        action = tier_actions.get(tier_name, _TIER_ACTIONS_GENERIC.get(tier_name, ""))
        sec_txt = ""
        if secondary_hazard and secondary_score is not None:
            sec_meta = HAZARD_META[secondary_hazard]
            sec_txt = (
                f"\n\n**Secondary {secondary_hazard.value} risk:** {secondary_score * 100:.0f}%"
            )
        return (
            f"The current **{meta.risk_label}** for **{city}** is **{tier_name}** "
            f"({risk_pct:.0f}% risk score).\n\n"
            f"This is based on:\n"
            f"• ML ensemble probability: {ml_prob * 100:.0f}%\n"
            f"• HIE amplification factor: {mias_factor:.2f}×\n"
            f"• Model confidence: {confidence:.0f}%\n"
            + sec_txt + "\n\n" + action
        )

    if intent == "emergency_actions":
        tier_actions = _TIER_ACTIONS.get(ht, _TIER_ACTIONS_GENERIC)
        action = tier_actions.get(tier_name, _TIER_ACTIONS_GENERIC.get(tier_name, ""))
        return (
            f"**{meta.icon} Emergency actions for {ht.value} — current tier: {tier_name}**\n\n"
            + action
        )

    if intent == "preparedness":
        tips = _PREPAREDNESS.get(ht, "")
        return (
            f"**{meta.icon} {ht.value} — Preparedness Guide for {city}:**\n\n"
            + tips
        )

    if intent == "contacts":
        contacts = _COUNTRY_CONTACTS.get(country, "**Emergency:** 112")
        return f"**Emergency Contacts — {country}**\n\n{contacts}"

    # fallback
    return (
        f"I'm not sure I understood that. For **{city}** ({ht.value} risk zone), "
        f"you can ask me:\n\n"
        f"• *\"What should I do during a {ht.value.lower()}?\"*\n"
        f"• *\"Explain current risk\"*\n"
        f"• *\"What are the emergency actions?\"*\n"
        f"• *\"What hazard type is this city?\"*\n"
        f"• *\"Emergency contact numbers\"*"
    )
