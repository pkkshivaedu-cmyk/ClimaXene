"""Interactive multi-hazard risk heatmap (Folium) — India + Central Asia."""

from __future__ import annotations

import pandas as pd

from src.risk_scoring import TIERS


TIER_COLORS = {t.name: t.hex_color for t in TIERS}

# Approximate radius (pixels) by tier to visually separate urgency
_TIER_RADIUS = {
    "Safe": 8,
    "Advisory": 10,
    "Watch": 12,
    "Warning": 15,
    "Emergency": 19,
}

_LEGEND_HTML = """
<div style="position:fixed;bottom:24px;left:24px;z-index:9999;
    background:rgba(255,255,255,0.95);padding:10px 14px;
    border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,0.18);
    font-family:Inter,sans-serif;font-size:12px;">
  <b style="font-size:13px;">Risk Level</b>
  <div style="margin-top:6px;display:flex;flex-direction:column;gap:4px;">
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;
        background:#22c55e;margin-right:6px;"></span>Safe</span>
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;
        background:#eab308;margin-right:6px;"></span>Advisory</span>
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;
        background:#f97316;margin-right:6px;"></span>Watch</span>
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;
        background:#ef4444;margin-right:6px;"></span>Warning</span>
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:50%;
        background:#7f1d1d;margin-right:6px;"></span>Emergency</span>
  </div>
  <hr style="margin:8px 0;border-color:#e2e8f0;">
  <b style="font-size:11px;">Hazard Types</b>
  <div style="margin-top:4px;font-size:11px;display:flex;flex-direction:column;gap:3px;">
    <span>🌧️ Flood / Rain</span>
    <span>❄️ Snowfall / Blizzard</span>
    <span>🌪️ Sandstorm / Dust</span>
    <span>🌡️ Extreme Heat</span>
    <span>⛰️ Landslide</span>
    <span>🥶 Hard Frost</span>
    <span>☀️ Drought</span>
    <span>🌨️ Blizzard / Dzud</span>
  </div>
</div>
"""

# Hazard-type icon map (matches city_hazard_profile primary values)
_HAZARD_ICON: dict[str, str] = {
    "flood":     "🌧️",
    "snowfall":  "❄️",
    "sandstorm": "🌪️",
    "heatwave":  "🌡️",
    "blizzard":  "🌨️",
    "mixed":     "🌐",
}


def build_india_map(city_risks: pd.DataFrame) -> str:
    import folium

    # Centre between India and Central Asia
    m = folium.Map(location=[42.0, 65.0], zoom_start=4, tiles="CartoDB positron")

    # Try to import city hazard profiles for icon enrichment
    try:
        from src.city_hazard_profile import get_hazard_profile
        _profile_fn = get_hazard_profile
    except ImportError:
        _profile_fn = None

    for _, row in city_risks.iterrows():
        tier_str = row["tier"]
        color = TIER_COLORS.get(tier_str, "#94a3b8")
        radius = _TIER_RADIUS.get(tier_str, 10)
        risk_pct = row.get("risk_pct", 0)
        temp = row.get("temperature", "—")
        hum = row.get("humidity", "—")
        zone = row.get("climate_zone", "")
        city_name = row["city"]

        # Resolve hazard icon for this city
        hazard_icon = "🌧️"
        hazard_label = "Flood / Rainfall"
        if _profile_fn:
            try:
                prof = _profile_fn(city_name)
                hazard_icon = _HAZARD_ICON.get(prof.primary, "🌧️")
                hazard_label = prof.risk_label
            except Exception:
                pass

        popup_html = (
            f"<div style='font-family:Inter,sans-serif;min-width:200px;'>"
            f"<b style='font-size:14px;color:#0f172a;'>{city_name}</b>"
            + (f"<br><span style='font-size:11px;color:#64748b;'>{zone}</span>" if zone else "")
            + f"<hr style='margin:6px 0;border-color:#e2e8f0;'>"
            f"<b style='color:{color};'>⬤ {tier_str}</b> &nbsp; {risk_pct:.0f}% risk"
            f"<br>🌡 {temp}°C &nbsp;&nbsp; 💧 {hum}%"
            f"<br><span style='font-size:11px;color:#475569;'>"
            f"{hazard_icon} Primary hazard: {hazard_label}</span>"
            f"</div>"
        )

        # Use a DivIcon with hazard emoji for better visual distinction
        folium.CircleMarker(
            location=[row["lat"], row["lon"]],
            radius=radius,
            color=color,
            fill=True,
            fill_color=color,
            fill_opacity=0.82,
            weight=2,
            tooltip=folium.Tooltip(
                f"{hazard_icon} <b>{city_name}</b> — {tier_str} ({risk_pct:.0f}%)",
                sticky=True,
            ),
            popup=folium.Popup(popup_html, max_width=240),
        ).add_to(m)

        # Overlay hazard emoji as a small label
        folium.Marker(
            location=[row["lat"], row["lon"]],
            icon=folium.DivIcon(
                html=f"<div style='font-size:10px;margin-top:-6px;margin-left:8px;"
                     f"pointer-events:none;'>{hazard_icon}</div>",
                icon_size=(18, 18),
                icon_anchor=(0, 0),
            ),
        ).add_to(m)

    # Legend overlay
    legend = folium.Element(_LEGEND_HTML)
    m.get_root().html.add_child(legend)

    return m.get_root().render()
