"""Unified prediction pipeline — ML + MIAS/CFIS + drought + confidence."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from sklearn.ensemble import VotingClassifier

from src.drought import drought_risk_score
from src.mias import (
    CFISResult,
    DEFAULT_ELAPSED_SECONDS,
    MXeneResponse,
    compute_cfis,
    final_risk_score,
    formula_display,
    mxene_response,
)
from src.preprocessing import build_single_row
from src.risk_scoring import TIERS, RiskTier, classify_risk


@dataclass
class PredictionResult:
    ml_prob: float
    mias_factor: float
    adjusted_score: float
    tier: RiskTier
    drought_score: float
    confidence_pct: float
    prob_std: float
    tier_probs: dict[str, float]
    mxene: MXeneResponse | None = None
    cfis: CFISResult | None = None


def _estimator_probabilities(model: VotingClassifier, features: pd.DataFrame) -> np.ndarray:
    probs = []
    for est in model.estimators_:
        probs.append(est.predict_proba(features)[0][1])
    return np.array(probs)


def tier_probability_distribution(adjusted_score: float) -> dict[str, float]:
    centers = [0.1, 0.3, 0.5, 0.7, 0.9]
    weights = np.exp(-8 * (np.array(centers) - adjusted_score) ** 2)
    weights /= weights.sum()
    return {t.name: float(w) for t, w in zip(TIERS, weights, strict=False)}


def predict(
    model: VotingClassifier,
    temperature: float,
    humidity: float,
    pressure: float,
    dew_point: float,
    wind_speed: float,
    elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS,
    *,
    rainfall: float = 0.0,
    rainfall_3d: float | None = None,
    rainfall_7d: float | None = None,
    rainfall_14d: float | None = None,
    pressure_change: float | None = None,
) -> PredictionResult:
    features = build_single_row(temperature, humidity, pressure, dew_point, wind_speed)
    est_probs = _estimator_probabilities(model, features)
    ml_prob = float(np.mean(est_probs))
    prob_std = float(np.std(est_probs))
    mx = mxene_response(humidity, elapsed_seconds)
    cfis = compute_cfis(
        humidity,
        elapsed_seconds,
        rainfall=rainfall,
        rainfall_3d=rainfall_3d,
        rainfall_7d=rainfall_7d,
        rainfall_14d=rainfall_14d,
        pressure_change=pressure_change,
    )
    adjusted = final_risk_score(
        ml_prob,
        humidity,
        elapsed_seconds,
        rainfall=rainfall,
        rainfall_3d=rainfall_3d,
        rainfall_7d=rainfall_7d,
        rainfall_14d=rainfall_14d,
        pressure_change=pressure_change,
    )
    tier = classify_risk(adjusted)
    drought_base = max(0, 1 - humidity / 100) * 0.5 + max(0, (temperature - 30) / 20) * 0.3
    drought = drought_risk_score(drought_base, humidity, temperature, elapsed_seconds)
    confidence_pct = (1 - min(prob_std * 2, 0.4)) * 100

    return PredictionResult(
        ml_prob=ml_prob,
        mias_factor=cfis.amplification,
        adjusted_score=adjusted,
        tier=tier,
        drought_score=drought,
        confidence_pct=confidence_pct,
        prob_std=prob_std,
        tier_probs=tier_probability_distribution(adjusted),
        mxene=mx,
        cfis=cfis,
    )


def mias_formula_display(
    humidity: float,
    elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS,
    *,
    rainfall: float = 0.0,
    rainfall_3d: float | None = None,
    rainfall_7d: float | None = None,
    rainfall_14d: float | None = None,
    pressure_change: float | None = None,
) -> str:
    mx = mxene_response(humidity, elapsed_seconds)
    cfis = compute_cfis(
        humidity,
        elapsed_seconds,
        rainfall=rainfall,
        rainfall_3d=rainfall_3d,
        rainfall_7d=rainfall_7d,
        rainfall_14d=rainfall_14d,
        pressure_change=pressure_change,
    )
    return formula_display(mx, cfis)
