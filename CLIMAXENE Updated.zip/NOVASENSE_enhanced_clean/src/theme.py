"""ClimaXene global theme — CSS, Plotly styling, brand tokens."""

from __future__ import annotations

import streamlit as st

BRAND_NAME = "ClimaXene"
BRAND_TAGLINE = "AI Flood Prediction & Climate Intelligence Platform"
BRAND_ACCENT = "#0891b2"
BRAND_ACCENT_DARK = "#0e7490"
BRAND_GRADIENT = "linear-gradient(135deg, #0e7490 0%, #06b6d4 50%, #22d3ee 100%)"

PLOTLY_LAYOUT = dict(
    font=dict(family="Inter, system-ui, sans-serif", color="#334155"),
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    margin=dict(l=40, r=24, t=48, b=40),
    colorway=["#0891b2", "#06b6d4", "#f97316", "#ef4444", "#22c55e", "#8b5cf6"],
)


def apply_plotly_theme(fig):
    fig.update_layout(**PLOTLY_LAYOUT)
    return fig


def inject_global_css() -> None:
    st.markdown(
        f"""
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

        html, body, [class*="css"] {{
            font-family: 'Inter', system-ui, sans-serif;
        }}

        .block-container {{
            padding-top: 1.25rem;
            max-width: 1280px;
        }}

        #MainMenu {{visibility: hidden;}}
        footer {{visibility: hidden;}}
        header[data-testid="stHeader"] {{
            background: rgba(248, 250, 252, 0.92);
            backdrop-filter: blur(8px);
        }}

        .ns-hero {{
            background: {BRAND_GRADIENT};
            border-radius: 16px;
            padding: 1.75rem 2rem;
            margin-bottom: 1.25rem;
            color: #f0fdfa;
            box-shadow: 0 12px 40px rgba(8, 145, 178, 0.25);
        }}
        .ns-hero h1 {{
            margin: 0;
            font-size: 1.85rem;
            font-weight: 800;
            letter-spacing: -0.02em;
        }}
        .ns-hero p {{
            margin: 0.5rem 0 0;
            opacity: 0.95;
            font-size: 1rem;
        }}
        .ns-hero .badges {{
            margin-top: 1rem;
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
        }}
        .ns-badge {{
            background: rgba(255,255,255,0.18);
            border: 1px solid rgba(255,255,255,0.35);
            padding: 0.25rem 0.65rem;
            border-radius: 999px;
            font-size: 0.72rem;
            font-weight: 600;
        }}

        .ns-metric-card {{
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 1rem 1.1rem;
            box-shadow: 0 1px 3px rgba(15, 23, 42, 0.06);
            height: 100%;
        }}
        .ns-metric-card .label {{
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            color: #64748b;
            font-weight: 600;
        }}
        .ns-metric-card .value {{
            font-size: 1.5rem;
            font-weight: 700;
            color: #0f172a;
            margin-top: 0.25rem;
        }}
        .ns-metric-card .delta {{
            font-size: 0.8rem;
            color: #0891b2;
            margin-top: 0.15rem;
        }}

        .ns-section-title {{
            font-size: 1.15rem;
            font-weight: 700;
            color: #0f172a;
            margin: 1.5rem 0 0.75rem;
            padding-bottom: 0.35rem;
            border-bottom: 2px solid #e2e8f0;
        }}

        .ns-pipeline {{
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            align-items: center;
            margin: 1rem 0;
        }}
        .ns-pipeline-step {{
            background: #f1f5f9;
            border: 1px solid #e2e8f0;
            padding: 0.5rem 0.85rem;
            border-radius: 8px;
            font-size: 0.8rem;
            font-weight: 600;
            color: #334155;
        }}
        .ns-pipeline-arrow {{
            color: #94a3b8;
            font-weight: 700;
        }}

        div[data-testid="stSidebar"] {{
            background: linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%);
        }}
        div[data-testid="stSidebar"] .stButton > button {{
            border-radius: 10px;
            font-weight: 600;
        }}

        .stTabs [data-baseweb="tab-list"] {{
            gap: 8px;
        }}
        .stTabs [data-baseweb="tab"] {{
            border-radius: 8px 8px 0 0;
            font-weight: 600;
        }}

        /* ── Command Center & new KPI enhancements ── */
        .ns-cc-header {{
            border-radius: 14px;
            padding: 0.9rem 1.4rem;
            color: #ffffff;
            font-weight: 800;
            font-size: 1.05rem;
            letter-spacing: 0.02em;
            margin-bottom: 1rem;
        }}
        .ns-contact-row {{
            display:flex;align-items:center;gap:0.6rem;
            background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
            padding:0.45rem 0.75rem;margin:0.22rem 0;
        }}
        .ns-contact-number {{
            margin-left:auto;font-size:1rem;font-weight:800;color:#0891b2;white-space:nowrap;
        }}

        /* ── Chat widget ── */
        .ns-chat-bubble-user {{
            background: #0891b2;
            color: #ffffff;
            padding: 0.55rem 1rem;
            border-radius: 18px 18px 4px 18px;
            font-size: 0.92rem;
            max-width: 75%;
            margin-left: auto;
            margin-bottom: 0.4rem;
        }}
        .ns-chat-bubble-bot {{
            background: #f1f5f9;
            color: #1e293b;
            padding: 0.55rem 1rem;
            border-radius: 18px 18px 18px 4px;
            font-size: 0.92rem;
            max-width: 88%;
            margin-right: auto;
            margin-bottom: 0.4rem;
            border: 1px solid #e2e8f0;
        }}
        </style>
        """,
        unsafe_allow_html=True,
    )
