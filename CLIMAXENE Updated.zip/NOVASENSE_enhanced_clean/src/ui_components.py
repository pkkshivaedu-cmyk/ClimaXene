"""Reusable Streamlit UI fragments — ClimaXene design system."""

from __future__ import annotations

import streamlit as st

from src.risk_scoring import RiskTier
from src.theme import BRAND_GRADIENT, BRAND_NAME, BRAND_TAGLINE


def render_hero() -> None:
    st.markdown(
        f"""
        <div class="ns-hero">
            <h1>🌍 {BRAND_NAME}</h1>
            <p>{BRAND_TAGLINE}</p>
            <div class="badges">
                <span class="ns-badge">Ensemble ML</span>
                <span class="ns-badge">Multi-Hazard Engine</span>
                <span class="ns-badge">5-Tier Early Warning</span>
                <span class="ns-badge">130+ Cities · India &amp; Central Asia</span>
                <span class="ns-badge">Flood · Snow · Sand · Heat · Frost · Landslide</span>
                <span class="ns-badge">SHAP Explainability</span>
                <span class="ns-badge">AI Disaster Assistant</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_pipeline_diagram() -> None:
    st.markdown(
        """
        <div class="ns-pipeline">
            <span class="ns-pipeline-step">OpenWeather / IMD</span>
            <span class="ns-pipeline-arrow">→</span>
            <span class="ns-pipeline-step">City Hazard Profile</span>
            <span class="ns-pipeline-arrow">→</span>
            <span class="ns-pipeline-step">RF + GB Ensemble</span>
            <span class="ns-pipeline-arrow">→</span>
            <span class="ns-pipeline-step">HIE · SIE · DIE · TIE · BIE</span>
            <span class="ns-pipeline-arrow">→</span>
            <span class="ns-pipeline-step">5-Tier Alert + Actions</span>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_metric_card(label: str, value: str, delta: str = "") -> str:
    delta_html = f'<div class="delta">{delta}</div>' if delta else ""
    return f"""
    <div class="ns-metric-card">
        <div class="label">{label}</div>
        <div class="value">{value}</div>
        {delta_html}
    </div>
    """


def render_metric_row(items: list[tuple[str, str, str]]) -> None:
    cols = st.columns(len(items))
    for col, (label, value, delta) in zip(cols, items, strict=False):
        col.markdown(render_metric_card(label, value, delta), unsafe_allow_html=True)


def render_section(title: str) -> None:
    st.markdown(f'<p class="ns-section-title">{title}</p>', unsafe_allow_html=True)


def render_tier_pill(tier: RiskTier, score_pct: float) -> None:
    st.markdown(
        f"""
        <div style="
            display:inline-flex;align-items:center;gap:0.5rem;
            background:{tier.hex_color}18;border:1px solid {tier.hex_color};
            padding:0.35rem 0.85rem;border-radius:999px;font-weight:700;
            color:{tier.hex_color};font-size:0.9rem;
        ">
            <span style="width:10px;height:10px;border-radius:50%;background:{tier.hex_color};"></span>
            {tier.name} · {score_pct:.0f}%
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_alert_banner(
    tier: RiskTier,
    *,
    lang: str = "en",
    override_message: str | None = None,
    override_action: str | None = None,
) -> None:
    from src.i18n import t, tier_action, tier_message, tier_name as tname
    label_text = t("ui.official_advisory", lang)
    display_name = tname(tier.name, lang)
    message = override_message or tier_message(tier.name, lang)
    action = override_action or tier_action(tier.name, lang)
    recommended_label = t("alert.recommended_action", lang)
    st.markdown(
        f"""
        <div style="
            background: {tier.hex_color}14;
            border: 1px solid {tier.hex_color}44;
            border-left: 6px solid {tier.hex_color};
            padding: 1.1rem 1.35rem;
            border-radius: 12px;
            margin: 1rem 0;
        ">
            <div style="font-size:0.7rem;text-transform:uppercase;letter-spacing:0.08em;
                color:{tier.hex_color};font-weight:700;">{label_text}</div>
            <h3 style="margin:0.35rem 0 0;color:{tier.hex_color};font-size:1.25rem;">
                {display_name} — {message}
            </h3>
            <p style="margin:0.65rem 0 0;color:#475569;font-size:0.95rem;">
                <b>{recommended_label}:</b> {action}
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_confidence_meter(risk_pct: float, confidence_pct: float, tier: RiskTier) -> None:
    """Combined risk + confidence visual meter."""
    conf_color = "#22c55e" if confidence_pct >= 80 else "#eab308" if confidence_pct >= 60 else "#ef4444"
    st.markdown(
        f"""
        <div style="background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;
            padding:1.1rem 1.35rem;box-shadow:0 2px 8px rgba(15,23,42,0.07);margin:0.5rem 0;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.6rem;">
                <span style="font-size:0.72rem;text-transform:uppercase;letter-spacing:0.07em;
                    color:#64748b;font-weight:600;">Flood Risk</span>
                <span style="font-size:0.72rem;text-transform:uppercase;letter-spacing:0.07em;
                    color:#64748b;font-weight:600;">Confidence</span>
            </div>
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.75rem;">
                <span style="font-size:1.6rem;font-weight:800;color:{tier.hex_color};">
                    {risk_pct:.0f}%
                    <span style="font-size:0.85rem;font-weight:600;margin-left:6px;
                        background:{tier.hex_color}18;padding:2px 10px;border-radius:999px;">
                        {tier.name}
                    </span>
                </span>
                <span style="font-size:1.6rem;font-weight:800;color:{conf_color};">
                    {confidence_pct:.0f}%
                </span>
            </div>
            <div style="background:#f1f5f9;border-radius:8px;height:10px;overflow:hidden;margin-bottom:4px;">
                <div style="height:100%;width:{min(risk_pct, 100):.0f}%;
                    background:{tier.hex_color};border-radius:8px;transition:width 0.4s;"></div>
            </div>
            <div style="background:#f1f5f9;border-radius:8px;height:6px;overflow:hidden;">
                <div style="height:100%;width:{min(confidence_pct, 100):.0f}%;
                    background:{conf_color};border-radius:8px;transition:width 0.4s;"></div>
            </div>
            <div style="display:flex;justify-content:space-between;margin-top:0.35rem;">
                <span style="font-size:0.7rem;color:#94a3b8;">Risk gauge</span>
                <span style="font-size:0.7rem;color:#94a3b8;">Confidence gauge</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_sms_mockup(city: str, tier_name: str, summary: str, *, lang: str = "en") -> None:
    from src.i18n import tier_name as tname
    display_tier = tname(tier_name, lang)
    body = summary if len(summary) <= 140 else summary[:137] + "..."
    st.markdown(
        f"""
        <div style="max-width:380px;background:linear-gradient(145deg,#0f172a,#1e293b);
            color:#f8fafc;padding:16px 18px;border-radius:16px;
            box-shadow:0 8px 24px rgba(15,23,42,0.35);font-family:Inter,system-ui;">
            <div style="display:flex;justify-content:space-between;align-items:center;">
                <span style="font-size:11px;color:#94a3b8;font-weight:600;">CLIMAXENE ALERT</span>
                <span style="font-size:10px;color:#64748b;">now</span>
            </div>
            <div style="margin-top:12px;font-size:14px;line-height:1.45;">
                <span style="background:#0891b2;padding:2px 8px;border-radius:4px;
                    font-size:11px;font-weight:700;">{display_tier}</span>
                <span style="margin-left:6px;font-weight:600;">{city}</span>
                <p style="margin:8px 0 0;color:#e2e8f0;">{body}</p>
            </div>
            <div style="margin-top:12px;font-size:10px;color:#64748b;">
                Demo SMS · IMD-aligned 5-tier protocol
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_impact_panel(metrics: dict | None) -> None:
    if not metrics:
        st.info("Train the model to show validation metrics on the overview.")
        return
    render_metric_row([
        ("ROC-AUC", f"{metrics.get('roc_auc', 0):.3f}", "Hold-out test set"),
        ("F1 Score", f"{metrics.get('f1', 0):.3f}", "Rain event detection"),
        ("Training rows", f"{metrics.get('train_samples', 0):,}", metrics.get("data_source", "IMD")),
        ("Cities covered", str(metrics.get("n_cities", 40)), "Hyperlocal India"),
    ])


def render_problem_solution() -> None:
    c1, c2 = st.columns(2)
    with c1:
        st.markdown(
            """
            #### 🎯 Problem
            India loses **$3B+ annually** to floods and faces **2× monsoon variability**.
            National forecasts lack **street-level** humidity response — the signal that
            precedes flash floods in coastal and urban corridors.
            """
        )
    with c2:
        st.markdown(
            """
            #### 💡 Our solution
            **ClimaXene** fuses **IMD-scale ML** with the **Humidity Intelligence Engine (HIE)** —
            a physics-inspired MXene sensor model (Activation × Saturation × Time) to amplify
            rain probability **before** gauges peak. Delivered as **5-tier IMD-style**
            alerts with SHAP transparency and multilingual emergency guidance.
            """
        )


def render_footer() -> None:
    st.markdown(
        """
        <div style="text-align:center;padding:1.5rem 0 0.5rem;color:#94a3b8;font-size:0.8rem;
            border-top:1px solid #e2e8f0;margin-top:2rem;">
            ClimaXene · Ensemble ML + Humidity Intelligence Engine · Built for India · Hackathon 2026
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_demo_callout(scenario_title: str, description: str, tab_hint: str) -> None:
    st.success(
        f"**Judge demo active:** {scenario_title} — {description} "
        f"→ Explore **{tab_hint}** tab."
    )
