"""SHAP explainability for ensemble predictions."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import VotingClassifier

from src.preprocessing import FEATURE_COLUMNS


def _flatten_shap_values(shap_values, n_features: int) -> np.ndarray:
    """Reduce SHAP output to a 1D vector of length n_features for one row."""
    if isinstance(shap_values, list):
        # Binary classifier: use positive class (index 1) when available
        arr = shap_values[1] if len(shap_values) > 1 else shap_values[0]
    else:
        arr = shap_values

    arr = np.asarray(arr)
    if arr.ndim == 3:
        # (samples, features, classes) — rain class = 1
        arr = arr[0, :, 1] if arr.shape[2] > 1 else arr[0, :, 0]
    elif arr.ndim == 2:
        arr = arr[0]
    else:
        arr = arr.ravel()

    flat = np.ravel(arr)
    if flat.size != n_features:
        flat = flat.reshape(-1, n_features)[0] if flat.size >= n_features else flat
    return flat[:n_features]


def get_shap_contributions(
    model: VotingClassifier,
    features: pd.DataFrame,
) -> pd.DataFrame | None:
    try:
        import shap
    except ImportError:
        return None

    rf = model.named_estimators_.get("rf")
    if rf is None:
        return None

    try:
        explainer = shap.TreeExplainer(rf)
        shap_values = explainer.shap_values(features)
        vals = _flatten_shap_values(shap_values, len(FEATURE_COLUMNS))
        df = pd.DataFrame(
            {"feature": FEATURE_COLUMNS, "shap_value": vals.astype(float)}
        )
        return df.reindex(df["shap_value"].abs().sort_values(ascending=False).index)
    except Exception:
        return None
