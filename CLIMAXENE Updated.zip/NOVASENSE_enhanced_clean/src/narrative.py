"""Natural-language alert summaries — hazard-aware for multi-city support."""

from __future__ import annotations

from src.predictions import PredictionResult
from src.risk_scoring import RiskTier


def _tone_prefix(tier: RiskTier) -> str:
    if tier.name == "Safe":
        return "Conditions are calm for"
    if tier.name == "Advisory":
        return "Advisory for"
    if tier.name == "Watch":
        return "Watch alert for"
    if tier.name == "Warning":
        return "Warning for"
    return "EMERGENCY for"


def build_alert_summary(
    city: str,
    result: PredictionResult,
    *,
    humidity: float,
    temperature: float,
    top_features: list[tuple[str, float]] | None = None,
    forecast_note: str = "",
    hazard_label: str = "flood/rain",
) -> str:
    """
    Build a natural-language alert summary.

    Parameters
    ----------
    hazard_label : str
        Human-readable hazard type, e.g. "sandstorm", "snowfall", "extreme heat".
        Defaults to "flood/rain" for backward compatibility.
    """
    prefix = _tone_prefix(result.tier)
    conf = f" ({result.confidence_pct:.0f}% confidence)" if result.confidence_pct else ""
    drivers = ""
    if top_features:
        parts = [f"{name} ({val:+.2f})" for name, val in top_features[:2]]
        drivers = f" — driven mainly by {', '.join(parts)}"
    mias_note = f" MIAS amplification {result.mias_factor:.2f}× at {humidity:.0f}% humidity."
    drought_note = ""
    if result.drought_score >= 0.5:
        drought_note = f" Parallel drought stress index {result.drought_score * 100:.0f}%."
    fc = f" {forecast_note}" if forecast_note else ""
    return (
        f"{prefix} {city}{conf}: {hazard_label} risk {result.adjusted_score * 100:.0f}% "
        f"({result.tier.name} tier).{drivers}{mias_note}{drought_note}{fc}"
    ).strip()
