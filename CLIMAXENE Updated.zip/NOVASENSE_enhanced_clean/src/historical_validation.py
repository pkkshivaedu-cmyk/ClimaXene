"""Validate model + MIAS/CFIS against documented Indian extreme weather events."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
from sklearn.ensemble import VotingClassifier

from src.mias import compute_cfis, final_risk_score, mxene_response
from src.preprocessing import build_single_row
from src.risk_scoring import TIERS, classify_risk

TIER_RANK = {t.name: i for i, t in enumerate(TIERS)}


def load_events(path: Path) -> list[dict]:
    return json.loads(path.read_text(encoding="utf-8"))


def event_temperature(ev: dict) -> float:
    if "temperature" in ev:
        return float(ev["temperature"])
    return (float(ev.get("tmax", 0)) + float(ev.get("tmin", 0))) / 2.0


def event_rainfall_mm(ev: dict) -> float:
    if "rainfall_mm" in ev:
        return float(ev["rainfall_mm"])
    return float(ev.get("rainfall", 0) or 0)


def validate_events(
    model: VotingClassifier,
    events: list[dict],
    *,
    elapsed_seconds: float = 2.0,
) -> pd.DataFrame:
    rows = []
    for ev in events:
        temp = event_temperature(ev)
        features = build_single_row(
            temp,
            ev["humidity"],
            ev["pressure"],
            ev["dew_point"],
            ev["wind_speed"],
        )
        ml_prob = float(model.predict_proba(features)[0][1])
        rain_mm = event_rainfall_mm(ev)
        ml_prob = min(ml_prob + min(rain_mm / 150 * 0.2, 0.35), 1.0)
        mx = mxene_response(ev["humidity"], elapsed_seconds)
        cfis = compute_cfis(
            ev["humidity"],
            elapsed_seconds,
            rainfall=rain_mm,
            rainfall_3d=ev.get("rainfall_3d"),
            rainfall_7d=ev.get("rainfall_7d"),
            rainfall_14d=ev.get("rainfall_14d"),
            pressure_change=ev.get("pressure_change"),
        )
        adjusted = final_risk_score(
            ml_prob,
            ev["humidity"],
            elapsed_seconds,
            rainfall=rain_mm,
            rainfall_3d=ev.get("rainfall_3d"),
            rainfall_7d=ev.get("rainfall_7d"),
            rainfall_14d=ev.get("rainfall_14d"),
            pressure_change=ev.get("pressure_change"),
        )
        tier = classify_risk(adjusted)
        from src.predictions import PredictionResult

        r = PredictionResult(
            ml_prob=ml_prob,
            mias_factor=cfis.amplification,
            adjusted_score=adjusted,
            tier=tier,
            drought_score=0.0,
            confidence_pct=90.0,
            prob_std=0.0,
            tier_probs={},
            mxene=mx,
            cfis=cfis,
        )
        expected = ev["expected_min_tier"]
        passed = TIER_RANK[r.tier.name] >= TIER_RANK[expected]
        rows.append(
            {
                "event": ev["name"],
                "date": ev["date"],
                "city": ev["city"],
                "expected_min_tier": expected,
                "predicted_tier": r.tier.name,
                "risk_pct": round(r.adjusted_score * 100, 1),
                "ml_prob_pct": round(r.ml_prob * 100, 1),
                "mias_factor": round(r.mias_factor, 3),
                "cfis": round(cfis.cfis, 3),
                "passed": passed,
                "source": ev.get("source", ""),
            }
        )
    return pd.DataFrame(rows)
