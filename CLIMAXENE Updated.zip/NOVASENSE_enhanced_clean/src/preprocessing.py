"""Data loading, cleaning, and feature engineering."""

from __future__ import annotations

import numpy as np
import pandas as pd

FEATURE_COLUMNS = [
    "temperature",
    "humidity",
    "pressure",
    "dew_point",
    "wind_speed",
    "heat_index",
    "humidity_lag1",
    "humidity_lag2",
]

TARGET_COLUMN = "rainfall"


def _ensure_temperature(df: pd.DataFrame) -> pd.DataFrame:
    """Derive temperature from tmax/tmin when needed."""
    out = df.copy()
    if "temperature" not in out.columns and "tmax" in out.columns and "tmin" in out.columns:
        out["temperature"] = (out["tmax"] + out["tmin"]) / 2.0
    return out


def _normalize_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """Map common column aliases to canonical names."""
    rename_map = {}
    for col in df.columns:
        key = col.strip().lower().replace(" ", "_").replace("(", "").replace(")", "")
        if key in ("temp", "temperature_c", "temp_c"):
            rename_map[col] = "temperature"
        elif key in (
            "humid",
            "relative_humidity",
            "humidity_",
            "humidity_pct",
            "humidity_percent",
            "humidity_%",
        ):
            rename_map[col] = "humidity"
        elif key in ("press", "pressure_hpa", "pressure_mb"):
            rename_map[col] = "pressure"
        elif key in ("dewpoint", "dew_point_c"):
            rename_map[col] = "dew_point"
        elif key in ("wind", "windspeed", "wind_speed_kmh", "wind_kph"):
            rename_map[col] = "wind_speed"
        elif key in ("rainfall_mm", "rain_mm", "precipitation_mm"):
            rename_map[col] = "rainfall_mm"
        elif key in (
            "rain",
            "raintoday",
            "rain_today",
            "rainfall_today",
            "precipitation",
        ):
            rename_map[col] = "rainfall"
        elif key == "rainfall" and col.lower() != "rainfall":
            rename_map[col] = "rainfall"
        elif key == "raintomorrow" and "rainfall" not in rename_map.values():
            rename_map[col] = "rainfall"
    return df.rename(columns=rename_map)


def _resolve_rainfall_column(df: pd.DataFrame) -> pd.Series:
    """Single rainfall target column — avoids duplicate 'rainfall' after normalization."""
    if "rainfall" in df.columns:
        col = df["rainfall"]
        if isinstance(col, pd.DataFrame):
            col = col.iloc[:, 0]
        return col
    if "rainfall_mm" in df.columns:
        mm = df["rainfall_mm"]
        if isinstance(mm, pd.DataFrame):
            mm = mm.iloc[:, 0]
        return (mm > 0.2).astype(int)
    raise ValueError("No rainfall or rainfall_mm column found")


def _encode_rainfall(series: pd.Series) -> pd.Series:
    """Convert Yes/No, 1/0, or numeric rainfall labels to binary."""
    if isinstance(series, pd.DataFrame):
        series = series.iloc[:, 0]
    if series.dtype == object:
        return series.astype(str).str.lower().isin(["yes", "1", "true", "y"]).astype(int)
    return (series > 0).astype(int) if series.dtype != bool else series.astype(int)


def compute_heat_index(temp_c: float, humidity: float) -> float:
    """Approximate heat index in °C from temperature and relative humidity."""
    temp_f = temp_c * 9 / 5 + 32
    hi_f = (
        -42.379
        + 2.04901523 * temp_f
        + 10.14333127 * humidity
        - 0.22475541 * temp_f * humidity
        - 0.00683783 * temp_f**2
        - 0.05481717 * humidity**2
        + 0.00122874 * temp_f**2 * humidity
        + 0.00085282 * temp_f * humidity**2
        - 0.00000199 * temp_f**2 * humidity**2
    )
    return (hi_f - 32) * 5 / 9


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add heat index and lagged humidity features (per-city when city column exists)."""
    out = df.copy()
    if "heat_index" not in out.columns:
        out["heat_index"] = [
            compute_heat_index(t, h)
            for t, h in zip(out["temperature"], out["humidity"], strict=False)
        ]
    if "city" in out.columns:
        out["humidity_lag1"] = out.groupby("city", sort=False)["humidity"].shift(1)
        out["humidity_lag2"] = out.groupby("city", sort=False)["humidity"].shift(2)
    else:
        out["humidity_lag1"] = out["humidity"].shift(1)
        out["humidity_lag2"] = out["humidity"].shift(2)
    return out


def load_and_prepare(
    df: pd.DataFrame,
    *,
    fit: bool = True,
    medians: dict[str, float] | None = None,
) -> tuple[pd.DataFrame, pd.Series, dict[str, float]]:
    """Clean dataset and return feature matrix, target, and imputation medians."""
    df = _normalize_column_names(df)
    df = _ensure_temperature(df)
    # Drop duplicate column names (e.g. rainfall + rainfall both mapped to 'rainfall')
    df = df.loc[:, ~df.columns.duplicated()].copy()

    required = ["temperature", "humidity", "pressure", "dew_point", "wind_speed"]
    missing = [c for c in required if c not in df.columns]
    has_target = "flood_label" in df.columns or "rainfall" in df.columns or "rainfall_mm" in df.columns
    if not has_target:
        missing.append("flood_label or rainfall")
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    if "flood_label" in df.columns:
        df[TARGET_COLUMN] = df["flood_label"].astype(int)
    else:
        df[TARGET_COLUMN] = _encode_rainfall(_resolve_rainfall_column(df))
    df = df.drop(columns=["rainfall_mm"], errors="ignore")
    df = df.dropna(subset=[TARGET_COLUMN]).copy()
    df = engineer_features(df)

    if medians is None:
        medians = {}
    for col in FEATURE_COLUMNS:
        if col not in df.columns:
            continue
        if fit or col not in medians:
            medians[col] = float(df[col].median())
        df[col] = df[col].fillna(medians[col])

    df = df.dropna(subset=FEATURE_COLUMNS)
    X = df[FEATURE_COLUMNS]
    y = df[TARGET_COLUMN]
    return X, y, medians


def build_single_row(
    temperature: float,
    humidity: float,
    pressure: float,
    dew_point: float,
    wind_speed: float,
    humidity_lag1: float | None = None,
    humidity_lag2: float | None = None,
) -> pd.DataFrame:
    """Build a one-row feature DataFrame for live prediction."""
    lag1 = humidity_lag1 if humidity_lag1 is not None else humidity * 0.98
    lag2 = humidity_lag2 if humidity_lag2 is not None else humidity * 0.96
    heat = compute_heat_index(temperature, humidity)
    return pd.DataFrame(
        [
            {
                "temperature": temperature,
                "humidity": humidity,
                "pressure": pressure,
                "dew_point": dew_point,
                "wind_speed": wind_speed,
                "heat_index": heat,
                "humidity_lag1": lag1,
                "humidity_lag2": lag2,
            }
        ]
    )
