"""
MXene-Inspired Adaptive Sensing (MIAS) layer + Climate Flood Intelligence Score (CFIS).

MXene humidity component (MXH):
  1. Activation:  A(RH) = 1 / (1 + e^(-k(RH - RHc)))
  2. Saturation:  S(RH) = 1 - e^(-α·RH)
  3. Time response: T(t) = 1 - e^(-t/τ)   [t and τ in SECONDS — lab MXene ~0.5–2 s]
  MXH = A × S × T  (range 0–1)

CFIS (Climate Flood Intelligence Score):
  RainScore = 0.40·norm(rainfall) + 0.25·norm(rainfall_3d) + 0.20·norm(rainfall_7d) + 0.15·norm(rainfall_14d)
  StormFactor = clamp(|pressure_change| / 10, 0, 1)
  CFIS = 0.65·RainScore + 0.20·MXH + 0.15·StormFactor

Final risk:
  FinalRisk = min(ML_Probability × (1 + 0.5 × CFIS), 1.0)   [amplification range 1.0–1.5]
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

DEFAULT_RH_CRITICAL = 60.0
DEFAULT_K_ACTIVATION = 0.18
DEFAULT_ALPHA_SATURATION = 0.03
DEFAULT_TAU_SECONDS = 1.0
DEFAULT_ELAPSED_SECONDS = 2.0
MAX_AMPLIFICATION = 0.4
CFIS_AMPLIFICATION_SCALE = 0.5

# Normalization caps (mm) — derived from combined_imd_export.csv maxima
RAIN_NORM_CAPS = {
    "rainfall": 175.0,
    "rainfall_3d": 220.0,
    "rainfall_7d": 275.0,
    "rainfall_14d": 420.0,
}

RAIN_SCORE_WEIGHTS = (0.40, 0.25, 0.20, 0.15)
CFIS_WEIGHTS = (0.65, 0.20, 0.15)  # RainScore, MXH, StormFactor


@dataclass(frozen=True)
class MXeneResponse:
    activation: float
    saturation: float
    time_response: float
    combined: float
    amplification: float
    humidity: float
    elapsed_seconds: float


@dataclass(frozen=True)
class CFISResult:
    rain_score: float
    mxh: float
    storm_factor: float
    cfis: float
    amplification: float
    rainfall_norm: float
    rainfall_3d_norm: float
    rainfall_7d_norm: float
    rainfall_14d_norm: float


def activation(humidity: float, rh_critical: float = DEFAULT_RH_CRITICAL, k: float = DEFAULT_K_ACTIVATION) -> float:
    return 1.0 / (1.0 + math.exp(-k * (humidity - rh_critical)))


def saturation(humidity: float, alpha: float = DEFAULT_ALPHA_SATURATION) -> float:
    return 1.0 - math.exp(-alpha * humidity)


def time_response(elapsed_seconds: float, tau_seconds: float = DEFAULT_TAU_SECONDS) -> float:
    t = max(elapsed_seconds, 0.0)
    return 1.0 - math.exp(-t / tau_seconds)


def mxene_response(
    humidity: float,
    elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS,
    *,
    rh_critical: float = DEFAULT_RH_CRITICAL,
    k: float = DEFAULT_K_ACTIVATION,
    alpha: float = DEFAULT_ALPHA_SATURATION,
    tau_seconds: float = DEFAULT_TAU_SECONDS,
) -> MXeneResponse:
    a = activation(humidity, rh_critical, k)
    s = saturation(humidity, alpha)
    tr = time_response(elapsed_seconds, tau_seconds)
    combined = a * s * tr
    amp = 1.0 + MAX_AMPLIFICATION * combined
    return MXeneResponse(
        activation=a,
        saturation=s,
        time_response=tr,
        combined=combined,
        amplification=amp,
        humidity=humidity,
        elapsed_seconds=elapsed_seconds,
    )


def mxh(humidity: float, elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS, **kwargs) -> float:
    """MXene humidity component — atmospheric moisture saturation indicator (0–1)."""
    return mxene_response(humidity, elapsed_seconds, **kwargs).combined


def normalize_rainfall(value: float | None, cap: float) -> float:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return 0.0
    return min(max(float(value), 0.0) / cap, 1.0)


def rain_score(
    rainfall: float = 0.0,
    rainfall_3d: float | None = None,
    rainfall_7d: float | None = None,
    rainfall_14d: float | None = None,
) -> tuple[float, float, float, float, float]:
    """Weighted normalized rainfall accumulation score (0–1)."""
    n0 = normalize_rainfall(rainfall, RAIN_NORM_CAPS["rainfall"])
    n3 = normalize_rainfall(rainfall_3d, RAIN_NORM_CAPS["rainfall_3d"])
    n7 = normalize_rainfall(rainfall_7d, RAIN_NORM_CAPS["rainfall_7d"])
    n14 = normalize_rainfall(rainfall_14d, RAIN_NORM_CAPS["rainfall_14d"])
    w = RAIN_SCORE_WEIGHTS
    score = w[0] * n0 + w[1] * n3 + w[2] * n7 + w[3] * n14
    return score, n0, n3, n7, n14


def storm_factor(pressure_change: float | None) -> float:
    if pressure_change is None or (isinstance(pressure_change, float) and math.isnan(pressure_change)):
        return 0.0
    return min(abs(float(pressure_change)) / 10.0, 1.0)


def compute_cfis(
    humidity: float,
    elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS,
    *,
    rainfall: float = 0.0,
    rainfall_3d: float | None = None,
    rainfall_7d: float | None = None,
    rainfall_14d: float | None = None,
    pressure_change: float | None = None,
    **kwargs,
) -> CFISResult:
    rs, n0, n3, n7, n14 = rain_score(rainfall, rainfall_3d, rainfall_7d, rainfall_14d)
    mxh_val = mxh(humidity, elapsed_seconds, **kwargs)
    sf = storm_factor(pressure_change)
    w = CFIS_WEIGHTS
    cfis = w[0] * rs + w[1] * mxh_val + w[2] * sf
    amp = 1.0 + CFIS_AMPLIFICATION_SCALE * cfis
    return CFISResult(
        rain_score=rs,
        mxh=mxh_val,
        storm_factor=sf,
        cfis=cfis,
        amplification=amp,
        rainfall_norm=n0,
        rainfall_3d_norm=n3,
        rainfall_7d_norm=n7,
        rainfall_14d_norm=n14,
    )


def mxene_factor(humidity: float, elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS, **kwargs) -> float:
    return compute_cfis(humidity, elapsed_seconds, **kwargs).amplification


def final_risk_score(
    ml_prob: float,
    humidity: float,
    elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS,
    *,
    rainfall: float = 0.0,
    rainfall_3d: float | None = None,
    rainfall_7d: float | None = None,
    rainfall_14d: float | None = None,
    pressure_change: float | None = None,
    **kwargs,
) -> float:
    cfis = compute_cfis(
        humidity,
        elapsed_seconds,
        rainfall=rainfall,
        rainfall_3d=rainfall_3d,
        rainfall_7d=rainfall_7d,
        rainfall_14d=rainfall_14d,
        pressure_change=pressure_change,
        **kwargs,
    )
    adjusted = ml_prob * cfis.amplification
    return min(adjusted, 1.0)


def mxene_curve(
    humidity_range: np.ndarray | None = None,
    elapsed_seconds: float = DEFAULT_ELAPSED_SECONDS,
) -> dict[str, np.ndarray]:
    if humidity_range is None:
        humidity_range = np.linspace(0, 100, 101)
    rows = [mxene_response(float(h), elapsed_seconds) for h in humidity_range]
    return {
        "humidity": humidity_range,
        "activation": np.array([r.activation for r in rows]),
        "saturation": np.array([r.saturation for r in rows]),
        "time_response": np.full(len(rows), rows[0].time_response),
        "combined": np.array([r.combined for r in rows]),
        "amplification": np.array([r.amplification for r in rows]),
    }


def formula_display(response: MXeneResponse, cfis: CFISResult | None = None) -> str:
    h, t = response.humidity, response.elapsed_seconds
    lines = [
        f"Activation A(RH) = 1/(1+e^(-k(RH-RHc))) = {response.activation:.4f}",
        f"Saturation S(RH) = 1-e^(-α·RH) = {response.saturation:.4f}",
        f"Time response T(t) = 1-e^(-t/τ), t={t:.2f}s, τ={DEFAULT_TAU_SECONDS}s → {response.time_response:.4f}",
        f"MXH = A×S×T = {response.combined:.4f}  (RH={h:.1f}%)",
    ]
    if cfis is not None:
        lines.extend([
            f"RainScore = 0.40·R + 0.25·R3d + 0.20·R7d + 0.15·R14d = {cfis.rain_score:.4f}",
            f"  norm: R={cfis.rainfall_norm:.3f}  R3d={cfis.rainfall_3d_norm:.3f}  "
            f"R7d={cfis.rainfall_7d_norm:.3f}  R14d={cfis.rainfall_14d_norm:.3f}",
            f"StormFactor = |ΔP|/10 = {cfis.storm_factor:.4f}",
            f"CFIS = 0.65·RainScore + 0.20·MXH + 0.15·StormFactor = {cfis.cfis:.4f}",
            f"amplification = 1 + 0.5×CFIS = {cfis.amplification:.4f}",
        ])
    else:
        lines.append(f"mxene_factor = 1 + 0.4×Response = {response.amplification:.4f}  (RH={h:.1f}%)")
    return "\n".join(lines)
