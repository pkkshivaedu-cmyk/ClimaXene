"""OpenWeatherMap API integration."""

from __future__ import annotations

import os
from typing import Any

import requests


def fetch_live_weather(city: str, api_key: str | None = None) -> dict[str, Any]:
    """
    Fetch current weather for a city from OpenWeatherMap.
    Returns dict with temperature, humidity, pressure, dew_point, wind_speed.
    """
    key = (api_key or os.getenv("OPENWEATHER_API_KEY", "")).strip()
    if not key:
        raise ValueError(
            "OpenWeather API key not set. Add OPENWEATHER_API_KEY to .env or enter it in the sidebar."
        )
    if len(key) != 32:
        raise ValueError(
            f"API key length looks wrong ({len(key)} chars; expected 32). "
            "Check for extra spaces or a missing character in .env."
        )

    url = "https://api.openweathermap.org/data/2.5/weather"
    params = {"q": city.strip(), "appid": key, "units": "metric"}
    resp = requests.get(url, params=params, timeout=15)
    if resp.status_code == 401:
        detail = resp.json().get("message", "Unauthorized") if resp.headers.get("content-type", "").startswith("application/json") else resp.text
        raise ValueError(
            f"OpenWeather rejected your API key (401): {detail}\n\n"
            "• Use the **Default** key from openweathermap.org/api_keys (not a new key that still returns 401).\n"
            "• Put it in c:\\CLIMAXENE\\.env as: OPENWEATHER_API_KEY=your_32_char_key\n"
            "• Leave the sidebar **Override API key** field EMPTY so .env is used.\n"
            "• Restart Streamlit after saving .env."
        )
    resp.raise_for_status()
    data = resp.json()

    main = data["main"]
    wind = data.get("wind", {})
    temp = main["temp"]
    humidity = main["humidity"]
    pressure = main["pressure"]
    dew_point = main.get("temp_min", temp - 5)  # fallback if dew not in free tier

    # Estimate dew point from temp & humidity (Magnus formula)
    a, b = 17.27, 237.7
    alpha = (a * temp) / (b + temp) + np_log(humidity / 100.0)
    dew_point = (b * alpha) / (a - alpha)

    return {
        "city": data.get("name", city),
        "country": data.get("sys", {}).get("country", ""),
        "description": data.get("weather", [{}])[0].get("description", ""),
        "temperature": round(temp, 1),
        "humidity": round(humidity, 1),
        "pressure": round(pressure, 1),
        "dew_point": round(dew_point, 1),
        "wind_speed": round(wind.get("speed", 0) * 3.6, 1),  # m/s → km/h
    }


def fetch_forecast(city: str, api_key: str | None = None, hours: int = 72) -> list[dict[str, Any]]:
    """Fetch 3-hourly forecast windows for next `hours` (OpenWeather 5-day forecast)."""
    key = (api_key or os.getenv("OPENWEATHER_API_KEY", "")).strip()
    if not key:
        raise ValueError("OpenWeather API key not set.")

    url = "https://api.openweathermap.org/data/2.5/forecast"
    params = {"q": city.strip(), "appid": key, "units": "metric"}
    resp = requests.get(url, params=params, timeout=20)
    if resp.status_code == 401:
        raise ValueError("OpenWeather rejected API key (401). Use Default key in .env.")
    resp.raise_for_status()
    data = resp.json()
    windows = []
    max_items = max(1, hours // 3)
    for item in data.get("list", [])[:max_items]:
        main = item["main"]
        wind = item.get("wind", {})
        temp = main["temp"]
        humidity = main["humidity"]
        a, b = 17.27, 237.7
        alpha = (a * temp) / (b + temp) + np_log(humidity / 100.0)
        dew = (b * alpha) / (a - alpha)
        windows.append({
            "time": item["dt_txt"],
            "temperature": round(temp, 1),
            "humidity": round(humidity, 1),
            "pressure": round(main["pressure"], 1),
            "dew_point": round(dew, 1),
            "wind_speed": round(wind.get("speed", 0) * 3.6, 1),
            "rain_mm": float(item.get("rain", {}).get("3h", 0)),
        })
    return windows


def np_log(x: float) -> float:
    import math

    return math.log(max(x, 1e-6))
