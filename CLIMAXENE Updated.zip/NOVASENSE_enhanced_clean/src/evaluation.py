"""Model evaluation charts — ROC, confusion matrix, MIAS/CFIS comparison."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import (
    auc,
    confusion_matrix,
    f1_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split

from src.mias import final_risk_score
from src.preprocessing import _ensure_temperature, _normalize_column_names, load_and_prepare
from src.risk_scoring import THRESHOLDS, TIERS


def _tier_index(score: float) -> int:
    for i, t in enumerate(THRESHOLDS):
        if score < t:
            return i
    return len(THRESHOLDS)


def _cfis_kwargs(row: pd.Series) -> dict:
    rainfall_val = row.get("rainfall_mm", row.get("rainfall", 0))
    return {
        "rainfall": float(rainfall_val or 0),
        "rainfall_3d": row.get("rainfall_3d"),
        "rainfall_7d": row.get("rainfall_7d"),
        "rainfall_14d": row.get("rainfall_14d"),
        "pressure_change": row.get("pressure_change"),
    }


def evaluate_on_holdout(
    model: VotingClassifier,
    df: pd.DataFrame,
    *,
    random_state: int = 42,
) -> dict:
    raw = df.copy()
    if "temperature" not in raw.columns:
        raw = _normalize_column_names(raw)
        raw = _ensure_temperature(raw)

    X, y, _ = load_and_prepare(raw, fit=True)
    meta = raw.loc[X.index]

    _, X_test, _, y_test = train_test_split(
        X, y, test_size=0.2, random_state=random_state, stratify=y
    )
    y_proba = model.predict_proba(X_test)[:, 1]
    y_pred = model.predict(X_test)

    fpr, tpr, _ = roc_curve(y_test, y_proba)
    roc_auc = auc(fpr, tpr)
    cm = confusion_matrix(y_test, y_pred)

    test_meta = meta.loc[X_test.index]
    with_mias = []
    without_mias = []
    for prob, (_, row), h in zip(y_proba, test_meta.iterrows(), X_test["humidity"].values, strict=False):
        kwargs = _cfis_kwargs(row)
        without_mias.append(_tier_index(prob))
        with_mias.append(_tier_index(final_risk_score(prob, h, **kwargs)))

    mias_match = float(np.mean(np.array(with_mias) == np.array(with_mias)))

    tier_f1 = {}
    pred_tiers = with_mias
    for i, tier in enumerate(TIERS):
        binary_true = (np.array(pred_tiers) >= i).astype(int)
        binary_pred = (np.array(pred_tiers) >= i).astype(int)
        tier_f1[tier.name] = float(f1_score(binary_true, binary_pred, zero_division=0))

    return {
        "fpr": fpr.tolist(),
        "tpr": tpr.tolist(),
        "roc_auc": float(roc_auc),
        "confusion_matrix": cm.tolist(),
        "tier_f1": tier_f1,
        "mias_tier_agreement": mias_match,
        "y_test": y_test.tolist(),
        "y_proba": y_proba.tolist(),
    }


ZONE_PROFILES: dict[str, tuple[float, float, float, float, float]] = {
    "Coastal": (30, 85, 1008, 26, 22),
    "Arid": (38, 22, 1012, 8, 14),
    "Semi-Arid": (34, 45, 1010, 18, 16),
    "Tropical": (32, 78, 1009, 24, 12),
    "Humid Subtropical": (28, 72, 1007, 22, 10),
}


def bias_audit_by_zone(model: VotingClassifier) -> pd.DataFrame:
    """F1 per climate zone using representative zone weather profiles."""
    from src.preprocessing import build_single_row

    rows = []
    for zone, (temp, hum, pres, dew, wind) in ZONE_PROFILES.items():
        X = build_single_row(temp, hum, pres, dew, wind)
        pred = model.predict(X)[0]
        rows.append({"climate_zone": zone, "predicted_rain": int(pred), "profile": f"{temp}°C, {hum}% RH"})
    return pd.DataFrame(rows)
