"""Dictionary-based multilingual support — English, Hindi, Tamil."""

from __future__ import annotations

LANGUAGES = {"English": "en", "हिन्दी (Hindi)": "hi", "தமிழ் (Tamil)": "ta"}

_TRANSLATIONS: dict[str, dict[str, str]] = {
    # ── Tier names ───────────────────────────────────────────────────────────
    "tier.Safe": {"en": "Safe", "hi": "सुरक्षित", "ta": "பாதுகாப்பான"},
    "tier.Advisory": {"en": "Advisory", "hi": "सलाह", "ta": "ஆலோசனை"},
    "tier.Watch": {"en": "Watch", "hi": "सतर्क रहें", "ta": "கவனமாக இருங்கள்"},
    "tier.Warning": {"en": "Warning", "hi": "चेतावनी", "ta": "எச்சரிக்கை"},
    "tier.Emergency": {"en": "Emergency", "hi": "आपातकाल", "ta": "அவசரநிலை"},

    # ── Tier messages (short advisory text) ──────────────────────────────────
    "tier.Safe.message": {
        "en": "Conditions are stable. No significant rain or flood risk detected.",
        "hi": "स्थिति स्थिर है। कोई महत्वपूर्ण वर्षा या बाढ़ का खतरा नहीं।",
        "ta": "நிலைமைகள் நிலையாக உள்ளன. குறிப்பிடத்தக்க மழை அல்லது வெள்ளம் இல்லை.",
    },
    "tier.Advisory.message": {
        "en": "Elevated moisture detected. Light rain possible in the next few hours.",
        "hi": "अधिक नमी पाई गई। अगले कुछ घंटों में हल्की बारिश संभव।",
        "ta": "அதிக ஈரப்பதம் கண்டறியப்பட்டது. சில மணிநேரங்களில் இலேசான மழை சாத்தியம்.",
    },
    "tier.Watch.message": {
        "en": "Moderate rain probability. Localized flooding possible in low-lying areas.",
        "hi": "मध्यम वर्षा की संभावना। निचले क्षेत्रों में स्थानीय बाढ़ संभव।",
        "ta": "மிதமான மழை சாத்தியம். தாழ்வான பகுதிகளில் வெள்ளம் வரலாம்.",
    },
    "tier.Warning.message": {
        "en": "High rain and flood risk. Heavy rainfall likely.",
        "hi": "अत्यधिक वर्षा और बाढ़ का खतरा। भारी बारिश की संभावना।",
        "ta": "அதிக மழை மற்றும் வெள்ள ஆபத்து. கனமழை எதிர்பார்க்கப்படுகிறது.",
    },
    "tier.Emergency.message": {
        "en": "Extreme flood risk. Life-threatening conditions possible.",
        "hi": "अत्यंत बाढ़ का खतरा। जीवन-घातक परिस्थितियाँ संभव।",
        "ta": "தீவிர வெள்ள ஆபத்து. உயிர் அபாயம் ஏற்படலாம்.",
    },

    # ── Tier actions / recommendations ───────────────────────────────────────
    "tier.Safe.action": {
        "en": "Continue normal activities. Monitor updates periodically.",
        "hi": "सामान्य गतिविधियाँ जारी रखें। समय-समय पर अपडेट देखते रहें।",
        "ta": "வழக்கமான செயல்களை தொடருங்கள். தகவல்களை தொடர்ந்து கண்காணியுங்கள்.",
    },
    "tier.Advisory.action": {
        "en": "Stay informed. Prepare emergency supplies. Secure loose outdoor items.",
        "hi": "सूचित रहें। आपातकालीन सामग्री तैयार करें। बाहरी वस्तुओं को सुरक्षित करें।",
        "ta": "தகவல்களை அறிந்திருங்கள். அவசர பொருட்களை தயார் செய்யுங்கள்.",
    },
    "tier.Watch.action": {
        "en": "Avoid flood-prone zones. Protect assets. Check local advisories.",
        "hi": "बाढ़-प्रवण क्षेत्रों से बचें। संपत्ति सुरक्षित करें। स्थानीय सलाह जाँचें।",
        "ta": "வெள்ளம் அதிகமுள்ள பகுதிகளை தவிர்க்கவும். சொத்துக்களை பாதுகாக்கவும்.",
    },
    "tier.Warning.action": {
        "en": "Move valuables to higher ground. Avoid flood-prone zones. Protect assets immediately.",
        "hi": "मूल्यवान वस्तुएं ऊँचे स्थान पर ले जाएं। बाढ़-प्रवण क्षेत्रों से बचें। संपत्ति तुरंत सुरक्षित करें।",
        "ta": "மதிப்புமிக்க பொருட்களை உயரமான இடத்திற்கு நகர்த்துங்கள். வெள்ள பகுதிகளை தவிர்க்கவும்.",
    },
    "tier.Emergency.action": {
        "en": "Evacuate immediately. Contact authorities. Follow emergency services.",
        "hi": "तुरंत निकासी करें। अधिकारियों से संपर्क करें। आपातकालीन सेवाओं का पालन करें।",
        "ta": "உடனடியாக வெளியேறுங்கள். அதிகாரிகளை தொடர்பு கொள்ளுங்கள். அவசர சேவைகளை பின்பற்றுங்கள்.",
    },

    # ── Alert label ───────────────────────────────────────────────────────────
    "alert.label": {
        "en": "Flood Risk Alert",
        "hi": "बाढ़ चेतावनी",
        "ta": "வெள்ள அபாய எச்சரிக்கை",
    },
    "alert.recommended_action": {
        "en": "Recommended action",
        "hi": "अनुशंसित कार्रवाई",
        "ta": "பரிந்துரைக்கப்பட்ட நடவடிக்கை",
    },

    # ── UI labels ─────────────────────────────────────────────────────────────
    "ui.flood_risk": {"en": "Flood Risk", "hi": "बाढ़ का खतरा", "ta": "வெள்ள ஆபத்து"},
    "ui.confidence": {"en": "Confidence", "hi": "विश्वसनीयता", "ta": "நம்பகத்தன்மை"},
    "ui.rain_probability": {"en": "Rain probability", "hi": "वर्षा संभावना", "ta": "மழை நிகழ்தகவு"},
    "ui.humidity_score": {
        "en": "Humidity Intelligence Score",
        "hi": "आर्द्रता बुद्धिमत्ता स्कोर",
        "ta": "ஈரப்பத புத்திசாலித்தன வரிசை",
    },
    "ui.language": {"en": "Language", "hi": "भाषा", "ta": "மொழி"},
    "ui.risk_level": {"en": "Risk Level", "hi": "जोखिम स्तर", "ta": "ஆபத்து நிலை"},
    "ui.alert_status": {"en": "Alert Status", "hi": "अलर्ट स्थिति", "ta": "எச்சரிக்கை நிலை"},
    "ui.emergency_contacts": {
        "en": "Emergency Contacts",
        "hi": "आपातकालीन संपर्क",
        "ta": "அவசர தொடர்புகள்",
    },
    "ui.estimated_affected": {
        "en": "Est. Affected Population",
        "hi": "अनुमानित प्रभावित जनसंख्या",
        "ta": "மதிப்பிடப்பட்ட பாதிப்புக்குள்ளான மக்கள்",
    },
    "ui.official_advisory": {
        "en": "Official-style advisory",
        "hi": "आधिकारिक सलाह",
        "ta": "அதிகாரப்பூர்வ ஆலோசனை",
    },
}


def t(key: str, lang: str = "en") -> str:
    """Translate a key to the given language code (falls back to English)."""
    entry = _TRANSLATIONS.get(key)
    if entry is None:
        return key
    return entry.get(lang) or entry.get("en") or key


def tier_name(tier_str: str, lang: str = "en") -> str:
    return t(f"tier.{tier_str}", lang)


def tier_message(tier_str: str, lang: str = "en") -> str:
    return t(f"tier.{tier_str}.message", lang)


def tier_action(tier_str: str, lang: str = "en") -> str:
    return t(f"tier.{tier_str}.action", lang)
