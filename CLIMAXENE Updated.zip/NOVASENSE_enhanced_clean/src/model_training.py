"""Ensemble ML training and persistence."""

from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier, VotingClassifier
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split

from src.preprocessing import FEATURE_COLUMNS, load_and_prepare


def train_ensemble(
    df: pd.DataFrame,
    *,
    test_size: float = 0.2,
    random_state: int = 42,
) -> tuple[VotingClassifier, dict, dict[str, float]]:
    """Train RF + GB ensemble and return model, metrics, imputation medians."""
    X, y, medians = load_and_prepare(df, fit=True)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    rf = RandomForestClassifier(n_estimators=100, max_depth=12, random_state=random_state)
    gb = GradientBoostingClassifier(n_estimators=150, learning_rate=0.05, random_state=random_state)
    ensemble = VotingClassifier(
        estimators=[("rf", rf), ("gb", gb)],
        voting="soft",
    )
    ensemble.fit(X_train, y_train)

    y_pred = ensemble.predict(X_test)
    y_proba = ensemble.predict_proba(X_test)[:, 1]

    metrics = {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, zero_division=0)),
        "recall": float(recall_score(y_test, y_pred, zero_division=0)),
        "f1": float(f1_score(y_test, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, y_proba)) if len(np.unique(y_test)) > 1 else 0.0,
        "train_samples": int(len(X_train)),
        "test_samples": int(len(X_test)),
    }

    return ensemble, metrics, medians


def save_model(
    model: VotingClassifier,
    metrics: dict,
    medians: dict[str, float],
    path: Path,
) -> None:
    path.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, path / "ensemble_model.joblib")
    joblib.dump(medians, path / "feature_medians.joblib")
    (path / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")


def load_model(path: Path) -> tuple[VotingClassifier, dict, dict[str, float]]:
    model = joblib.load(path / "ensemble_model.joblib")
    medians = joblib.load(path / "feature_medians.joblib")
    metrics_path = path / "metrics.json"
    metrics = json.loads(metrics_path.read_text(encoding="utf-8")) if metrics_path.exists() else {}
    return model, metrics, medians


def feature_importance(model: VotingClassifier) -> pd.DataFrame:
    """Average feature importances from RF and GB base estimators."""
    importances = np.zeros(len(FEATURE_COLUMNS))
    count = 0
    for name, est in model.named_estimators_.items():
        if hasattr(est, "feature_importances_"):
            importances += est.feature_importances_
            count += 1
    if count:
        importances /= count
    return pd.DataFrame({"feature": FEATURE_COLUMNS, "importance": importances}).sort_values(
        "importance", ascending=True
    )
