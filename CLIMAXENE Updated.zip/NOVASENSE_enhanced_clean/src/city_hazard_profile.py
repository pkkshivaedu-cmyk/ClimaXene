"""
City Hazard Profile — maps every city in the system to its primary natural-hazard type.

Hazard types:
  flood        — heavy rainfall / river overflow (India + Georgia + Kyrgyzstan + parts of Kaz/Taj/Afg)
  snowfall     — heavy snowfall / avalanche (high-altitude Alpine cities)
  sandstorm    — haboob / dust storm (arid Central Asian deserts)
  heatwave     — extreme heat / drought stress (hot-arid zones)
  blizzard     — severe blizzard / dzud (cold steppes — N. Kazakhstan, Mongolia)
  mixed        — multiple seasonal hazards

Each profile contains:
  primary    : dominant hazard type (used for UI, alerts, recommendations)
  secondary  : list of secondary hazards
  icon       : emoji for display
  color      : branding accent colour (distinct from flood tiers)
  risk_label : short label shown in UI instead of "Flood Risk"
"""

from __future__ import annotations
from dataclasses import dataclass, field


@dataclass(frozen=True)
class HazardProfile:
    primary: str          # flood | snowfall | sandstorm | heatwave | blizzard | mixed
    secondary: list[str]  # e.g. ["heatwave"] for a flood city that also overheats
    icon: str             # emoji
    color: str            # hex
    risk_label: str       # e.g. "Snowfall Risk"
    description: str      # one-liner for UI


# ── Master lookup: city name → HazardProfile ──────────────────────────────

_CITY_PROFILES: dict[str, HazardProfile] = {

    # ── India (flood-primary) ──────────────────────────────────────────────
    "Mumbai":           HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Coastal monsoon flooding & cyclone surges"),
    "Delhi":            HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Seasonal monsoon flooding & extreme heat"),
    "Chennai":          HazardProfile("flood",     ["cyclone"],       "🌊", "#3b82f6", "Flood Risk",     "Coastal flooding & cyclone risk"),
    "Kolkata":          HazardProfile("flood",     ["cyclone"],       "🌊", "#3b82f6", "Flood Risk",     "Delta flooding & Bay of Bengal cyclones"),
    "Mumbai":           HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Coastal monsoon flooding"),
    "Bengaluru":        HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Urban flooding during monsoon season"),
    "Hyderabad":        HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Flash flooding & heat stress"),
    "Pune":             HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Monsoon flooding in plateau terrain"),
    "Ahmedabad":        HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Extreme summer heat & flash floods"),
    "Rajkot":           HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Hot arid conditions, dust events"),
    "Jodhpur":          HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Desert dust storms & extreme heat"),
    "Jaipur":           HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Extreme heat & seasonal flooding"),
    "Srinagar":         HazardProfile("snowfall",  ["flood"],         "❄️", "#60a5fa", "Snowfall Risk",  "Heavy snowfall & avalanche risk in winter"),
    "Patna":            HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Ganges river flooding"),
    "Lucknow":          HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "River flooding & heat waves"),
    "Kanpur":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Ganges plain flooding"),
    "Varanasi":         HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Ganges river floods"),
    "Agra":             HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Yamuna river flooding"),
    "Bhopal":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Monsoon flooding"),
    "Indore":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Flash flooding during monsoon"),
    "Nagpur":           HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Seasonal flooding & heat stress"),
    "Visakhapatnam":    HazardProfile("flood",     ["cyclone"],       "🌊", "#3b82f6", "Flood Risk",     "Coastal flooding & cyclone risk"),
    "Vijayawada":       HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Krishna river floods"),
    "Surat":            HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Tapi river & coastal flooding"),
    "Vadodara":         HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "River basin flooding"),
    "Madurai":          HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Vaigai river flooding & heat"),
    "Coimbatore":       HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Monsoon flooding in Nilgiri foothills"),
    "Ranchi":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Chota Nagpur plateau flash floods"),
    "Dhanbad":          HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Monsoon flooding"),
    "Meerut":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Gangetic plain flooding"),
    "Ghaziabad":        HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Hindon river flooding"),
    "Faridabad":        HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Yamuna floodplain risk"),
    "Amritsar":         HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Ravi river seasonal flooding"),
    "Ludhiana":         HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Sutlej basin flooding"),
    "Gwalior":          HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Chambal basin flooding"),
    "Jabalpur":         HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Narmada river flooding"),
    "Nashik":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Godavari river flooding"),
    "Allahabad":        HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Prayagraj confluence flooding"),
    "Howrah":           HazardProfile("flood",     ["cyclone"],       "🌊", "#3b82f6", "Flood Risk",     "Hooghly river flooding"),
    "Thane":            HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Coastal & urban flooding"),

    # ── Kazakhstan ─────────────────────────────────────────────────────────
    "Almaty":           HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Mountain runoff flooding & heavy snowfall"),
    "Astana":           HazardProfile("blizzard",  ["flood"],         "🌨️", "#818cf8", "Blizzard Risk",  "Severe blizzards & spring flood risk"),
    "Shymkent":         HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Extreme heat & dust storms"),
    "Aktobe":           HazardProfile("blizzard",  ["flood"],         "🌨️", "#818cf8", "Blizzard Risk",  "Winter blizzards & spring meltwater floods"),
    "Taraz":            HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Arid heat & seasonal flash flooding"),
    "Pavlodar":         HazardProfile("blizzard",  ["flood"],         "🌨️", "#818cf8", "Blizzard Risk",  "Steppe blizzards & Irtysh flooding"),
    "Ust-Kamenogorsk":  HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Irtysh river flooding & mountain snow"),
    "Semey":            HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Cold steppe winter blizzards"),
    "Atyrau":           HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Caspian steppe dust storms & heat"),
    "Kostanay":         HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Northern steppe blizzards"),
    "Kyzylorda":        HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Aral Sea basin dust storms"),
    "Petropavl":        HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Severe winter blizzards & snowfall"),
    "Aktau":            HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Caspian desert dust & extreme heat"),
    "Temirtau":         HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Industrial steppe — winter blizzards"),
    "Turkestan":        HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Desert dust storms & heat"),
    "Taldykorgan":      HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Ili river & Tian Shan snowmelt flooding"),
    "Ekibastuz":        HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Steppe blizzards"),
    "Rudny":            HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Northern steppe winter storms"),
    "Zhanaozen":        HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Mangyshlak desert dust storms"),
    "Balqash":          HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Lake Balkhash basin dust events"),

    # ── Uzbekistan ─────────────────────────────────────────────────────────
    "Tashkent":         HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Extreme summer heat & flash flooding"),
    "Samarkand":        HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Desert heat & dust storms"),
    "Namangan":         HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Fergana Valley heat & Naryn floods"),
    "Andijan":          HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Fergana Valley — heat & flooding"),
    "Nukus":            HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Aral Sea dust basin — extreme dust storms"),
    "Bukhara":          HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Kyzylkum desert dust & severe heat"),
    "Qarshi":           HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "South Uzbekistan arid heat"),
    "Fergana":          HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Valley heat & seasonal flooding"),
    "Margilan":         HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Fergana Valley heat stress"),
    "Navoi":            HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Desert industrial city — dust storms"),
    "Urgench":          HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Khorezm oasis — Aral dust storms"),
    "Gulistan":         HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Syr Darya basin heat & flooding"),
    "Termez":           HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Afghanistan border — extreme heat"),
    "Jizzakh":          HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Central Uzbekistan arid heat"),
    "Kokand":           HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Fergana Valley — heat & flooding"),

    # ── Kyrgyzstan ─────────────────────────────────────────────────────────
    "Bishkek":          HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Spring glacial melt flooding & snowfall"),
    "Osh":              HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Mountain river flooding"),
    "Jalal-Abad":       HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Kara Darya flooding"),
    "Tokmok":           HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Chu Valley flooding"),
    "Karakol":          HazardProfile("snowfall",  ["flood"],         "❄️", "#60a5fa", "Snowfall Risk",  "Issyk-Kul mountain snow & avalanche"),
    "Uzgen":            HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Kara Darya basin flooding"),
    "Kara-Balta":       HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Chu Valley flooding & snowfall"),
    "Balykchy":         HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Issyk-Kul meltwater flooding"),
    "Naryn":            HazardProfile("snowfall",  ["flood"],         "❄️", "#60a5fa", "Snowfall Risk",  "High-altitude snowfall & Naryn river floods"),
    "Batken":           HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "South Kyrgyzstan border — heat & flash floods"),

    # ── Tajikistan ─────────────────────────────────────────────────────────
    "Dushanbe":         HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Mountain flash floods & mudslides"),
    "Khujand":          HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Syr Darya flooding & summer heat"),
    "Bokhtar":          HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "South Tajikistan — heat & flooding"),
    "Kulob":            HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Mountain watershed flash floods"),
    "Qurghonteppa":     HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Lowland heat & Amu Darya flooding"),
    "Khorugh":          HazardProfile("snowfall",  ["flood"],         "❄️", "#60a5fa", "Snowfall Risk",  "Pamirs — severe snowfall & avalanche"),
    "Istaravshan":      HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Zarafshan valley flooding"),
    "Panjakent":        HazardProfile("heatwave",  ["flood"],         "🌡️", "#ef4444", "Heatwave Risk",  "Zarafshan — arid heat & flash floods"),
    "Vahdat":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Kofarnihon river flooding"),
    "Hisor":            HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Kofarnihon valley flooding"),

    # ── Turkmenistan ───────────────────────────────────────────────────────
    "Ashgabat":         HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Karakum desert dust storms & extreme heat"),
    "Turkmenbashi":     HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Caspian coastal dust & heat"),
    "Dashoguz":         HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Aral Sea dust basin — haboob events"),
    "Mary":             HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Murghab oasis — dust storms"),
    "Turkmenabat":      HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Amu Darya — dust storms & heat"),
    "Balkanabat":       HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Karakum dust & Caspian heat"),
    "Bayramaly":        HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Desert heat & dust events"),
    "Tejen":            HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Karakum extreme heat & dust"),
    "Serdar":           HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "Karakum desert dust storms"),
    "Sarahs":           HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Afghan border — extreme desert heat"),

    # ── Afghanistan ─────────────────────────────────────────────────────────
    "Kabul":            HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Kabul river flooding & mountain snowfall"),
    "Kandahar":         HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "South Afghan desert — extreme heat & dust"),
    "Herat":            HazardProfile("sandstorm", ["heatwave"],      "🌪️", "#f59e0b", "Sandstorm Risk", "120-day wind & dust storms"),
    "Mazar-i-Sharif":   HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Balkh river flooding & summer heat"),
    "Kunduz":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Kunduz river flooding"),
    "Jalalabad":        HazardProfile("flood",     ["heatwave"],      "🌊", "#3b82f6", "Flood Risk",     "Kabul river flooding & heat"),
    "Ghazni":           HazardProfile("snowfall",  ["flood"],         "❄️", "#60a5fa", "Snowfall Risk",  "High-plateau snowfall & spring flooding"),
    "Baghlan":          HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Kunduz basin flash flooding"),
    "Bamyan":           HazardProfile("snowfall",  ["flood"],         "❄️", "#60a5fa", "Snowfall Risk",  "Hazarajat highlands — heavy snowfall"),
    "Taloqan":          HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Taloqan river flash flooding"),

    # ── Mongolia ────────────────────────────────────────────────────────────
    "Ulaanbaatar":      HazardProfile("blizzard",  ["flood"],         "🌨️", "#818cf8", "Blizzard Risk",  "Dzud (severe winter storms) & spring flooding"),
    "Erdenet":          HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Steppe winter blizzards"),
    "Darkhan":          HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Northern Mongolia blizzards"),
    "Khovd":            HazardProfile("blizzard",  ["sandstorm"],     "🌨️", "#818cf8", "Blizzard Risk",  "Western Mongolia — blizzards & dust"),
    "Murun":            HazardProfile("blizzard",  [],                "🌨️", "#818cf8", "Blizzard Risk",  "Khovsgol highlands — severe blizzards"),

    # ── Georgia ─────────────────────────────────────────────────────────────
    "Tbilisi":          HazardProfile("flood",     ["snowfall"],      "🌊", "#3b82f6", "Flood Risk",     "Mtkvari/Vere flash floods & mountain snowfall"),
    "Kutaisi":          HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Rioni river flooding"),
    "Batumi":           HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Black Sea coast — heavy rainfall & flooding"),
    "Rustavi":          HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Mtkvari river flooding"),
    "Zugdidi":          HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Enguri river flooding"),

    # ── Azerbaijan ──────────────────────────────────────────────────────────
    "Baku":             HazardProfile("sandstorm", ["flood"],         "🌪️", "#f59e0b", "Sandstorm Risk", "Caspian dust storms & Kura flooding"),
    "Sumqayit":         HazardProfile("sandstorm", ["flood"],         "🌪️", "#f59e0b", "Sandstorm Risk", "Apsheron dust events"),
    "Ganja":            HazardProfile("flood",     ["sandstorm"],     "🌊", "#3b82f6", "Flood Risk",     "Kura river flooding & dust"),
    "Mingachevir":      HazardProfile("flood",     [],                "🌊", "#3b82f6", "Flood Risk",     "Kura river dam flooding risk"),
    "Nakhchivan":       HazardProfile("heatwave",  ["sandstorm"],     "🌡️", "#ef4444", "Heatwave Risk",  "Exclave — arid heat & dust storms"),
}


# ── Default for unknown cities ─────────────────────────────────────────────

_DEFAULT_PROFILE = HazardProfile(
    "flood", [], "🌊", "#3b82f6", "Weather Risk",
    "General weather risk assessment"
)


def get_hazard_profile(city: str) -> HazardProfile:
    """Return HazardProfile for a city. Falls back to flood/generic if unknown."""
    return _CITY_PROFILES.get(city, _DEFAULT_PROFILE)


def get_primary_hazard(city: str) -> str:
    return get_hazard_profile(city).primary


def is_flood_city(city: str) -> bool:
    return get_primary_hazard(city) == "flood"


# ── Hazard-aware sensor name (for Live Intelligence labels) ─────────────────

_SENSOR_LABELS: dict[str, str] = {
    "flood":     "HIE (Humidity Intelligence)",
    "snowfall":  "SIE (Snow Intelligence Engine)",
    "sandstorm": "DIE (Dust Intelligence Engine)",
    "heatwave":  "TIE (Thermal Intelligence Engine)",
    "blizzard":  "BIE (Blizzard Intelligence Engine)",
    "mixed":     "MIE (Multi-hazard Intelligence)",
}


def get_sensor_label(city: str) -> str:
    return _SENSOR_LABELS.get(get_primary_hazard(city), "HIE (Humidity Intelligence)")
