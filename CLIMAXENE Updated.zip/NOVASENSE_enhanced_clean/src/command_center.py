"""Emergency Command Center — aggregated view for a selected city."""

from __future__ import annotations

import json
import math
from pathlib import Path

import streamlit as st

from src.predictions import PredictionResult

_CONTACTS_PATH = Path(__file__).resolve().parent.parent / "data" / "emergency_contacts.json"
_POP_PATH = Path(__file__).resolve().parent.parent / "data" / "city_population.json"

_TIER_AFFECTED_PCT = {
    "Safe": 0.0,
    "Advisory": 0.01,
    "Watch": 0.04,
    "Warning": 0.12,
    "Emergency": 0.28,
}

_STATUS_PULSE = {
    "Safe": ("#22c55e", "✅ CLEAR"),
    "Advisory": ("#eab308", "⚠️ ADVISORY"),
    "Watch": ("#f97316", "🟠 WATCH"),
    "Warning": ("#ef4444", "🔴 WARNING"),
    "Emergency": ("#7f1d1d", "🆘 EMERGENCY"),
}

_TIER_BULLETS = {
    "Safe": [
        "Monitor IMD bulletins every 24 hours.",
        "No evacuation or protective action required.",
        "Keep emergency kit accessible as general practice.",
    ],
    "Advisory": [
        "Prepare 72-hour emergency supplies (water, food, medicines).",
        "Stay informed via local news and IMD app.",
        "Secure outdoor furniture and drains.",
    ],
    "Watch": [
        "Move documents and valuables to higher floor.",
        "Avoid drainage channels and low-lying roads.",
        "Brief family members on evacuation plan.",
        "Keep vehicle fuel tank above half.",
    ],
    "Warning": [
        "Avoid all flood-prone and low-lying zones.",
        "Sandbag doors and disconnect electrical appliances.",
        "Keep emergency contacts on speed dial.",
        "Wait for official evacuation orders.",
        "Protect assets — do not wade through floodwater.",
    ],
    "Emergency": [
        "🚨 EVACUATE LOW-LYING AREAS IMMEDIATELY.",
        "Call 112 or NDRF for rescue assistance.",
        "Do NOT drive or walk through floodwater.",
        "Follow only official evacuation routes.",
        "Move to the nearest designated shelter.",
        "Carry ID, medicines, and 3-day supplies.",
    ],
}


@st.cache_data
def _load_population() -> dict:
    if _POP_PATH.exists():
        return json.loads(_POP_PATH.read_text(encoding="utf-8"))
    return {}


@st.cache_data
def _load_contacts() -> dict:
    if _CONTACTS_PATH.exists():
        return json.loads(_CONTACTS_PATH.read_text(encoding="utf-8"))
    return {}


def _fmt_population(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.0f}K"
    return str(n)


def render_command_center(
    city: str,
    result: PredictionResult,
    *,
    lang: str = "en",
) -> None:
    from src.i18n import t, tier_action, tier_name as tname

    tier = result.tier
    pulse_color, pulse_label = _STATUS_PULSE.get(tier.name, ("#94a3b8", tier.name))

    populations = _load_population()
    contacts = _load_contacts()

    city_pop = populations.get(city, 0)
    affected_pct = _TIER_AFFECTED_PCT.get(tier.name, 0)
    est_affected = math.ceil(city_pop * affected_pct)

    # ── Header status strip ───────────────────────────────────────────────
    st.markdown(
        f"""
        <div style="
            background:{pulse_color};
            color:#ffffff;
            padding:0.75rem 1.5rem;
            border-radius:12px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            margin-bottom:1rem;
        ">
            <span style="font-size:1.1rem;font-weight:800;letter-spacing:0.02em;">
                {pulse_label}
            </span>
            <span style="font-size:0.85rem;opacity:0.9;">
                {city} · ClimaXene Emergency Command Center
            </span>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # ── KPI row ───────────────────────────────────────────────────────────
    c1, c2, c3, c4 = st.columns(4)
    _kpi(c1, t("ui.flood_risk", lang), f"{result.adjusted_score * 100:.0f}%", tier.name, pulse_color)
    _kpi(c2, t("ui.humidity_score", lang), f"{result.mias_factor:.3f}×", "HIE amplification", "#0891b2")
    _kpi(c3, t("ui.confidence", lang), f"{result.confidence_pct:.0f}%", "Inter-model agreement", "#8b5cf6")
    if city_pop:
        _kpi(c4, t("ui.estimated_affected", lang), _fmt_population(est_affected),
             f"{affected_pct * 100:.0f}% of {_fmt_population(city_pop)}", "#f97316")
    else:
        _kpi(c4, t("ui.estimated_affected", lang), "—", "Population data unavailable", "#94a3b8")

    st.markdown("<br>", unsafe_allow_html=True)

    col_a, col_b = st.columns([1.1, 1])

    # ── Recommended actions ───────────────────────────────────────────────
    with col_a:
        st.markdown(
            f'<p style="font-size:1rem;font-weight:700;color:#0f172a;margin-bottom:0.5rem;">'
            f'🛡️ {t("alert.recommended_action", lang)}</p>',
            unsafe_allow_html=True,
        )
        bullets = _TIER_BULLETS.get(tier.name, [])
        for b in bullets:
            st.markdown(
                f'<div style="padding:0.45rem 0.75rem;margin:0.3rem 0;border-radius:8px;'
                f'background:{pulse_color}10;border-left:4px solid {pulse_color};'
                f'font-size:0.9rem;color:#1e293b;">{b}</div>',
                unsafe_allow_html=True,
            )

    # ── Emergency contacts ────────────────────────────────────────────────
    with col_b:
        st.markdown(
            f'<p style="font-size:1rem;font-weight:700;color:#0f172a;margin-bottom:0.5rem;">'
            f'📞 {t("ui.emergency_contacts", lang)}</p>',
            unsafe_allow_html=True,
        )
        national = contacts.get("national", [])
        for entry in national[:5]:
            _contact_card(entry["name"], entry["number"], entry["description"])

        city_to_state = contacts.get("city_to_state", {})
        state = city_to_state.get(city)
        if state:
            state_contacts = contacts.get("state", {}).get(state, [])
            if state_contacts:
                st.markdown(
                    f'<p style="font-size:0.78rem;font-weight:700;color:#64748b;'
                    f'text-transform:uppercase;letter-spacing:0.06em;margin:0.65rem 0 0.35rem;">'
                    f'{state} State</p>',
                    unsafe_allow_html=True,
                )
                for entry in state_contacts:
                    _contact_card(entry["name"], entry["number"], entry["description"])


def _kpi(col, label: str, value: str, delta: str, color: str) -> None:
    col.markdown(
        f"""
        <div style="background:#fff;border:1px solid #e2e8f0;border-radius:12px;
            padding:1rem 1.1rem;border-top:4px solid {color};">
            <div style="font-size:0.68rem;text-transform:uppercase;letter-spacing:0.07em;
                color:#64748b;font-weight:600;">{label}</div>
            <div style="font-size:1.55rem;font-weight:800;color:#0f172a;margin-top:0.2rem;">
                {value}
            </div>
            <div style="font-size:0.75rem;color:{color};margin-top:0.15rem;">{delta}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def _contact_card(name: str, number: str, desc: str) -> None:
    st.markdown(
        f"""
        <div style="display:flex;align-items:center;gap:0.6rem;
            background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
            padding:0.5rem 0.75rem;margin:0.25rem 0;">
            <div>
                <div style="font-size:0.82rem;font-weight:700;color:#0f172a;">{name}</div>
                <div style="font-size:0.75rem;color:#64748b;">{desc}</div>
            </div>
            <div style="margin-left:auto;font-size:1rem;font-weight:800;color:#0891b2;
                white-space:nowrap;">{number}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
