"""Live multi-hazard map — OpenWeather live fetch for user-selected cities."""

from __future__ import annotations

import pandas as pd

from src.predictions import predict
from src.weather_api import fetch_live_weather
from sklearn.ensemble import VotingClassifier


def fetch_live_city_risks(
    model: VotingClassifier,
    cities_df: pd.DataFrame,
    selected_cities: list[str],
    api_key: str,
    *,
    elapsed_seconds: float = 2.0,
) -> pd.DataFrame:
    # Import hazard profile tools for city-aware risk scoring
    try:
        from src.hazard_profile import (
            get_profile, get_profile_by_climate,
            compute_primary_score,
        )
        _hazard_aware = True
    except ImportError:
        _hazard_aware = False

    subset = cities_df[cities_df["city"].isin(selected_cities)]
    rows = []
    errors = []
    for _, c in subset.iterrows():
        city = c["city"]
        try:
            w = fetch_live_weather(city, api_key)
            r = predict(
                model,
                w["temperature"],
                w["humidity"],
                w["pressure"],
                w["dew_point"],
                w["wind_speed"],
                elapsed_seconds=elapsed_seconds,
            )

            # For non-flood cities, override the risk score with the
            # city-specific primary hazard score (sandstorm, snowfall, heat, etc.)
            display_risk_pct = r.adjusted_score * 100
            if _hazard_aware:
                climate_zone = c.get("climate_zone", "Semi-Arid")
                profile = get_profile(city) or get_profile_by_climate(climate_zone, city)
                from src.hazard_profile import HazardType
                if profile.primary_hazard != HazardType.FLOOD:
                    hazard_score = compute_primary_score(
                        profile,
                        w["temperature"], w["humidity"], w["pressure"],
                        w["dew_point"], w["wind_speed"],
                    )
                    display_risk_pct = hazard_score * 100
                    # Also update the tier for display consistency
                    from src.risk_scoring import classify_risk
                    r = type(r)(
                        ml_prob=r.ml_prob,
                        adjusted_score=hazard_score,
                        mias_factor=r.mias_factor,
                        tier=classify_risk(hazard_score),
                        confidence_pct=r.confidence_pct,
                        tier_probs=r.tier_probs,
                        prob_std=r.prob_std,
                        drought_score=r.drought_score,
                        mxene=r.mxene,
                    )

            rows.append(
                {
                    "city": w.get("city", city),
                    "lat": c["lat"],
                    "lon": c["lon"],
                    "climate_zone": c.get("climate_zone", ""),
                    "tier": r.tier.name,
                    "risk_pct": display_risk_pct,
                    "temperature": w["temperature"],
                    "humidity": w["humidity"],
                    "description": w.get("description", ""),
                    "live": True,
                }
            )
        except Exception as e:
            errors.append(f"{city}: {e}")
    if errors and not rows:
        raise RuntimeError("; ".join(errors))
    df = pd.DataFrame(rows)
    df.attrs["errors"] = errors
    return df

