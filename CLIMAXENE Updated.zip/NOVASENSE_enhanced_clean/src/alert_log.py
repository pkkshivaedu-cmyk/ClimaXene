"""Tier transition notification log (session-based)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


@dataclass
class AlertEntry:
    timestamp: str
    city: str
    from_tier: str
    to_tier: str
    message: str


def record_tier_change(
    log: list[AlertEntry],
    city: str,
    old_tier: str,
    new_tier: str,
    *,
    summary: str = "",
) -> list[AlertEntry]:
    tier_order = ["Safe", "Advisory", "Watch", "Warning", "Emergency"]
    if old_tier == new_tier:
        return log
    if tier_order.index(new_tier) <= tier_order.index(old_tier):
        return log
    entry = AlertEntry(
        timestamp=datetime.now().strftime("%H:%M:%S"),
        city=city,
        from_tier=old_tier,
        to_tier=new_tier,
        message=summary or f"{city} crossed from {old_tier} → {new_tier}",
    )
    return [entry] + log[:49]
